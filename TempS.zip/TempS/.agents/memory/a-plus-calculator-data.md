---
name: A Plus calculator data
description: User-approved demo-data rule for A Plus calculator option selectors and displayed premiums.
---

For the A Plus calculator, the user asked to use dummy data for all dropdown options.

**Why:** the provided references do not show complete insurer option lists, and the user explicitly chose dummy values.

**How to apply:** Label dropdown options as demo data, avoid implying insurer availability, and show only premium values supported by the supplied references.
