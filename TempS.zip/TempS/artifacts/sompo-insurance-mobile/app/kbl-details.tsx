import React, { useState } from 'react';
import { Platform, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppHeader, LabeledInput, PrimaryButton } from '@/components/AppUI';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

export default function KBLDetailsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { addPolicy } = useAppState();
  const { action = 'status', claimType = 'Health' } = useLocalSearchParams<{
    action?: string;
    claimType?: string;
  }>();
  const [accountNumber, setAccountNumber] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [error, setError] = useState('');
  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;

  const verify = async () => {
    const validDate = /^\d{2}\/\d{2}\/\d{4}$/.test(dateOfBirth.trim());
    if (accountNumber.trim().length < 4 || !validDate) {
      setError('Enter an account number and date of birth in DD/MM/YYYY format.');
      return;
    }
    setError('');
    if (action === 'link') {
      const category = claimType.toLowerCase().includes('motor')
        ? 'Motor'
        : claimType.toLowerCase().includes('health')
          ? 'Health'
          : 'Other';
      await addPolicy({
        id: `linked-${Date.now()}`,
        name: `Linked ${claimType} Policy`,
        company: 'Linked on this device',
        policyNumber: accountNumber.trim().toUpperCase(),
        sumAssured: 'Details on insurer account',
        expiryDate: 'Confirm with insurer',
        category,
      });
      router.replace('/policies');
      return;
    }
    router.replace({
      pathname: '/claim-action',
      params: { action, claimType, account: accountNumber.trim() },
    });
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.page, { backgroundColor: colors.screen }]}
      contentContainerStyle={[
        styles.content,
        { paddingTop: topInset + 8, paddingBottom: bottomInset + 24 },
      ]}
      bottomOffset={80}
      keyboardShouldPersistTaps="handled"
    >
      <AppHeader title="KBL Details" onBack={() => router.back()} />
      <View style={styles.brandRow}>
        <View style={[styles.brandPill, { backgroundColor: colors.white, borderColor: colors.border }]}>
          <Ionicons name="shield-checkmark" size={17} color={colors.primary} />
          <Text style={[styles.brandText, { color: colors.foreground }]}>Universal Sompo</Text>
        </View>
        <View style={[styles.bankPill, { backgroundColor: colors.primary, borderColor: colors.primary }]}>
          <Ionicons name="business-outline" size={15} color={colors.white} />
          <Text style={[styles.bankText, { color: colors.white }]}>Karnataka Bank</Text>
        </View>
      </View>
      <View style={styles.trust}>
        <Ionicons name="lock-closed" size={13} color={colors.success} />
        <Text style={[styles.trustText, { color: colors.success }]}>Secure & Trusted</Text>
      </View>
      <Text style={[styles.title, { color: colors.foreground }]}>Let’s Verify{"\n"}It’s You</Text>
      <Text style={[styles.description, { color: colors.mutedForeground }]}>
        {action === 'link'
          ? 'Enter your account details to add a policy record to this device.'
          : `Complete the secure check to view ${claimType.toLowerCase()} policy information.`}
      </Text>
      <View style={[styles.illustration, { backgroundColor: colors.primaryWash }]}>
        <Ionicons name="phone-portrait-outline" size={48} color={colors.primary} />
        <View style={[styles.illustrationBadge, { backgroundColor: colors.white }]}>
          <Ionicons name="shield-checkmark" size={20} color={colors.success} />
        </View>
      </View>
      <LabeledInput
        label="Account Number *"
        value={accountNumber}
        onChangeText={setAccountNumber}
        placeholder="Enter your account number"
        autoCapitalize="characters"
        returnKeyType="next"
      />
      <LabeledInput
        label="Date of Birth *"
        value={dateOfBirth}
        onChangeText={setDateOfBirth}
        placeholder="DD/MM/YYYY"
        keyboardType="numbers-and-punctuation"
        maxLength={10}
      />
      {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
      <View style={styles.footer}>
        <PrimaryButton label="Proceed to verify" icon="shield-checkmark-outline" onPress={verify} />
      </View>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 17, gap: 14 },
  brandRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  brandPill: { flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1, borderRadius: 11, paddingVertical: 8, paddingHorizontal: 9 },
  bankPill: { flexDirection: 'row', alignItems: 'center', gap: 5, borderWidth: 1, borderRadius: 11, paddingVertical: 8, paddingHorizontal: 9 },
  brandText: { fontSize: 10, fontWeight: '800' },
  bankText: { fontSize: 9, fontWeight: '800' },
  trust: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 7 },
  trustText: { fontSize: 10, fontWeight: '700' },
  title: { fontSize: 23, lineHeight: 28, fontWeight: '800' },
  description: { fontSize: 12, lineHeight: 18, maxWidth: 300 },
  illustration: { height: 105, borderRadius: 20, alignItems: 'center', justifyContent: 'center', marginVertical: 2 },
  illustrationBadge: { width: 35, height: 35, borderRadius: 18, alignItems: 'center', justifyContent: 'center', position: 'absolute', right: '32%', bottom: 18 },
  error: { fontSize: 11, lineHeight: 15 },
  footer: { marginTop: 'auto', paddingTop: 14 },
});
