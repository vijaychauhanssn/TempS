import React, { useEffect, useState } from 'react';
import { Alert, Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import {
  AppHeader,
  AppPage,
  LabeledInput,
  PrimaryButton,
  SectionHeading,
  SurfaceCard,
} from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';
import { listDemoHealthClaims } from '@/src/services/claimService';

const demoClaims = [
  { id: 'CLM-240815', policyNumber: 'USGI/HLT/2025/0021', type: 'Health Claim', state: 'Documents reviewed', icon: 'checkmark-circle-outline' as const },
  { id: 'CLM-240921', policyNumber: 'USGI/MTR/2025/0042', type: 'Motor Claim', state: 'Under assessment', icon: 'time-outline' as const },
];

export default function ClaimActionScreen() {
  const colors = useColors();
  const { action = 'status', claimType = 'Health' } = useLocalSearchParams<{
    action?: string;
    claimType?: string;
  }>();
  const [incidentDate, setIncidentDate] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');
  const [reference, setReference] = useState('');
  const [statusClaims, setStatusClaims] = useState(demoClaims);
  const [statusModalVisible, setStatusModalVisible] = useState(false);
  const [lookupMethod, setLookupMethod] = useState<'policy' | 'claim'>('policy');
  const [lookupValue, setLookupValue] = useState('');
  const [lookupError, setLookupError] = useState('');
  const [statusResult, setStatusResult] = useState('');

  useEffect(() => {
    let isMounted = true;
    void listDemoHealthClaims().then((savedClaims) => {
      if (!isMounted) return;
      const saved = savedClaims.map((claim) => ({
        id: claim.reference,
        policyNumber: claim.policyNumber,
        type: 'Health Claim',
        state: claim.status,
        icon: 'time-outline' as const,
      }));
      setStatusClaims([...saved, ...demoClaims]);
    });
    return () => {
      isMounted = false;
    };
  }, []);

  const title =
    action === 'initiate'
      ? 'Claim Intimation'
      : action === 'forms'
        ? 'Claim Forms'
        : 'Claim Status';

  const submitIntimation = () => {
    if (!/^\d{2}\/\d{2}\/\d{4}$/.test(incidentDate.trim()) || description.trim().length < 10) {
      setError('Enter the incident date and at least 10 characters describing what happened.');
      return;
    }
    setError('');
    setReference(`DEMO-${Date.now().toString().slice(-6)}`);
  };

  const submitStatusLookup = () => {
    const query = lookupValue.trim().toLowerCase();
    if (!query) {
      setLookupError(`Enter a ${lookupMethod === 'policy' ? 'policy' : 'claim'} number.`);
      return;
    }
    const expectedType = claimType.toLowerCase().includes('motor') ? 'motor claim' : 'health claim';
    const match = statusClaims.find((claim) => {
      if (claim.type.toLowerCase() !== expectedType) return false;
      const candidate = lookupMethod === 'policy' ? claim.policyNumber : claim.id;
      return candidate.toLowerCase() === query;
    });
    setStatusResult(
      match
        ? `${match.id} · ${match.state}`
        : 'No matching demo claim was found. Live insurer status is not connected.',
    );
    setLookupError('');
    setStatusModalVisible(false);
  };

  return (
    <>
      <AppPage contentStyle={styles.content}>
        <AppHeader title={title} onBack={() => router.back()} />
        {action === 'initiate' ? (
          reference ? (
            <SurfaceCard style={styles.successCard}>
              <View style={[styles.successIcon, { backgroundColor: colors.primaryWash }]}>
                <Ionicons name="checkmark" size={30} color={colors.success} />
              </View>
              <Text style={[styles.successTitle, { color: colors.foreground }]}>Intimation saved</Text>
              <Text style={[styles.body, { color: colors.mutedForeground }]}>
                Demo reference number: {reference}
              </Text>
              <Text style={[styles.note, { color: colors.mutedForeground }]}>
                This was saved only for this screen and was not sent to the insurer.
              </Text>
              <PrimaryButton label="Back to claims" icon="arrow-forward" onPress={() => router.replace('/claims')} />
            </SurfaceCard>
          ) : (
            <>
              <View style={[styles.banner, { backgroundColor: colors.primaryWash }]}>
                <Ionicons name="document-text-outline" size={22} color={colors.primary} />
                <Text style={[styles.bannerText, { color: colors.foreground }]}>
                  {claimType} claim · provide a few details to create a local demo intimation.
                </Text>
              </View>
              <LabeledInput
                label="Incident date *"
                value={incidentDate}
                onChangeText={setIncidentDate}
                placeholder="DD/MM/YYYY"
                keyboardType="numbers-and-punctuation"
                maxLength={10}
              />
              <LabeledInput
                label="What happened? *"
                value={description}
                onChangeText={setDescription}
                placeholder="Briefly describe the incident"
                multiline
                style={styles.multiline}
              />
              {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
              <PrimaryButton label="Submit demo intimation" icon="arrow-forward" onPress={submitIntimation} />
            </>
          )
        ) : null}

        {action === 'status' ? (
          <>
            <Text style={[styles.body, { color: colors.mutedForeground }]}>
              Sample claim updates are shown below. Your live claim status is not connected.
            </Text>
            <PrimaryButton
              label="Check claim status"
              icon="search-outline"
              onPress={() => {
                setLookupValue('');
                setLookupError('');
                setStatusModalVisible(true);
              }}
            />
            {statusResult ? (
              <View style={[styles.statusResult, { backgroundColor: colors.primaryWash }]}>
                <Ionicons name="information-circle-outline" size={18} color={colors.primary} />
                <Text style={[styles.body, { color: colors.foreground }]}>{statusResult}</Text>
              </View>
            ) : null}
            <SectionHeading title="Recent claims" />
            {statusClaims
              .filter((claim) => claim.type.toLowerCase().includes(claimType.toLowerCase()))
              .map((claim) => (
                <SurfaceCard key={claim.id} style={styles.statusCard}>
                  <View style={[styles.statusIcon, { backgroundColor: colors.primaryWash }]}>
                    <Ionicons name={claim.icon} size={21} color={colors.primary} />
                  </View>
                  <View style={styles.statusCopy}>
                    <Text style={[styles.statusType, { color: colors.foreground }]}>{claim.type}</Text>
                    <Text style={[styles.note, { color: colors.mutedForeground }]}>{claim.id}</Text>
                    <Text style={[styles.statusState, { color: colors.primary }]}>{claim.state}</Text>
                  </View>
                  <Ionicons name="chevron-forward" size={17} color={colors.mutedForeground} />
                </SurfaceCard>
              ))}
            <PrimaryButton label="Start a claim" icon="arrow-forward" onPress={() => router.replace('/claims')} />
          </>
        ) : null}

        {action === 'forms' ? (
          <>
            <Text style={[styles.body, { color: colors.mutedForeground }]}>
              Choose a sample checklist to review. Official claim forms are provided by the insurer.
            </Text>
            {[
              { name: 'Health Claim Form', detail: 'Hospitalization and medical expense checklist' },
              { name: 'Motor Claim Form', detail: 'Accident and vehicle damage checklist' },
              { name: 'Claim Documents Checklist', detail: 'Documents commonly requested for review' },
            ].map((form) => (
              <SurfaceCard key={form.name} style={styles.formCard}>
                <View style={[styles.statusIcon, { backgroundColor: colors.primaryWash }]}>
                  <Ionicons name="document-text-outline" size={20} color={colors.primary} />
                </View>
                <View style={styles.statusCopy}>
                  <Text style={[styles.statusType, { color: colors.foreground }]}>{form.name}</Text>
                  <Text style={[styles.note, { color: colors.mutedForeground }]}>{form.detail}</Text>
                </View>
                <PrimaryButton
                  label="View"
                  onPress={() => Alert.alert(form.name, `${form.detail}.\n\nThis demonstration does not contain official insurer forms.`)}
                  style={styles.viewButton}
                />
              </SurfaceCard>
            ))}
          </>
        ) : null}
      </AppPage>

      <Modal
        visible={statusModalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setStatusModalVisible(false)}
      >
        <View style={[styles.lookupBackdrop, { backgroundColor: colors.scrim }]}>
          <Pressable
            accessibilityLabel="Close claim status lookup"
            onPress={() => setStatusModalVisible(false)}
            style={StyleSheet.absoluteFill}
          />
          <SurfaceCard style={styles.lookupCard}>
            <View style={styles.lookupHeader}>
              <Text style={[styles.lookupTitle, { color: colors.foreground }]}>
                {claimType} Claim Status
              </Text>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Close claim status lookup"
                onPress={() => setStatusModalVisible(false)}
                hitSlop={10}
              >
                <Ionicons name="close" size={21} color={colors.primary} />
              </Pressable>
            </View>
            <Text style={[styles.body, { color: colors.mutedForeground }]}>
              How would you like to look up the claim?
            </Text>
            <View style={styles.lookupChoices}>
              {(['policy', 'claim'] as const).map((method) => (
                <Pressable
                  key={method}
                  accessibilityRole="radio"
                  accessibilityState={{ checked: lookupMethod === method }}
                  onPress={() => setLookupMethod(method)}
                  style={styles.lookupChoice}
                >
                  <Ionicons
                    name={lookupMethod === method ? 'radio-button-on' : 'radio-button-off'}
                    size={18}
                    color={lookupMethod === method ? colors.primary : colors.mutedForeground}
                  />
                  <Text style={[styles.lookupChoiceText, { color: colors.foreground }]}>
                    {method === 'policy' ? 'Policy Number' : 'Claim Number'}
                  </Text>
                </Pressable>
              ))}
            </View>
            <LabeledInput
              label={lookupMethod === 'policy' ? 'Policy Number' : 'Claim Number'}
              value={lookupValue}
              onChangeText={setLookupValue}
              placeholder={lookupMethod === 'policy' ? 'Enter policy number' : 'Enter claim number'}
              autoCapitalize="characters"
            />
            {lookupError ? <Text style={[styles.error, { color: colors.destructive }]}>{lookupError}</Text> : null}
            <PrimaryButton label="Submit" onPress={submitStatusLookup} />
          </SurfaceCard>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 15, gap: 13 },
  banner: { borderRadius: 13, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 9 },
  bannerText: { flex: 1, fontSize: 11, lineHeight: 16, fontWeight: '600' },
  body: { fontSize: 12, lineHeight: 18 },
  multiline: { minHeight: 98, textAlignVertical: 'top', paddingTop: 12 },
  error: { fontSize: 11, lineHeight: 15 },
  statusResult: { borderRadius: 10, padding: 10, flexDirection: 'row', alignItems: 'center', gap: 8 },
  lookupBackdrop: { flex: 1, justifyContent: 'center', paddingHorizontal: 24 },
  lookupCard: { borderRadius: 16, padding: 16, gap: 13 },
  lookupHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  lookupTitle: { flex: 1, fontSize: 15, fontWeight: '800' },
  lookupChoices: { gap: 10 },
  lookupChoice: { minHeight: 30, flexDirection: 'row', alignItems: 'center', gap: 8 },
  lookupChoiceText: { fontSize: 11, fontWeight: '600' },
  successCard: { alignItems: 'center', gap: 11, padding: 23 },
  successIcon: { width: 58, height: 58, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  successTitle: { fontSize: 19, fontWeight: '800' },
  note: { fontSize: 10, lineHeight: 15 },
  statusCard: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12 },
  statusIcon: { width: 39, height: 39, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  statusCopy: { flex: 1, gap: 3 },
  statusType: { fontSize: 12, fontWeight: '800' },
  statusState: { fontSize: 10, fontWeight: '700' },
  formCard: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 10 },
  viewButton: { minWidth: 58 },
});
