import type { ImageSourcePropType } from 'react-native';
import { ApiError, apiRequest } from './apiClient';
import { getConfiguredHomePath } from './endpoints';

export type BannerTarget =
  | 'policies'
  | 'nearby'
  | 'wellness'
  | 'stepathon'
  | 'motor-insurance'
  | 'health-plan'
  | 'claims'
  | 'renewal'
  | 'a-plus-calculator';

export type HomeBanner = {
  id: string;
  title?: string;
  description?: string;
  imageUrl?: string;
  imageSource?: ImageSourcePropType;
  icon?: string;
  ctaLabel?: string;
  target?: BannerTarget;
  actionType?: 'navigate' | 'none';
  isActive?: boolean;
  sortOrder?: number;
};

export type HomeResponse = {
  banners: HomeBanner[];
  quickActions?: unknown[];
  policySummary?: Record<string, unknown>;
  notifications?: unknown[];
  sections?: unknown[];
};

const demoHome: HomeResponse = {
  banners: [
    {
      id: 'home-protection',
      imageSource: require('../../assets/images/home-hero.png'),
      actionType: 'navigate',
      target: 'policies',
      isActive: true,
      sortOrder: 1,
    },
    {
      id: 'motor-cover',
      imageSource: require('../../assets/images/motor-hero.png'),
      actionType: 'navigate',
      target: 'motor-insurance',
      isActive: true,
      sortOrder: 2,
    },
    {
      id: 'policy-renewal',
      imageSource: require('../../assets/images/policy-renewal-hero.png'),
      actionType: 'navigate',
      target: 'renewal',
      isActive: true,
      sortOrder: 3,
    },
  ],
};

const delay = (milliseconds: number, signal?: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    const timer = setTimeout(resolve, milliseconds);
    signal?.addEventListener(
      'abort',
      () => {
        clearTimeout(timer);
        reject(new ApiError('The request was cancelled.', 'timeout'));
      },
      { once: true },
    );
  });

function normalizeResponse(data: HomeResponse): HomeResponse {
  if (!data || !Array.isArray(data.banners)) {
    throw new ApiError('Home service returned an invalid banner list.', 'invalid-response');
  }
  for (const banner of data.banners) {
    if (banner?.imageUrl) {
      let url: URL;
      try {
        url = new URL(banner.imageUrl);
      } catch {
        throw new ApiError('Home service returned an invalid banner image URL.', 'invalid-response');
      }
      if (url.protocol !== 'https:') {
        throw new ApiError('Home banner images must use a secure HTTPS URL.', 'invalid-response');
      }
    }
  }
  return {
    ...data,
    banners: data.banners
      .filter((banner) => banner && banner.isActive !== false)
      .sort((left, right) => (left.sortOrder ?? 0) - (right.sortOrder ?? 0)),
  };
}

export async function getHomeContent(signal?: AbortSignal): Promise<HomeResponse> {
  const configuredPath = getConfiguredHomePath();
  if (configuredPath) {
    const response = await apiRequest<HomeResponse>(configuredPath, { signal });
    return normalizeResponse(response);
  }

  const demoState = process.env.EXPO_PUBLIC_HOME_DEMO_STATE;
  if (demoState === 'loading') await delay(1200, signal);
  else await delay(350, signal);
  if (demoState === 'error') {
    throw new ApiError('Home content is unavailable right now.', 'network');
  }
  if (demoState === 'empty') return { banners: [] };
  return normalizeResponse(demoHome);
}
