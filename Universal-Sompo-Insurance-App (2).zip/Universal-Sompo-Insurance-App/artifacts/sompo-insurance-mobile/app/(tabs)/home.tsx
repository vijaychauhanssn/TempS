import React, { useState } from 'react';
import {
  Alert,
  Image,
  ImageBackground,
  ImageSourcePropType,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  AppPage,
  Avatar,
  Hairline,
  IconButton,
  OutlineButton,
  PrimaryButton,
  SectionHeading,
  SurfaceCard,
} from '@/components/AppUI';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

const buyItems = [
  { label: '4 Wheeler', image: require('../../assets/images/reference-icons/buy-car.png'), vehicle: 'Four Wheeler' },
  { label: '2 Wheeler', image: require('../../assets/images/reference-icons/buy-bike.png'), vehicle: 'Two Wheeler' },
  { label: 'Health', image: require('../../assets/images/reference-icons/buy-health.png') },
];

const moreItems = [
  { label: 'Watch your health', image: require('../../assets/images/reference-icons/watch-health.png'), route: '/(tabs)/wellness' as const },
  { label: 'Pollution Certificate', image: require('../../assets/images/reference-icons/pollution.png'), route: '/pollution-certificate' as const },
  { label: 'Check Challan', image: require('../../assets/images/reference-icons/challan.png'), route: '/my-challan' as const },
  { label: 'My Vehicle', image: require('../../assets/images/reference-icons/my-vehicle.png'), route: '/my-vehicle' as const },
  { label: 'Insurance Finder', image: require('../../assets/images/reference-icons/insurance-finder.png'), route: '/(tabs)/nearby' as const },
  { label: 'My Stepathon', image: require('../../assets/images/reference-icons/stepathon.png'), route: '/stepathon' as const },
  { label: 'Health Webinar', image: require('../../assets/images/reference-icons/health-webinar.png'), route: '/webinar' as const },
  { label: 'Be-Fit', image: require('../../assets/images/reference-icons/be-fit.png'), route: '/be-fit' as const },
];

const quickLinks = [
  { label: 'Renewal', image: require('../../assets/images/reference-icons/quick-renewal.png'), tone: 'pink', route: '/renewal' as const },
  { label: 'Health Claim', image: require('../../assets/images/reference-icons/quick-health-claim.png'), tone: 'rose', route: '/claims' as const },
  { label: 'Motor Claim', image: require('../../assets/images/reference-icons/quick-motor-claim.png'), tone: 'blue', route: '/claims' as const },
  { label: 'Health Premium Calculator', image: require('../../assets/images/reference-icons/quick-premium.png'), tone: 'gold', route: '/calculator' as const },
] as const;

const healthPlans = [
  { title: 'A Plus Health Insurance', detail: '4× cover · 15% direct discounts', icon: 'heart' as const, key: 'a-plus' },
  { title: 'Complete Healthcare', detail: 'Flexible family health cover', icon: 'people' as const, key: 'complete' },
  { title: 'Super Healthcare', detail: 'Cashless care across India', icon: 'medkit' as const, key: 'super' },
  { title: 'Arogya Sanjeevani', detail: 'Essential health protection', icon: 'shield-checkmark' as const, key: 'arogya' },
];

function HomeCategory({
  label,
  image,
  onPress,
  compact = false,
}: {
  label: string;
  image: ImageSourcePropType;
  onPress: () => void;
  compact?: boolean;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={({ pressed }) => [
        styles.categoryItem,
        { backgroundColor: compact ? 'transparent' : colors.white, borderColor: colors.border },
        compact && styles.compactCategory,
        pressed && styles.pressed,
      ]}
    >
      <View style={[styles.categoryIcon, compact && styles.compactCategoryIcon]}>
        <Image source={image} resizeMode="contain" style={styles.categoryImage} />
      </View>
      <Text numberOfLines={2} style={[styles.categoryLabel, { color: colors.foreground }]}>
        {label}
      </Text>
    </Pressable>
  );
}

function PolicyBenefit({
  icon,
  label,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
}) {
  const colors = useColors();
  return (
    <View style={styles.policyBenefit}>
      <Ionicons name={icon} size={12} color={colors.mutedForeground} />
      <Text style={[styles.policyBenefitText, { color: colors.mutedForeground }]}>{label}</Text>
    </View>
  );
}

function HomeDrawer({
  visible,
  onClose,
}: {
  visible: boolean;
  onClose: () => void;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { profile, logout, deleteLocalAccount } = useAppState();
  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;

  const go = (path: '/profile' | '/calculator' | '/resources' | '/faq' | '/contact') => {
    onClose();
    router.push(path);
  };

  const dial = async () => {
    try {
      await Linking.openURL('tel:1800224030');
    } catch {
      Alert.alert('Emergency support', 'Call 1800-22-4030 for assistance.');
    }
  };

  const removeAccount = () => {
    Alert.alert(
      'Delete demo account?',
      'This removes the profile and demo sign-in saved on this device.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete account',
          style: 'destructive',
          onPress: () => {
            void deleteLocalAccount();
            onClose();
            router.replace('/welcome');
          },
        },
      ],
    );
  };

  const group = (
    title: string,
    items: {
      label: string;
      icon: keyof typeof Ionicons.glyphMap;
      onPress: () => void;
    }[],
  ) => (
    <View style={[styles.drawerGroup, { backgroundColor: colors.white }]}>
      <Text style={[styles.drawerGroupTitle, { color: colors.foreground }]}>{title}</Text>
      {items.map((item, index) => (
        <React.Fragment key={item.label}>
          {index > 0 ? <Hairline /> : null}
          <Pressable
            onPress={item.onPress}
            accessibilityRole="button"
            style={({ pressed }) => [styles.drawerItem, pressed && styles.pressed]}
          >
            <Ionicons name={item.icon} size={19} color={colors.mutedForeground} />
            <Text style={[styles.drawerItemText, { color: colors.foreground }]}>
              {item.label}
            </Text>
            <Ionicons name="chevron-forward" size={15} color={colors.mutedForeground} />
          </Pressable>
        </React.Fragment>
      ))}
    </View>
  );

  return (
    <Modal
      transparent
      animationType="fade"
      visible={visible}
      onRequestClose={onClose}
      statusBarTranslucent
    >
      <View style={styles.drawerOverlay}>
        <Pressable
          onPress={onClose}
          accessibilityLabel="Close menu"
          style={[StyleSheet.absoluteFill, { backgroundColor: colors.scrim }]}
        />
        <View
          style={[
            styles.drawer,
            {
              paddingTop: topInset + 10,
              paddingBottom: Math.max(insets.bottom, 12),
              backgroundColor: colors.screen,
              borderTopRightRadius: 28,
              borderBottomRightRadius: 28,
            },
          ]}
        >
          <View style={[styles.drawerProfile, { backgroundColor: colors.white, borderColor: colors.border }]}>
            <Avatar name={profile.fullName} size={54} />
            <View style={styles.drawerProfileCopy}>
              <Text numberOfLines={1} style={[styles.drawerName, { color: colors.foreground }]}>
                {profile.fullName}
              </Text>
              <Text numberOfLines={1} style={[styles.drawerEmail, { color: colors.mutedForeground }]}>
                {profile.email}
              </Text>
            </View>
            <Pressable
              onPress={() => go('/profile')}
              accessibilityRole="button"
              accessibilityLabel="Edit profile"
            >
              <Ionicons name="create-outline" size={21} color={colors.primary} />
            </Pressable>
          </View>

          <ScrollView
            style={styles.drawerScroll}
            contentContainerStyle={styles.drawerScrollContent}
            showsVerticalScrollIndicator={false}
          >
            {group('Account', [
              { label: 'My Profile', icon: 'person-circle-outline', onPress: () => go('/profile') },
              { label: 'My Policies', icon: 'document-text-outline', onPress: () => { onClose(); router.push('/policies'); } },
            ])}
            {group('App Features', [
              { label: 'Offline Calculator', icon: 'calculator-outline', onPress: () => go('/calculator') },
              { label: 'Resources', icon: 'book-outline', onPress: () => go('/resources') },
              { label: 'Privacy Policy', icon: 'lock-closed-outline', onPress: () => Alert.alert('Privacy Policy', 'This demo stores profile and policy details only on this device. No insurer service is connected.') },
              { label: 'Terms & Conditions', icon: 'document-text-outline', onPress: () => Alert.alert('Terms & Conditions', 'This is a visual demo. Insurance information and calculations are illustrative only.') },
            ])}
            {group('Support', [
              { label: 'Contact Us', icon: 'call-outline', onPress: () => go('/contact') },
              { label: 'Rate Us', icon: 'star-outline', onPress: () => Alert.alert('Thank you', 'App ratings are not connected in this demo.') },
              { label: 'FAQ', icon: 'help-circle-outline', onPress: () => go('/faq') },
              { label: 'Emergency', icon: 'medkit-outline', onPress: () => void dial() },
            ])}
          </ScrollView>

          <View style={styles.drawerActions}>
            <PrimaryButton
              label="Logout"
              icon="chevron-forward"
              onPress={() => {
                void logout();
                onClose();
                router.replace('/welcome');
              }}
            />
            <OutlineButton label="Delete Account" icon="trash-outline" onPress={removeAccount} />
            <Text style={[styles.version, { color: colors.mutedForeground }]}>Version · 2.86</Text>
          </View>
        </View>
      </View>
    </Modal>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const { profile, policies } = useAppState();
  const [drawerVisible, setDrawerVisible] = useState(false);

  const openInsurance = (vehicle?: string) => {
    if (vehicle) {
      router.push({ pathname: '/motor-insurance', params: { vehicle } });
    } else {
      router.push({ pathname: '/health-buy', params: { plan: 'complete' } });
    }
  };

  return (
    <>
      <AppPage contentStyle={styles.homeContent}>
        <View style={styles.homeHeader}>
          <Pressable
            onPress={() => setDrawerVisible(true)}
            accessibilityRole="button"
            accessibilityLabel="Open menu"
            style={styles.menuButton}
          >
            <Ionicons name="menu" size={26} color={colors.foreground} />
          </Pressable>
          <View style={styles.greeting}>
            <Text style={[styles.greetingSmall, { color: colors.mutedForeground }]}>Hi,</Text>
            <Text numberOfLines={1} style={[styles.greetingName, { color: colors.foreground }]}>
              {profile.fullName}
            </Text>
          </View>
          <Avatar name={profile.fullName} size={39} />
          <IconButton
            name="notifications-outline"
            label="Notifications"
            badge
            onPress={() => router.push('/notifications')}
          />
        </View>

        <ImageBackground
          source={require('../../assets/images/home-hero.png')}
          imageStyle={styles.promoImage}
          style={styles.promoHero}
        >
          <LinearGradient
            colors={[colors.primaryDeep, 'transparent']}
            start={{ x: 0, y: 1 }}
            end={{ x: 0.75, y: 0 }}
            style={styles.promoShade}
          />
          <View style={styles.promoCopy}>
            <Text style={[styles.promoEyebrow, { color: colors.white }]}>PROTECTION FOR WHAT MATTERS</Text>
            <Text style={[styles.promoTitle, { color: colors.white }]}>Cover for every chapter.</Text>
            <Pressable
              onPress={() => router.push('/policies')}
              style={({ pressed }) => [styles.promoButton, { backgroundColor: colors.white }, pressed && styles.pressed]}
            >
              <Text style={[styles.promoButtonText, { color: colors.primary }]}>Explore insurance</Text>
              <Ionicons name="arrow-forward" size={14} color={colors.primary} />
            </Pressable>
          </View>
        </ImageBackground>

        <SurfaceCard style={styles.policyPanel}>
          <View style={styles.policyPanelTop}>
            <View style={styles.policyPanelCopy}>
              <Text style={[styles.policyPanelTitle, { color: colors.foreground }]}>My Policy</Text>
              <Text style={[styles.policyPanelDetail, { color: colors.mutedForeground }]}>
                Access your USGIC policy in one place for downloads, renewals, claims and more.
              </Text>
              <Text style={[styles.policyCount, { color: colors.primary }]}>
                {policies.length} {policies.length === 1 ? 'Policy' : 'Policies'}
              </Text>
            </View>
            <Image source={require('../../assets/images/reference-icons/policy-family.png')} resizeMode="contain" style={styles.policyArtwork} />
          </View>
          <View style={styles.policyActions}>
            <Pressable
              onPress={() => router.push('/policies')}
              accessibilityRole="button"
              style={({ pressed }) => [styles.policyAction, { borderColor: colors.primary }, pressed && styles.pressed]}
            >
              <Ionicons name="document-text-outline" size={16} color={colors.primary} />
              <Text style={[styles.policyActionText, { color: colors.primary }]}>View Policy</Text>
            </Pressable>
            <Pressable
              onPress={() => router.push('/add-policy')}
              accessibilityRole="button"
              style={({ pressed }) => [styles.policyAction, { backgroundColor: colors.primary }, pressed && styles.pressed]}
            >
              <Ionicons name="add" size={18} color={colors.white} />
              <Text style={[styles.policyActionText, { color: colors.white }]}>Add</Text>
            </Pressable>
          </View>
          <View style={styles.policyBenefits}>
            <PolicyBenefit icon="lock-closed-outline" label="Secure & Safe" />
            <PolicyBenefit icon="options-outline" label="Manage easily" />
            <PolicyBenefit icon="flash-outline" label="Quick access" />
          </View>
        </SurfaceCard>

        <View style={styles.section}>
          <SectionHeading title="Buy Insurance" actionLabel="See all" onAction={() => router.push('/policies')} />
          <View style={styles.buyGrid}>
            {buyItems.map((item) => (
              <HomeCategory
                key={item.label}
                label={item.label}
                image={item.image}
                onPress={() => openInsurance(item.vehicle)}
              />
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <SectionHeading title="More Than Just Insurance" actionLabel="Explore" onAction={() => router.push('/nearby')} />
          <SurfaceCard style={styles.moreGrid}>
            {moreItems.map((item) => (
              <HomeCategory
                key={item.label}
                label={item.label}
                image={item.image}
                compact
                onPress={() => router.push(item.route)}
              />
            ))}
          </SurfaceCard>
        </View>

        <View style={styles.section}>
          <SectionHeading title="Quick Links" />
          <View style={styles.quickGrid}>
            {quickLinks.map((item) => (
              <Pressable
                key={item.label}
                onPress={() => router.push(item.route)}
                style={({ pressed }) => [
                  styles.quickLink,
                  { backgroundColor: colors[item.tone] },
                  pressed && styles.pressed,
                ]}
              >
                <Image source={item.image} resizeMode="contain" style={styles.quickLinkImage} />
                <Text style={[styles.quickLabel, { color: colors.foreground }]}>{item.label}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <SectionHeading title="Insurance Plans That Are Made for You" actionLabel="View all" onAction={() => router.push('/health-plan?plan=a-plus')} />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.horizontalCards}>
            {healthPlans.map((plan, index) => (
              <PlanPreview
                key={plan.key}
                title={plan.title}
                description={plan.detail}
                icon={plan.icon}
                color={index % 2 === 0 ? colors.health : colors.vehicle}
                onPress={() => router.push({ pathname: '/health-plan', params: { plan: plan.key } })}
              />
            ))}
          </ScrollView>
        </View>

        <SurfaceCard style={styles.trustCard}>
          <View style={styles.trustHeading}>
            <Ionicons name="shield-checkmark" size={18} color={colors.primary} />
            <Text style={[styles.trustTitle, { color: colors.foreground }]}>Trusted by customers across India</Text>
          </View>
          <View style={styles.trustStats}>
            <TrustStat icon="people-outline" label="Care that puts you first" />
            <TrustStat icon="business-outline" label="Wide hospital network" />
            <TrustStat icon="headset-outline" label="Here when you need us" />
          </View>
        </SurfaceCard>

        <View style={styles.section}>
          <SectionHeading title="What Our Customers Are Saying" actionLabel="Read more" onAction={() => router.push('/faq')} />
          <SurfaceCard style={styles.testimonial}>
            <View style={styles.stars}>
              {Array.from({ length: 5 }, (_, index) => (
                <Ionicons key={index} name="star" size={15} color={colors.gold} />
              ))}
            </View>
            <Text style={[styles.quote, { color: colors.foreground }]}>
              “Easy to find the information I need and manage my cover in one place.”
            </Text>
            <Text style={[styles.quoteBy, { color: colors.mutedForeground }]}>Universal Sompo app user</Text>
          </SurfaceCard>
        </View>

        <View style={styles.section}>
          <SectionHeading title="Insightful Blogs" actionLabel="See all" onAction={() => router.push('/resources')} />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.horizontalCards}>
            <StoryCard
              title="Understanding health cover"
              category="HEALTH GUIDES"
              image={require('../../assets/images/resource-healthcare.png')}
              onPress={() => router.push('/resources')}
            />
            <StoryCard
              title="A clearer claims journey"
              category="INSURANCE TIPS"
              image={require('../../assets/images/resource-claimform.png')}
              onPress={() => router.push('/claims')}
            />
            <StoryCard
              title="Protecting your everyday"
              category="WELLNESS"
              image={require('../../assets/images/resource-supreme.png')}
              onPress={() => router.push('/resources')}
            />
          </ScrollView>
        </View>

        <View style={styles.section}>
          <SectionHeading title="Tutorial Videos" actionLabel="See all" onAction={() => router.push('/resources')} />
          <Pressable onPress={() => router.push('/webinar')} style={({ pressed }) => [pressed && styles.pressed]}>
            <ImageBackground
              source={require('../../assets/images/webinar-banner.png')}
              imageStyle={styles.webinarImage}
              style={styles.webinarCard}
            >
              <View style={[styles.playButton, { backgroundColor: colors.white }]}>
                <Ionicons name="play" size={20} color={colors.primary} />
              </View>
              <View style={[styles.webinarTextBlock, { backgroundColor: colors.scrim }]}>
                <Text style={[styles.webinarEyebrow, { color: colors.white }]}>HEALTH WEBINAR</Text>
                <Text style={[styles.webinarTitle, { color: colors.white }]}>Lifestyle habits for stress resilience</Text>
              </View>
            </ImageBackground>
          </Pressable>
        </View>

        <Text style={[styles.demoNote, { color: colors.mutedForeground }]}>
          Sample policies and product information are for demonstration only.
        </Text>
      </AppPage>
      <HomeDrawer visible={drawerVisible} onClose={() => setDrawerVisible(false)} />
    </>
  );
}

function PlanPreview({
  title,
  description,
  icon,
  color,
  onPress,
}: {
  title: string;
  description: string;
  icon: keyof typeof Ionicons.glyphMap;
  color: string;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.planCard,
        { backgroundColor: colors.card, borderColor: colors.border, shadowColor: colors.shadow },
        pressed && styles.pressed,
      ]}
    >
      <View style={[styles.planIcon, { backgroundColor: color }]}>
        <Ionicons name={icon} size={23} color={colors.primaryDeep} />
      </View>
      <Text numberOfLines={2} style={[styles.planTitle, { color: colors.foreground }]}>{title}</Text>
      <Text numberOfLines={2} style={[styles.planDescription, { color: colors.mutedForeground }]}>{description}</Text>
      <Text style={[styles.planLink, { color: colors.primary }]}>View plan  ›</Text>
    </Pressable>
  );
}

function TrustStat({
  icon,
  label,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
}) {
  const colors = useColors();
  return (
    <View style={styles.trustStat}>
      <Ionicons name={icon} size={18} color={colors.primary} />
      <Text style={[styles.trustStatLabel, { color: colors.mutedForeground }]}>{label}</Text>
    </View>
  );
}

function StoryCard({
  title,
  category,
  image,
  onPress,
}: {
  title: string;
  category: string;
  image: number;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.storyCard,
        { backgroundColor: colors.card, borderColor: colors.border },
        pressed && styles.pressed,
      ]}
    >
      <Image source={image} style={styles.storyImage} />
      <Text style={[styles.storyCategory, { color: colors.primary }]}>{category}</Text>
      <Text numberOfLines={2} style={[styles.storyTitle, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.storyLink, { color: colors.primary }]}>Read more  ›</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  homeContent: { paddingHorizontal: 13, gap: 14, paddingBottom: 18 },
  homeHeader: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  menuButton: { width: 31, alignItems: 'flex-start', justifyContent: 'center' },
  greeting: { flex: 1, gap: 1 },
  greetingSmall: { fontSize: 10, fontWeight: '600' },
  greetingName: { fontSize: 14, fontWeight: '800' },
  promoHero: {
    height: 126,
    borderRadius: 15,
    overflow: 'hidden',
    justifyContent: 'flex-end',
  },
  promoImage: { borderRadius: 15 },
  promoShade: { position: 'absolute', top: 0, right: 0, bottom: 0, left: 0, opacity: 0.82 },
  promoCopy: { gap: 4, paddingHorizontal: 13, paddingBottom: 12, width: '78%' },
  promoEyebrow: { fontSize: 8, fontWeight: '800', letterSpacing: 0.8 },
  promoTitle: { fontSize: 19, lineHeight: 22, fontWeight: '800' },
  promoButton: {
    alignSelf: 'flex-start',
    borderRadius: 15,
    minHeight: 28,
    paddingHorizontal: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    marginTop: 3,
  },
  promoButtonText: { fontSize: 10, fontWeight: '800' },
  policyPanel: { padding: 10, gap: 7, borderRadius: 17 },
  policyPanelTop: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  policyPanelCopy: { flex: 1, gap: 3 },
  policyPanelTitle: { fontSize: 16, fontWeight: '800' },
  policyPanelDetail: { fontSize: 9, lineHeight: 13 },
  policyCount: { fontSize: 8, fontWeight: '800' },
  policyArtwork: { width: 103, height: 82 },
  policyActions: { flexDirection: 'row', gap: 8 },
  policyAction: {
    flex: 1,
    minHeight: 31,
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
  },
  policyActionText: { fontSize: 10, fontWeight: '800' },
  policyBenefits: { flexDirection: 'row', justifyContent: 'space-between', gap: 4, paddingTop: 2 },
  policyBenefit: { flex: 1, alignItems: 'center', gap: 2 },
  policyBenefitText: { fontSize: 7, lineHeight: 9, textAlign: 'center' },
  section: { gap: 7 },
  buyGrid: { flexDirection: 'row', justifyContent: 'space-between', gap: 7 },
  categoryItem: {
    flex: 1,
    minHeight: 78,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 2,
    padding: 4,
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
  },
  categoryIcon: {
    width: 42,
    height: 42,
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoryImage: { width: '100%', height: '100%', borderRadius: 21 },
  categoryLabel: { fontSize: 9, textAlign: 'center', fontWeight: '700', lineHeight: 12 },
  moreGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingVertical: 8,
    paddingHorizontal: 4,
    gap: 3,
  },
  compactCategory: { flexBasis: '23%', minHeight: 70, borderWidth: 0 },
  compactCategoryIcon: { width: 41, height: 41 },
  quickGrid: { flexDirection: 'row', gap: 5 },
  quickLink: {
    flex: 1,
    minWidth: 0,
    minHeight: 70,
    borderRadius: 13,
    paddingHorizontal: 4,
    paddingVertical: 6,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 3,
  },
  quickLinkImage: { width: 34, height: 34, borderRadius: 12 },
  quickLabel: { fontSize: 7, fontWeight: '700', lineHeight: 9, textAlign: 'center' },
  horizontalCards: { gap: 9, paddingRight: 8 },
  planCard: {
    width: 165,
    minHeight: 146,
    borderRadius: 15,
    padding: 11,
    borderWidth: StyleSheet.hairlineWidth,
    gap: 5,
    shadowOpacity: 0.05,
    shadowRadius: 7,
    shadowOffset: { width: 0, height: 3 },
    elevation: 2,
  },
  planIcon: { width: 36, height: 36, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  planTitle: { fontSize: 12, fontWeight: '800' },
  planDescription: { fontSize: 10, lineHeight: 14 },
  planLink: { fontSize: 10, fontWeight: '800', marginTop: 1 },
  trustCard: { padding: 13, gap: 12 },
  trustHeading: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  trustTitle: { flex: 1, fontSize: 13, fontWeight: '800' },
  trustStats: { flexDirection: 'row', justifyContent: 'space-between', gap: 7 },
  trustStat: { flex: 1, alignItems: 'center', gap: 5 },
  trustStatLabel: { fontSize: 9, lineHeight: 12, textAlign: 'center' },
  testimonial: { gap: 7, padding: 14 },
  stars: { flexDirection: 'row', gap: 2 },
  quote: { fontSize: 13, lineHeight: 19, fontWeight: '500' },
  quoteBy: { fontSize: 10, fontWeight: '600' },
  storyCard: {
    width: 155,
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
    padding: 8,
    gap: 5,
    overflow: 'hidden',
  },
  storyImage: { width: '100%', height: 84, borderRadius: 9, resizeMode: 'cover' },
  storyCategory: { fontSize: 8, fontWeight: '800', letterSpacing: 0.6 },
  storyTitle: { minHeight: 34, fontSize: 11, lineHeight: 15, fontWeight: '700' },
  storyLink: { fontSize: 9, fontWeight: '800' },
  webinarCard: { height: 122, borderRadius: 15, overflow: 'hidden', justifyContent: 'flex-end' },
  webinarImage: { borderRadius: 15 },
  playButton: {
    position: 'absolute',
    right: 12,
    top: 12,
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
  },
  webinarTextBlock: { padding: 10 },
  webinarEyebrow: { fontSize: 8, fontWeight: '800', letterSpacing: 0.8 },
  webinarTitle: { fontSize: 13, lineHeight: 17, fontWeight: '800' },
  demoNote: { fontSize: 9, lineHeight: 14, textAlign: 'center', paddingHorizontal: 10 },
  drawerOverlay: { flex: 1, flexDirection: 'row' },
  drawer: { width: '84%', maxWidth: 355, height: '100%', paddingHorizontal: 12, gap: 10 },
  drawerProfile: { minHeight: 72, borderRadius: 17, borderWidth: 1, padding: 10, alignItems: 'center', flexDirection: 'row', gap: 10 },
  drawerProfileCopy: { flex: 1, gap: 3 },
  drawerName: { fontSize: 14, fontWeight: '800' },
  drawerEmail: { fontSize: 10 },
  drawerScroll: { flex: 1 },
  drawerScrollContent: { gap: 10, paddingBottom: 4 },
  drawerGroup: { borderRadius: 16, paddingHorizontal: 12, paddingTop: 11, paddingBottom: 4, shadowOpacity: 0.04, shadowRadius: 8, shadowOffset: { width: 0, height: 3 } },
  drawerGroupTitle: { fontSize: 13, fontWeight: '800', marginBottom: 2 },
  drawerItem: { minHeight: 39, flexDirection: 'row', alignItems: 'center', gap: 10 },
  drawerItemText: { flex: 1, fontSize: 13, fontWeight: '600' },
  drawerActions: { gap: 7 },
  version: { textAlign: 'center', fontSize: 10, letterSpacing: 1.1, paddingTop: 2 },
  pressed: { opacity: 0.76, transform: [{ scale: 0.99 }] },
});
