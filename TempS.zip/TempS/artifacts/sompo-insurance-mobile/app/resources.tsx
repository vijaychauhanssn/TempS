import React from 'react';
import { Image, ImageSourcePropType, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppHeader, AppPage, PrimaryButton } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

const resources: {
  title: string;
  subtitle: string;
  image: ImageSourcePropType;
  plan: string;
}[] = [
  {
    title: 'A Plus Health Insurance Leaflet',
    subtitle: 'A quick guide to health cover',
    image: require('../assets/images/resource-healthcare.png'),
    plan: 'a-plus',
  },
  {
    title: 'CHI Brochure',
    subtitle: 'Understand health insurance benefits',
    image: require('../assets/images/resource-claimform.png'),
    plan: 'complete',
  },
  {
    title: 'Supreme Healthcare Onepage',
    subtitle: 'Explore sample plan information',
    image: require('../assets/images/resource-supreme.png'),
    plan: 'super',
  },
];

export default function ResourcesScreen() {
  const colors = useColors();
  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="Resource Video’s" onBack={() => router.back()} />
      <Text style={[styles.intro, { color: colors.mutedForeground }]}>
        Helpful information to make insurance simpler.
      </Text>
      <View style={styles.grid}>
        {resources.map((resource) => (
          <View
            key={resource.title}
            style={[
              styles.resourceCard,
              {
                backgroundColor: colors.white,
                borderColor: colors.border,
                shadowColor: colors.shadow,
              },
            ]}
          >
            <Image source={resource.image} resizeMode="cover" style={styles.resourceImage} />
            <View style={styles.resourceText}>
              <Text numberOfLines={2} style={[styles.resourceTitle, { color: colors.foreground }]}>
                {resource.title}
              </Text>
              <Text numberOfLines={2} style={[styles.resourceSubtitle, { color: colors.mutedForeground }]}>
                {resource.subtitle}
              </Text>
            </View>
            <PrimaryButton
              label="View details"
              onPress={() => router.push({ pathname: '/health-plan', params: { plan: resource.plan } })}
              style={styles.resourceButton}
            />
          </View>
        ))}
      </View>
      <Pressable
        onPress={() => router.push('/webinar')}
        style={[styles.webinarLink, { backgroundColor: colors.primaryWash }]}
      >
        <View style={styles.webinarCopy}>
          <Text style={[styles.webinarEyebrow, { color: colors.primary }]}>HEALTH WEBINAR</Text>
          <Text style={[styles.webinarTitle, { color: colors.foreground }]}>Lifestyle habits for stress resilience</Text>
          <Text style={[styles.webinarDetail, { color: colors.mutedForeground }]}>05 Nov 2026 · Join online</Text>
        </View>
        <Ionicons name="play-circle" size={27} color={colors.primary} />
      </Pressable>
      <Pressable onPress={() => router.push('/faq')} style={styles.faqLink}>
        <Text style={[styles.faqText, { color: colors.primary }]}>Browse FAQs instead</Text>
      </Pressable>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 16, gap: 12 },
  intro: { fontSize: 13, lineHeight: 19, marginTop: -6 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 11 },
  resourceCard: {
    width: '48%',
    minHeight: 202,
    borderRadius: 18,
    borderWidth: StyleSheet.hairlineWidth,
    overflow: 'hidden',
    padding: 8,
    gap: 6,
    shadowOpacity: 0.06,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
    elevation: 2,
  },
  resourceImage: { width: '100%', height: 92, borderRadius: 12 },
  resourceText: { flex: 1, gap: 3, paddingHorizontal: 3 },
  resourceTitle: { fontSize: 12, fontWeight: '800', lineHeight: 16 },
  resourceSubtitle: { fontSize: 10, lineHeight: 14 },
  resourceButton: { minHeight: 35, borderRadius: 19 },
  faqLink: { alignSelf: 'center', padding: 10 },
  faqText: { fontSize: 12, fontWeight: '700' },
  webinarLink: { minHeight: 66, borderRadius: 13, padding: 10, flexDirection: 'row', alignItems: 'center', gap: 8 },
  webinarCopy: { flex: 1, gap: 3 },
  webinarEyebrow: { fontSize: 8, fontWeight: '800', letterSpacing: 0.8 },
  webinarTitle: { fontSize: 11, fontWeight: '800' },
  webinarDetail: { fontSize: 9 },
});
