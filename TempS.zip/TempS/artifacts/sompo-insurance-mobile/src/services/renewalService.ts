export function createDemoRenewalReference() {
  return `RENEW-${Date.now().toString().slice(-6)}`;
}
