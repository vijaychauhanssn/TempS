export const colors = {
  primary: '#B8475D',
  primaryDark: '#963348',
  roseLight: '#F8EDEF',
  background: '#F7F7F8',
  surface: '#FFFFFF',
  text: '#24242A',
  muted: '#777780',
  border: '#E6E3E5',
  green: '#25845B',
  amber: '#B9791E',
};