import React, { useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import {
  AppHeader,
  AppPage,
  LabeledInput,
  PrimaryButton,
  SectionHeading,
  SurfaceCard,
} from '@/components/AppUI';
import { DatePickerField, isValidDateValue } from '@/components/FormFields';
import { useColors } from '@/hooks/useColors';

const demoClaims = [
  { id: 'CLM-240815', type: 'Health Claim', state: 'Documents reviewed', icon: 'checkmark-circle-outline' as const },
  { id: 'CLM-240921', type: 'Motor Claim', state: 'Under assessment', icon: 'time-outline' as const },
];

export default function ClaimActionScreen() {
  const colors = useColors();
  const { action = 'status', claimType = 'Health' } = useLocalSearchParams<{
    action?: string;
    claimType?: string;
  }>();
  const [incidentDate, setIncidentDate] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');
  const [reference, setReference] = useState('');

  const title =
    action === 'initiate'
      ? 'Claim Intimation'
      : action === 'forms'
        ? 'Claim Forms'
        : 'Claim Status';

  const submitIntimation = () => {
    if (!isValidDateValue(incidentDate) || description.trim().length < 10) {
      setError('Choose the incident date and add at least 10 characters describing what happened.');
      return;
    }
    setError('');
    setReference(`DEMO-${Date.now().toString().slice(-6)}`);
  };

  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title={title} onBack={() => router.back()} />
      {action === 'initiate' ? (
        reference ? (
          <SurfaceCard style={styles.successCard}>
            <View style={[styles.successIcon, { backgroundColor: colors.primaryWash }]}>
              <Ionicons name="checkmark" size={30} color={colors.success} />
            </View>
            <Text style={[styles.successTitle, { color: colors.foreground }]}>Intimation saved</Text>
            <Text style={[styles.body, { color: colors.mutedForeground }]}>
              Demo reference number: {reference}
            </Text>
            <Text style={[styles.note, { color: colors.mutedForeground }]}>
              This was saved only for this screen and was not sent to the insurer.
            </Text>
            <PrimaryButton label="Back to claims" icon="arrow-forward" onPress={() => router.replace('/claims')} />
          </SurfaceCard>
        ) : (
          <>
            <View style={[styles.banner, { backgroundColor: colors.primaryWash }]}>
              <Ionicons name="document-text-outline" size={22} color={colors.primary} />
              <Text style={[styles.bannerText, { color: colors.foreground }]}>
                {claimType} claim · provide a few details to create a local demo intimation.
              </Text>
            </View>
            <DatePickerField
              label="Incident date *"
              value={incidentDate}
              onChange={setIncidentDate}
              displayFormat="DD/MM/YYYY"
              minDate={new Date(1920, 0, 1)}
              maxDate={new Date()}
              testID="claim-incident-date"
            />
            <LabeledInput
              label="What happened? *"
              value={description}
              onChangeText={setDescription}
              placeholder="Briefly describe the incident"
              multiline
              style={styles.multiline}
            />
            {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
            <PrimaryButton label="Submit demo intimation" icon="arrow-forward" onPress={submitIntimation} />
          </>
        )
      ) : null}

      {action === 'status' ? (
        <>
          <Text style={[styles.body, { color: colors.mutedForeground }]}>
            Sample claim updates are shown below. Your live claim status is not connected.
          </Text>
          <SectionHeading title="Recent claims" />
          {demoClaims.map((claim) => (
            <SurfaceCard key={claim.id} style={styles.statusCard}>
              <View style={[styles.statusIcon, { backgroundColor: colors.primaryWash }]}>
                <Ionicons name={claim.icon} size={21} color={colors.primary} />
              </View>
              <View style={styles.statusCopy}>
                <Text style={[styles.statusType, { color: colors.foreground }]}>{claim.type}</Text>
                <Text style={[styles.note, { color: colors.mutedForeground }]}>{claim.id}</Text>
                <Text style={[styles.statusState, { color: colors.primary }]}>{claim.state}</Text>
              </View>
              <Ionicons name="chevron-forward" size={17} color={colors.mutedForeground} />
            </SurfaceCard>
          ))}
          <PrimaryButton label="Start a claim" icon="arrow-forward" onPress={() => router.replace('/claims')} />
        </>
      ) : null}

      {action === 'forms' ? (
        <>
          <Text style={[styles.body, { color: colors.mutedForeground }]}>
            Choose a sample checklist to review. Official claim forms are provided by the insurer.
          </Text>
          {[
            { name: 'Health Claim Form', detail: 'Hospitalization and medical expense checklist' },
            { name: 'Motor Claim Form', detail: 'Accident and vehicle damage checklist' },
            { name: 'Claim Documents Checklist', detail: 'Documents commonly requested for review' },
          ].map((form) => (
            <SurfaceCard key={form.name} style={styles.formCard}>
              <View style={[styles.statusIcon, { backgroundColor: colors.primaryWash }]}>
                <Ionicons name="document-text-outline" size={20} color={colors.primary} />
              </View>
              <View style={styles.statusCopy}>
                <Text style={[styles.statusType, { color: colors.foreground }]}>{form.name}</Text>
                <Text style={[styles.note, { color: colors.mutedForeground }]}>{form.detail}</Text>
              </View>
              <PrimaryButton
                label="View"
                onPress={() => Alert.alert(form.name, `${form.detail}.\n\nThis demonstration does not contain official insurer forms.`)}
                style={styles.viewButton}
              />
            </SurfaceCard>
          ))}
        </>
      ) : null}
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 15, gap: 13 },
  banner: { borderRadius: 13, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 9 },
  bannerText: { flex: 1, fontSize: 11, lineHeight: 16, fontWeight: '600' },
  body: { fontSize: 12, lineHeight: 18 },
  multiline: { minHeight: 98, textAlignVertical: 'top', paddingTop: 12 },
  error: { fontSize: 11, lineHeight: 15 },
  successCard: { alignItems: 'center', gap: 11, padding: 23 },
  successIcon: { width: 58, height: 58, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  successTitle: { fontSize: 19, fontWeight: '800' },
  note: { fontSize: 10, lineHeight: 15 },
  statusCard: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12 },
  statusIcon: { width: 39, height: 39, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  statusCopy: { flex: 1, gap: 3 },
  statusType: { fontSize: 12, fontWeight: '800' },
  statusState: { fontSize: 10, fontWeight: '700' },
  formCard: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 10 },
  viewButton: { minWidth: 58 },
});
