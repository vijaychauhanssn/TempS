# Universal Sompo Insurance

Cross-platform Expo app based on the supplied Universal Sompo mobile screen references.

## Run the app

```sh
pnpm --filter @workspace/sompo-insurance-mobile run dev
```

## Check the app

```sh
pnpm --filter @workspace/sompo-insurance-mobile run typecheck
```

See [replit.md](replit.md) for the app structure, demo behavior, and workspace commands.