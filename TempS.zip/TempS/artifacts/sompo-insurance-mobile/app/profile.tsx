import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppHeader, AppPage, Avatar, Hairline, SectionHeading, SurfaceCard } from '@/components/AppUI';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

const details: { label: string; field: keyof ReturnType<typeof useAppState>['profile'] }[] = [
  { label: 'Full Name', field: 'fullName' },
  { label: 'E-mail ID', field: 'email' },
  { label: 'Mobile', field: 'mobile' },
  { label: 'Gender', field: 'gender' },
  { label: 'Date of Birth', field: 'dateOfBirth' },
  { label: 'Blood Group', field: 'bloodGroup' },
  { label: 'Height', field: 'height' },
  { label: 'Weight', field: 'weight' },
  { label: 'Daily Activity', field: 'dailyActivity' },
  { label: 'Emergency contact person', field: 'emergencyName' },
  { label: 'Emergency contact', field: 'emergencyPhone' },
];

export default function ProfileScreen() {
  const colors = useColors();
  const { profile } = useAppState();
  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="Profile" onBack={() => router.back()} />
      <View style={[styles.profileHero, { backgroundColor: colors.primaryPale }]}>
        <View style={styles.profileIdentity}>
          <Avatar name={profile.fullName} size={70} />
          <View style={styles.identityCopy}>
            <Text style={[styles.hello, { color: colors.primary }]}>Hello</Text>
            <Text style={[styles.name, { color: colors.foreground }]}>
              {profile.fullName}
            </Text>
            <Text style={[styles.email, { color: colors.mutedForeground }]}>
              {profile.email}
            </Text>
          </View>
          <Pressable
            onPress={() => router.push('/profile-edit')}
            accessibilityRole="button"
            accessibilityLabel="Edit profile"
            style={({ pressed }) => [
              styles.editButton,
              { backgroundColor: colors.white, borderColor: colors.primary },
              pressed && styles.pressed,
            ]}
          >
            <Text style={[styles.editText, { color: colors.primary }]}>Edit</Text>
            <Ionicons name="create-outline" size={16} color={colors.primary} />
          </Pressable>
        </View>
        <View style={styles.progressRow}>
          <View style={[styles.progressTrack, { backgroundColor: colors.white }]}>
            <View
              style={[
                styles.progressFill,
                { width: '60%', backgroundColor: colors.primary },
              ]}
            />
          </View>
          <Text style={[styles.progressLabel, { color: colors.primaryDeep }]}>
            60%
          </Text>
        </View>
        <Text style={[styles.profileHint, { color: colors.foreground }]}>
          Complete your profile to keep your insurance information organised.
        </Text>
      </View>

      <SurfaceCard style={styles.vaultCard}>
        <View style={styles.vaultHeader}>
          <View style={styles.vaultTitleBlock}>
            <Ionicons name="shield-checkmark-outline" size={22} color={colors.primary} />
            <Text style={[styles.vaultTitle, { color: colors.foreground }]}>
              Insurance Vault
            </Text>
          </View>
          <Pressable
            onPress={() => router.push('/policies')}
            style={[styles.policyPill, { borderColor: colors.primary }]}
            accessibilityRole="button"
          >
            <Text style={[styles.policyPillText, { color: colors.primary }]}>
              0 Policy
            </Text>
          </Pressable>
        </View>
        <Hairline />
        {details.map((item) => (
          <View key={item.field}>
            <View style={styles.detailRow}>
              <Text style={[styles.detailLabel, { color: colors.foreground }]}>
                {item.label}
              </Text>
              <Text
                style={[styles.detailValue, { color: colors.mutedForeground }]}
                numberOfLines={2}
              >
                {profile[item.field] || '—'}
              </Text>
            </View>
            <Hairline />
          </View>
        ))}
        <View style={[styles.disclaimer, { borderColor: colors.primary }]}>
          <Text style={[styles.disclaimerTitle, { color: colors.primary }]}>
            Disclaimer:
          </Text>
          <Text style={[styles.disclaimerCopy, { color: colors.mutedForeground }]}>
            Profile details are stored on this device for the demo only. No
            insurance policy or endorsement service is connected.
          </Text>
        </View>
      </SurfaceCard>
      <SectionHeading title="Need help with your profile?" />
      <Pressable onPress={() => router.push('/contact')} style={styles.helpLink}>
        <Text style={[styles.helpText, { color: colors.primary }]}>
          Contact support
        </Text>
        <Ionicons name="arrow-forward" size={16} color={colors.primary} />
      </Pressable>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 14, gap: 14 },
  profileHero: { borderRadius: 22, padding: 15, gap: 9 },
  profileIdentity: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  identityCopy: { flex: 1, gap: 2 },
  hello: { fontSize: 18, fontWeight: '800' },
  name: { fontSize: 15, fontWeight: '700' },
  email: { fontSize: 10 },
  editButton: {
    borderWidth: 1,
    borderRadius: 17,
    paddingHorizontal: 10,
    paddingVertical: 5,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  editText: { fontSize: 12, fontWeight: '700' },
  progressRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  progressTrack: { height: 6, borderRadius: 4, flex: 1, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 4 },
  progressLabel: { fontSize: 11, fontWeight: '800' },
  profileHint: { fontSize: 11, lineHeight: 16 },
  vaultCard: { padding: 13, gap: 11 },
  vaultHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 2,
  },
  vaultTitleBlock: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  vaultTitle: { fontSize: 16, fontWeight: '800' },
  policyPill: { borderWidth: 1, borderRadius: 16, paddingHorizontal: 12, paddingVertical: 5 },
  policyPillText: { fontSize: 10, fontWeight: '700' },
  detailRow: {
    minHeight: 37,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  detailLabel: { flex: 1, fontSize: 12, fontWeight: '600' },
  detailValue: { flex: 1, textAlign: 'right', fontSize: 11 },
  disclaimer: { borderWidth: 1, borderRadius: 13, padding: 10, marginTop: 2 },
  disclaimerTitle: { fontSize: 11, fontWeight: '800', marginBottom: 3 },
  disclaimerCopy: { fontSize: 10, lineHeight: 15 },
  helpLink: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  helpText: { fontSize: 13, fontWeight: '700' },
  pressed: { opacity: 0.75 },
});
