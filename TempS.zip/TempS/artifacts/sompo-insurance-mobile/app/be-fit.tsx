import React, { useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Image, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppHeader, AppPage, LabeledInput, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const BOOKING_KEY = 'universal-sompo:be-fit-booking';
const locations = [
  { id: 'wellness-patna', name: 'Be-Fit Wellness Studio', area: 'Boring Road', city: 'Patna', pin: '800001', address: 'Boring Road, Patna' },
  { id: 'active-delhi', name: 'Active Life Fitness Club', area: 'Dwarka', city: 'Delhi', pin: '110075', address: 'Sector 12, Dwarka, Delhi' },
  { id: 'fit-noida', name: 'Fit & Well Centre', area: 'Sector 18', city: 'Noida', pin: '201301', address: 'Sector 18, Noida' },
];
const dates = ['Today', 'Tomorrow', 'Saturday'];
const slots = ['8:00 AM', '10:30 AM', '5:00 PM', '6:30 PM'];

type Booking = { location: string; address: string; date: string; slot: string; reference: string };

export default function BeFitScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [search, setSearch] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedDate, setSelectedDate] = useState('Tomorrow');
  const [selectedSlot, setSelectedSlot] = useState('');
  const [booking, setBooking] = useState<Booking | null>(null);
  const [showBooking, setShowBooking] = useState(false);
  const [error, setError] = useState('');
  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;

  useEffect(() => {
    let mounted = true;
    void AsyncStorage.getItem(BOOKING_KEY)
      .then((value) => {
        if (!mounted || !value) return;
        setBooking(JSON.parse(value) as Booking);
      })
      .catch(() => setError('Could not load your saved booking.'));
    return () => {
      mounted = false;
    };
  }, []);

  const visibleLocations = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return locations;
    return locations.filter((item) =>
      `${item.name} ${item.area} ${item.city} ${item.pin}`.toLowerCase().includes(query),
    );
  }, [search]);

  const confirmBooking = async () => {
    const location = locations.find((item) => item.id === selectedLocation);
    if (!location || !selectedSlot) {
      setError('Choose a fitness centre and a time slot first.');
      return;
    }
    const nextBooking = {
      location: location.name,
      address: location.address,
      date: selectedDate,
      slot: selectedSlot,
      reference: `BF-${Date.now().toString().slice(-6)}`,
    };
    try {
      await AsyncStorage.setItem(BOOKING_KEY, JSON.stringify(nextBooking));
      setBooking(nextBooking);
      setShowBooking(false);
      setError('');
    } catch {
      setError('This booking could not be saved on this device.');
    }
  };

  const cancelBooking = async () => {
    try {
      await AsyncStorage.removeItem(BOOKING_KEY);
      setBooking(null);
    } catch {
      setError('The local booking could not be cancelled.');
    }
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.page, { backgroundColor: colors.screen }]}
      contentContainerStyle={[styles.content, { paddingTop: topInset + 8, paddingBottom: bottomInset + 24 }]}
      bottomOffset={70}
      keyboardShouldPersistTaps="handled"
    >
      <AppHeader title="Be-Fit" onBack={() => router.back()} />
      <Image
        source={require('../assets/images/be-fit-hero.png')}
        resizeMode="cover"
        style={styles.hero}
        accessibilityLabel="People exercising"
      />
      <View style={styles.actions}>
        <Pressable
          onPress={() => {
            setShowBooking(false);
            setSelectedLocation('');
          }}
          style={[styles.actionTile, { backgroundColor: colors.primaryWash }]}
        >
          <Ionicons name="location-outline" size={19} color={colors.primary} />
          <View style={styles.actionCopy}>
            <Text style={[styles.actionTitle, { color: colors.foreground }]}>Be-Fit Network Locator</Text>
            <Text style={[styles.actionDetail, { color: colors.mutedForeground }]}>Find a sample partner centre</Text>
          </View>
          <Ionicons name="chevron-forward" size={15} color={colors.primary} />
        </Pressable>
        <Pressable
          onPress={() => {
            setShowBooking(true);
            setError('');
          }}
          style={[styles.actionTile, { backgroundColor: colors.primaryWash }]}
        >
          <Ionicons name="calendar-outline" size={19} color={colors.primary} />
          <View style={styles.actionCopy}>
            <Text style={[styles.actionTitle, { color: colors.foreground }]}>Book Your Slot</Text>
            <Text style={[styles.actionDetail, { color: colors.mutedForeground }]}>Choose a class time</Text>
          </View>
          <Ionicons name="chevron-forward" size={15} color={colors.primary} />
        </Pressable>
      </View>

      {booking ? (
        <SurfaceCard style={styles.bookingCard}>
          <View style={[styles.bookingIcon, { backgroundColor: colors.primaryWash }]}>
            <Ionicons name="checkmark-circle" size={22} color={colors.success} />
          </View>
          <View style={styles.bookingCopy}>
            <Text style={[styles.bookingTitle, { color: colors.foreground }]}>Saved booking</Text>
            <Text style={[styles.bookingDetail, { color: colors.mutedForeground }]}>
              {booking.location} · {booking.date}, {booking.slot}
            </Text>
            <Text style={[styles.bookingReference, { color: colors.primary }]}>{booking.reference}</Text>
            <Text style={[styles.demoNote, { color: colors.mutedForeground }]}>Saved locally; the centre has not been notified.</Text>
          </View>
          <Pressable onPress={() => void cancelBooking()} accessibilityRole="button" accessibilityLabel="Cancel local booking">
            <Ionicons name="close-circle-outline" size={21} color={colors.destructive} />
          </Pressable>
        </SurfaceCard>
      ) : null}

      {!showBooking ? (
        <View style={styles.section}>
          <View style={styles.sectionHeading}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Find a Be-Fit centre</Text>
            <Text style={[styles.sampleBadge, { color: colors.primary, backgroundColor: colors.primaryWash }]}>SAMPLE DIRECTORY</Text>
          </View>
          <LabeledInput
            label="City or pincode"
            value={search}
            onChangeText={setSearch}
            placeholder="Search city or pincode"
            autoCapitalize="words"
          />
          {visibleLocations.length ? visibleLocations.map((location) => (
            <Pressable
              key={location.id}
              onPress={() => {
                setSelectedLocation(location.id);
                setShowBooking(true);
                setError('');
              }}
              style={({ pressed }) => [pressed && styles.pressed]}
            >
              <SurfaceCard style={[styles.locationCard, { borderColor: selectedLocation === location.id ? colors.primary : colors.border }]}>
                <View style={[styles.locationIcon, { backgroundColor: colors.primaryWash }]}>
                  <Ionicons name="fitness-outline" size={20} color={colors.primary} />
                </View>
                <View style={styles.locationCopy}>
                  <Text style={[styles.locationTitle, { color: colors.foreground }]}>{location.name}</Text>
                  <Text style={[styles.locationAddress, { color: colors.mutedForeground }]}>{location.address}</Text>
                  <Text style={[styles.locationArea, { color: colors.mutedForeground }]}>{location.city} · {location.pin}</Text>
                </View>
                <Ionicons name="chevron-forward" size={16} color={colors.mutedForeground} />
              </SurfaceCard>
            </Pressable>
          )) : (
            <SurfaceCard style={styles.emptyCard}>
              <Ionicons name="search-outline" size={23} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>No sample centres match that search.</Text>
            </SurfaceCard>
          )}
        </View>
      ) : (
        <SurfaceCard style={styles.formCard}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Book your fitness slot</Text>
          <Text style={[styles.actionDetail, { color: colors.mutedForeground }]}>
            {locations.find((item) => item.id === selectedLocation)?.name ?? 'Choose a centre from the sample directory'}
          </Text>
          <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Choose a day</Text>
          <View style={styles.chips}>
            {dates.map((date) => (
              <Pressable
                key={date}
                onPress={() => setSelectedDate(date)}
                style={[styles.chip, { backgroundColor: selectedDate === date ? colors.primary : colors.card, borderColor: selectedDate === date ? colors.primary : colors.border }]}
              >
                <Text style={[styles.chipText, { color: selectedDate === date ? colors.white : colors.foreground }]}>{date}</Text>
              </Pressable>
            ))}
          </View>
          <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Choose a time</Text>
          <View style={styles.chips}>
            {slots.map((slot) => (
              <Pressable
                key={slot}
                onPress={() => setSelectedSlot(slot)}
                style={[styles.chip, { backgroundColor: selectedSlot === slot ? colors.primary : colors.card, borderColor: selectedSlot === slot ? colors.primary : colors.border }]}
              >
                <Text style={[styles.chipText, { color: selectedSlot === slot ? colors.white : colors.foreground }]}>{slot}</Text>
              </Pressable>
            ))}
          </View>
          {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
          <PrimaryButton label="Confirm Slot" icon="checkmark" onPress={() => void confirmBooking()} />
          <Pressable onPress={() => { setShowBooking(false); setError(''); }} style={styles.cancel}>
            <Text style={[styles.cancelText, { color: colors.primary }]}>Back to centre locator</Text>
          </Pressable>
        </SurfaceCard>
      )}

      <View style={styles.descriptionSection}>
        <Text style={[styles.descriptionTitle, { color: colors.primary }]}>Benefit Description</Text>
        <Text style={[styles.description, { color: colors.foreground }]}>
          Be-Fit gives you a sample directory of fitness centres and a local appointment flow. Choose a centre, day, and slot to save a demo booking.
        </Text>
        <Text style={[styles.descriptionTitle, { color: colors.primary }]}>Key Features</Text>
        <Text style={[styles.description, { color: colors.foreground }]}>
          Browse by city or pincode, choose a time that suits you, and view or cancel your saved booking from this page.
        </Text>
      </View>
      <Text style={[styles.demoNote, { color: colors.mutedForeground }]}>The centre directory and bookings are local demo data.</Text>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 14, gap: 12 },
  hero: { width: '100%', height: 126, borderRadius: 14 },
  actions: { flexDirection: 'row', gap: 8 },
  actionTile: { flex: 1, minHeight: 59, borderRadius: 12, padding: 8, flexDirection: 'row', alignItems: 'center', gap: 6 },
  actionCopy: { flex: 1, gap: 3 },
  actionTitle: { fontSize: 9, fontWeight: '800' },
  actionDetail: { fontSize: 8, lineHeight: 12 },
  bookingCard: { padding: 10, flexDirection: 'row', alignItems: 'flex-start', gap: 8 },
  bookingIcon: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  bookingCopy: { flex: 1, gap: 3 },
  bookingTitle: { fontSize: 11, fontWeight: '800' },
  bookingDetail: { fontSize: 9, lineHeight: 13 },
  bookingReference: { fontSize: 9, fontWeight: '800' },
  demoNote: { fontSize: 8, lineHeight: 13 },
  section: { gap: 8 },
  sectionHeading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 7 },
  sectionTitle: { fontSize: 13, fontWeight: '800' },
  sampleBadge: { fontSize: 7, fontWeight: '800', overflow: 'hidden', paddingHorizontal: 6, paddingVertical: 4, borderRadius: 8 },
  locationCard: { minHeight: 68, padding: 9, flexDirection: 'row', alignItems: 'center', gap: 8 },
  locationIcon: { width: 35, height: 35, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  locationCopy: { flex: 1, gap: 3 },
  locationTitle: { fontSize: 10, fontWeight: '800' },
  locationAddress: { fontSize: 8 },
  locationArea: { fontSize: 8 },
  emptyCard: { minHeight: 90, alignItems: 'center', justifyContent: 'center', gap: 7 },
  emptyText: { fontSize: 9, textAlign: 'center' },
  formCard: { padding: 12, gap: 10 },
  fieldLabel: { fontSize: 10, fontWeight: '800' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  chip: { minHeight: 32, borderWidth: 1, borderRadius: 17, paddingHorizontal: 10, justifyContent: 'center' },
  chipText: { fontSize: 9, fontWeight: '700' },
  error: { fontSize: 9, lineHeight: 13 },
  cancel: { alignItems: 'center', paddingVertical: 4 },
  cancelText: { fontSize: 9, fontWeight: '800' },
  descriptionSection: { gap: 7 },
  descriptionTitle: { fontSize: 11, fontWeight: '800' },
  description: { fontSize: 9, lineHeight: 14 },
  pressed: { opacity: 0.76 },
});
