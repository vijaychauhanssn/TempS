import React, { useState } from 'react';
import { Modal, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppHeader, LabeledInput, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';

function SelectField({
  label,
  value,
  placeholder,
  options,
  onChange,
}: {
  label: string;
  value: string;
  placeholder: string;
  options: string[];
  onChange: (value: string) => void;
}) {
  const colors = useColors();
  const [visible, setVisible] = useState(false);
  return (
    <>
      <View style={styles.field}>
        <Text style={[styles.label, { color: colors.foreground }]}>{label} *</Text>
        <Pressable
          onPress={() => setVisible(true)}
          style={[styles.select, { backgroundColor: colors.card, borderColor: colors.borderStrong }]}
        >
          <Text style={[styles.selectText, { color: value ? colors.foreground : colors.placeholder }]}>
            {value || placeholder}
          </Text>
          <Ionicons name="chevron-down" size={17} color={colors.foreground} />
        </Pressable>
      </View>
      <Modal transparent visible={visible} animationType="fade" onRequestClose={() => setVisible(false)}>
        <Pressable onPress={() => setVisible(false)} style={[StyleSheet.absoluteFill, styles.modalOverlay, { backgroundColor: colors.scrim }]}>
          <SurfaceCard style={styles.optionSheet}>
            <Text style={[styles.optionHeading, { color: colors.foreground }]}>{label}</Text>
            {options.map((option) => (
              <Pressable
                key={option}
                onPress={() => {
                  onChange(option);
                  setVisible(false);
                }}
                style={[styles.optionRow, { borderBottomColor: colors.border }]}
              >
                <Text style={[styles.optionText, { color: colors.foreground }]}>{option}</Text>
                {option === value ? <Ionicons name="checkmark" size={18} color={colors.primary} /> : null}
              </Pressable>
            ))}
          </SurfaceCard>
        </Pressable>
      </Modal>
    </>
  );
}

export default function VehicleDetailsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { vehicle = 'Four Wheeler' } = useLocalSearchParams<{ vehicle?: string }>();
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [registrationDate, setRegistrationDate] = useState('');
  const [state, setState] = useState('');
  const [rto, setRto] = useState('');
  const [error, setError] = useState('');
  const isTwoWheeler = vehicle.toLowerCase().includes('two');
  const brands = isTwoWheeler
    ? ['Hero MotoCorp', 'Honda', 'Bajaj', 'TVS', 'Royal Enfield']
    : ['Maruti Suzuki', 'Hyundai', 'Honda', 'Tata Motors', 'Mahindra'];
  const models = isTwoWheeler
    ? ['Splendor Plus', 'Activa 6G', 'Pulsar 150', 'Jupiter', 'Classic 350']
    : ['Swift', 'Baleno', 'Creta', 'Nexon', 'Brezza'];
  const states = ['Bihar', 'West Bengal', 'Maharashtra', 'Delhi'];
  const rtoOptions = state === 'West Bengal'
    ? ['Kolkata South · WB-20', 'Kolkata North · WB-01']
    : state === 'Maharashtra'
      ? ['Mumbai Central · MH-01', 'Pune · MH-12']
      : state === 'Delhi'
        ? ['Delhi Central · DL-01', 'South Delhi · DL-03']
        : ['Patna · BR-01', 'Gaya · BR-02'];
  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;

  const continueQuote = () => {
    if (!brand || !model || !/^\d{2}\/\d{2}\/\d{4}$/.test(registrationDate) || !state || !rto) {
      setError('Complete each field. Use DD/MM/YYYY for the registration date.');
      return;
    }
    setError('');
    router.push({
      pathname: '/motor-quote',
      params: { vehicle, brand, model, registrationYear: registrationDate.slice(-4), state, rto },
    });
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.page, { backgroundColor: colors.screen }]}
      contentContainerStyle={[
        styles.content,
        { paddingTop: topInset + 8, paddingBottom: bottomInset + 22 },
      ]}
      bottomOffset={72}
      keyboardShouldPersistTaps="handled"
    >
      <AppHeader title="Add Vehicle Details" onBack={() => router.back()} />
      <View style={[styles.vehicleIllustration, { backgroundColor: colors.primaryWash }]}>
        <Text style={[styles.vehicleType, { color: colors.primary }]}>
          {isTwoWheeler ? 'TWO-WHEELER' : 'MOTOR INSURANCE'}
        </Text>
        <Ionicons name={isTwoWheeler ? 'bicycle-outline' : 'car-sport-outline'} size={40} color={colors.primary} />
      </View>
      <SelectField label="Vehicle Brand" value={brand} placeholder="Select vehicle brand" options={brands} onChange={(value) => { setBrand(value); setModel(''); }} />
      <SelectField label="Model" value={model} placeholder="Select model" options={models} onChange={setModel} />
      <LabeledInput
        label="Date of Registration"
        value={registrationDate}
        onChangeText={setRegistrationDate}
        placeholder="DD/MM/YYYY"
        keyboardType="numbers-and-punctuation"
        maxLength={10}
      />
      <SelectField label="State Where Vehicle is Registered" value={state} placeholder="Select state" options={states} onChange={(value) => { setState(value); setRto(''); }} />
      <SelectField label="RTO" value={rto} placeholder="Select RTO name" options={rtoOptions} onChange={setRto} />
      {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
      <View style={styles.footer}>
        <PrimaryButton label="Confirm" icon="arrow-forward" onPress={continueQuote} />
      </View>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 15, gap: 12 },
  vehicleIllustration: { height: 110, borderRadius: 16, alignItems: 'center', justifyContent: 'center', gap: 4 },
  vehicleType: { fontSize: 9, fontWeight: '800', letterSpacing: 1.2 },
  field: { gap: 6 },
  label: { fontSize: 12, fontWeight: '700' },
  select: { minHeight: 45, paddingHorizontal: 12, borderWidth: 1, borderRadius: 9, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  selectText: { fontSize: 12 },
  error: { fontSize: 10, lineHeight: 15 },
  footer: { marginTop: 'auto', paddingTop: 10 },
  modalOverlay: { justifyContent: 'center', padding: 24 },
  optionSheet: { padding: 16, maxHeight: '75%', gap: 4 },
  optionHeading: { fontSize: 15, fontWeight: '800', paddingBottom: 9 },
  optionRow: { minHeight: 43, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: StyleSheet.hairlineWidth },
  optionText: { fontSize: 12, fontWeight: '600' },
});
