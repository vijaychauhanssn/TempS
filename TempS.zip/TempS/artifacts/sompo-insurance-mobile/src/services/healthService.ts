export type APlusSelection = {
  sumInsured: string;
  plan: string;
  tenure: string;
};

export type APlusReferenceQuote = {
  annualPremium: number;
  label: 'Reference amount';
};

/**
 * The supplied A+ screenshot shows ₹11,280 for ₹10 lakh / Silver / 1 year.
 * No other rates or calculation formula were supplied, so other selections
 * deliberately do not receive an invented premium.
 */
export function getAPlusReferenceQuote(
  selection: APlusSelection,
): APlusReferenceQuote | null {
  if (
    selection.sumInsured === '₹10 Lakh'
    && selection.plan === 'Silver'
    && selection.tenure === '1 Year'
  ) {
    return { annualPremium: 11280, label: 'Reference amount' };
  }
  return null;
}

export function createDemoHealthReference(prefix: 'APLUS' | 'KBL') {
  return `${prefix}-${Date.now().toString().slice(-6)}`;
}
