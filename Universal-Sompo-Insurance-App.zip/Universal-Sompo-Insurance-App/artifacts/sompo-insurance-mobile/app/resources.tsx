import React from 'react';
import { Image, ImageSourcePropType, Pressable, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { AppHeader, AppPage, PrimaryButton } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

const resources: {
  title: string;
  subtitle: string;
  image: ImageSourcePropType;
}[] = [
  {
    title: 'Health Insurance Leaflet',
    subtitle: 'A quick guide to health cover',
    image: require('../assets/images/resource-healthcare.png'),
  },
  {
    title: 'Claim Form',
    subtitle: 'Understand the claim process',
    image: require('../assets/images/resource-claimform.png'),
  },
  {
    title: 'Supreme Healthcare',
    subtitle: 'Explore helpful resources',
    image: require('../assets/images/resource-supreme.png'),
  },
];

export default function ResourcesScreen() {
  const colors = useColors();
  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="Resource Video’s" onBack={() => router.back()} />
      <Text style={[styles.intro, { color: colors.mutedForeground }]}>
        Helpful information to make insurance simpler.
      </Text>
      <View style={styles.grid}>
        {resources.map((resource) => (
          <View
            key={resource.title}
            style={[
              styles.resourceCard,
              {
                backgroundColor: colors.white,
                borderColor: colors.border,
                shadowColor: colors.shadow,
              },
            ]}
          >
            <Image source={resource.image} resizeMode="cover" style={styles.resourceImage} />
            <View style={styles.resourceText}>
              <Text numberOfLines={2} style={[styles.resourceTitle, { color: colors.foreground }]}>
                {resource.title}
              </Text>
              <Text numberOfLines={2} style={[styles.resourceSubtitle, { color: colors.mutedForeground }]}>
                {resource.subtitle}
              </Text>
            </View>
            <PrimaryButton
              label="Get in touch"
              onPress={() => router.push('/contact')}
              style={styles.resourceButton}
            />
          </View>
        ))}
      </View>
      <Pressable onPress={() => router.push('/faq')} style={styles.faqLink}>
        <Text style={[styles.faqText, { color: colors.primary }]}>Browse FAQs instead</Text>
      </Pressable>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 16, gap: 12 },
  intro: { fontSize: 13, lineHeight: 19, marginTop: -6 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 11 },
  resourceCard: {
    width: '48%',
    minHeight: 202,
    borderRadius: 18,
    borderWidth: StyleSheet.hairlineWidth,
    overflow: 'hidden',
    padding: 8,
    gap: 6,
    shadowOpacity: 0.06,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
    elevation: 2,
  },
  resourceImage: { width: '100%', height: 92, borderRadius: 12 },
  resourceText: { flex: 1, gap: 3, paddingHorizontal: 3 },
  resourceTitle: { fontSize: 12, fontWeight: '800', lineHeight: 16 },
  resourceSubtitle: { fontSize: 10, lineHeight: 14 },
  resourceButton: { minHeight: 35, borderRadius: 19 },
  faqLink: { alignSelf: 'center', padding: 10 },
  faqText: { fontSize: 12, fontWeight: '700' },
});
