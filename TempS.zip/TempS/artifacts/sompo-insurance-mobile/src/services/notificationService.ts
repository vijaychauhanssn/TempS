export type NotificationReadState = 'read' | 'unread';

export type DemoNotification = {
  id: string;
  title: string;
  message: string;
  state: NotificationReadState;
};

export const notificationService = {
  getMode(): 'device-local-demo' {
    return 'device-local-demo';
  },
};
