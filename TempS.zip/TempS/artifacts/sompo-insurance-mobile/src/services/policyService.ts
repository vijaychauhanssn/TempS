import type { UserPolicy } from '@/context/AppState';

export const policyService = {
  listDemoPolicies(policies: readonly UserPolicy[]): UserPolicy[] {
    return [...policies];
  },
  createDemoReference(): string {
    return `POL-${Date.now().toString().slice(-6)}`;
  },
};
