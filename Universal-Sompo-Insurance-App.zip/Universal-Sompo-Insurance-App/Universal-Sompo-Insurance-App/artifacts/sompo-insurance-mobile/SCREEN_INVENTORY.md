# Screen inventory

This inventory maps every Expo Router screen to its purpose and the supplied reference material. The app has 40+ route modules. All insurer-specific data and submissions remain demo-only until approved APIs are provided.

## Entry, account, and home

| Route | Screen | Main content and actions |
| --- | --- | --- |
| `/` | App entry | Routes into the welcome/login flow. |
| `/welcome` | Welcome | Continue to sign-in or registration. |
| `/login` | Sign in | Select a login method; UHID/employee DOB uses the calendar picker. |
| `/register` | Registration | Capture the local demo profile and continue to the app. |
| `/(tabs)/home` | Home | Banner carousel, insurance actions, claim/renewal shortcuts, and drawer navigation. Banner loading, empty, error/retry, swipe, pagination, auto-advance, and safe destination routing are supported. |
| `/(tabs)/index` | Tab entry | Default tab route. |
| `/(tabs)/_layout` | Tab navigation | Bottom tabs for home, policies, nearby, wellness, and help. |
| `/(tabs)/help` | Help | Help and support entry points. |
| `/notifications` | Notifications | View local demo notification items. |

## Policy and insurance flows

| Route | Screen | Main content and actions |
| --- | --- | --- |
| `/(tabs)/policies` | My Policies | Browse saved demo policies and open policy details. |
| `/policy-detail` | Policy details | View a selected local policy summary and expiry information. |
| `/add-policy` | Add a policy | Enter policy details for the local account. |
| `/insurance` | Insurance | Insurance product and cover entry points. |
| `/health-plan` | Health plan | Review the selected sample health plan and continue to quote details. |
| `/health-buy` | Health insurance details | Proposer, DOB/auto-calculated age, member, and cascading state → city → pincode selections. DOB is selected from the calendar. |
| `/a-plus-calculator` | A Plus calculator | Sum insured, tenure, plan, add-ons, quote summary, proposer details, and local demo continuation; corresponds to both supplied calculator screenshots. |
| `/motor-insurance` | Motor insurance | Choose vehicle and start the applicable sample quote flow. |
| `/motor-quote` | Motor quote | Quote steps, KYC DOB calendar, and locally displayed sample premium options. |
| `/vehicle-details` | Vehicle details | Select vehicle, state/RTO, and registration date from list/calendar controls. |
| `/renewal` | Renewal entry | Choose a policy category and open its renewal flow. |
| `/policy-renewal` | Policy renewal | KYC, DOB calendar, add-ons, and sample premium/review; matches the renewal reference. |
| `/calculator` | Premium calculator | Local sample calculation flow. |

## Claims and service

| Route | Screen | Main content and actions |
| --- | --- | --- |
| `/claims` | Claims | Choose health/motor intimation, status, or forms. Health intimation opens the dedicated form. |
| `/health-claim-intimation` | Health claim intimation | Select insured member; enter hospital, admission/discharge dates, diagnosis, contact, and estimated cost; select state/city/pincode and attach local document images. Confirmation is demo-only. Matches the supplied claim form and member-picker references. |
| `/claim-action` | Motor claim, status, and forms | Date-picker-based incident intimation, sample claim status, and informational form checklist. |
| `/service-request` | Service request | Create a local demo service-request reference. |
| `/contact` | Contact | Support contact and phone actions. |
| `/faq` | FAQs | Browse common questions and answers. |
| `/resources` | Resources | View informational resources. |
| `/profile` | Profile | View local account details. |
| `/profile-edit` | Edit profile | Update local profile fields; DOB uses the calendar picker. |

## Health services and wellbeing

| Route | Screen | Main content and actions |
| --- | --- | --- |
| `/(tabs)/nearby` | Nearby services | Browse health and vehicle service categories; emergency action opens the device dialer. |
| `/find-hospitals` | Service directory | Filter sample entries by state, city, and pincode lists; shows an empty state when no sample entry matches. |
| `/kbl` | KBL services | Health-checkup and teleconsultation entry points, corresponding to the supplied KBL landing reference. |
| `/kbl-details` | Account verification | Verify sample account details before a local policy-link action; DOB uses the calendar picker. |
| `/health-checkup` | Health-checkup details | Test list and home-collection request. Address plus state/city/pincode lists; request is saved as a local demo. |
| `/tele-consultation` | Teleconsultation | Enter reason, choose a consultation date, and enter a time; request remains demo-only. |
| `/(tabs)/wellness` | Wellness | Health and activity content. |
| `/be-fit` | Be-Fit | Browse sample fitness activities and make a local demo booking. |
| `/stepathon` | Stepathon | View the activity challenge and local progress/leaderboard presentation. |
| `/webinar` | Health webinar | Browse webinar information and local actions. |

## Vehicle and fallback routes

| Route | Screen | Main content and actions |
| --- | --- | --- |
| `/my-challan` | Challans | Browse sample vehicle challans. |
| `/my-vehicle` | My Vehicle | View local vehicle details. |
| `/pollution-certificate` | Pollution certificate | Review certificate information and local demo actions. |
| `/(tabs)/_layout` | Shared tab shell | Keeps primary app destinations available. |
| `/+not-found` | Not found | Fallback for unknown routes. |

## Date-picker coverage

Every editable DOB field uses the shared calendar picker: sign-in, account verification, health quote, motor quote, renewal KYC, and profile editing. DOB pickers disable future dates and preserve the existing field format where the flow requires it. Date pickers are also used for consultation, claim, admission/discharge, and vehicle-registration dates.
