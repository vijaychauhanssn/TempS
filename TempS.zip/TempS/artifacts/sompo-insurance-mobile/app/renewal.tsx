import React, { useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppHeader, AppPage, SurfaceCard } from '@/components/AppUI';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

const renewalProducts = [
  { name: 'Two Wheeler', detail: 'Comprehensive package and third-party liability', icon: 'bicycle-outline' as const, type: 'Two Wheeler' },
  { name: 'Private Car', detail: 'Comprehensive package and third-party liability', icon: 'car-sport-outline' as const, type: 'Four Wheeler' },
];

export default function RenewalScreen() {
  const colors = useColors();
  const { policies } = useAppState();
  const [reminders, setReminders] = useState<string[]>([]);

  const toggleReminder = (type: string) => {
    const enabled = reminders.includes(type);
    setReminders((current) => enabled ? current.filter((item) => item !== type) : [...current, type]);
    Alert.alert(enabled ? 'Reminder removed' : 'Reminder set', enabled
      ? 'This local demo reminder has been removed.'
      : 'A local demo reminder is set for this renewal.');
  };

  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="Renewal Policy" onBack={() => router.back()} />
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
        Renew a policy or set a local reminder to review it before expiry.
      </Text>
      <View style={styles.products}>
        {renewalProducts.map((product, index) => {
          const isReminderSet = reminders.includes(product.type);
          return (
            <SurfaceCard key={product.name} style={styles.productCard}>
              <View style={[styles.productBanner, { backgroundColor: index === 0 ? colors.blue : colors.primaryPale }]}>
                <Text style={[styles.productTitle, { color: colors.primaryDeep }]}>{product.name}</Text>
                <Text style={[styles.productDetail, { color: colors.mutedForeground }]}>{product.detail}</Text>
              </View>
              <View style={[styles.productIcon, { backgroundColor: index === 0 ? colors.primary : colors.primarySoft }]}>
                <Ionicons name={product.icon} size={30} color={colors.white} />
              </View>
              <View style={styles.benefitList}>
                <Benefit label="Benefits and features with IDV" />
                <Benefit label="Comprehensive cover options" />
                <Benefit label="Third party cover" />
              </View>
              <View style={styles.actionRow}>
                <Pressable
                  onPress={() => {
                    const policy = policies.find((item) =>
                      item.category === 'Motor'
                      && (product.type === 'Two Wheeler'
                        ? /two.?wheeler|bike|scooter/i.test(`${item.name} ${item.company}`)
                        : /four.?wheeler|car|private/i.test(`${item.name} ${item.company}`)),
                    );
                    if (policy) {
                      router.push({ pathname: '/policy-renewal', params: { policyId: policy.id } });
                    } else {
                      router.push({ pathname: '/motor-insurance', params: { vehicle: product.type, mode: 'renew' } });
                    }
                  }}
                  style={[styles.renewButton, { backgroundColor: colors.primary }]}
                >
                  <Text style={[styles.renewText, { color: colors.white }]}>Renew Now</Text>
                </Pressable>
                <Pressable
                  onPress={() => toggleReminder(product.type)}
                  style={[styles.reminderButton, { borderColor: colors.primary }]}
                >
                  <Ionicons name={isReminderSet ? 'notifications' : 'notifications-outline'} size={15} color={colors.primary} />
                  <Text style={[styles.reminderText, { color: colors.primary }]}>
                    {isReminderSet ? 'Reminder set' : 'Remind me'}
                  </Text>
                </Pressable>
              </View>
            </SurfaceCard>
          );
        })}
      </View>
      {policies.length ? (
        <View style={styles.expiringSection}>
          <Text style={[styles.expiringTitle, { color: colors.foreground }]}>Your policies</Text>
          {policies.slice(0, 2).map((policy) => (
            <Pressable
              key={policy.id}
              onPress={() => router.push({ pathname: '/policy-detail', params: { id: policy.id } })}
              style={({ pressed }) => [pressed && styles.pressed]}
            >
              <SurfaceCard style={styles.policyRow}>
                <Ionicons name={policy.category === 'Motor' ? 'car-outline' : 'heart-outline'} size={19} color={colors.primary} />
                <View style={styles.policyCopy}>
                  <Text style={[styles.policyName, { color: colors.foreground }]}>{policy.name}</Text>
                  <Text style={[styles.policyExpiry, { color: colors.mutedForeground }]}>Expires {policy.expiryDate}</Text>
                </View>
                <Ionicons name="chevron-forward" size={16} color={colors.mutedForeground} />
              </SurfaceCard>
            </Pressable>
          ))}
        </View>
      ) : null}
      <Text style={[styles.note, { color: colors.mutedForeground }]}>
        Renewal rates, benefits and payments are not connected to insurer services.
      </Text>
    </AppPage>
  );
}

function Benefit({ label }: { label: string }) {
  const colors = useColors();
  return (
    <View style={styles.benefit}>
      <Ionicons name="checkmark-circle" size={15} color={colors.success} />
      <Text style={[styles.benefitText, { color: colors.foreground }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 13, gap: 12 },
  subtitle: { fontSize: 11, lineHeight: 16, marginTop: -11 },
  products: { gap: 12 },
  productCard: { padding: 0, overflow: 'hidden', borderRadius: 15 },
  productBanner: { minHeight: 54, paddingHorizontal: 13, paddingVertical: 8, justifyContent: 'center' },
  productTitle: { fontSize: 14, fontWeight: '800' },
  productDetail: { fontSize: 9, lineHeight: 13 },
  productIcon: { height: 74, marginHorizontal: 1, alignItems: 'center', justifyContent: 'center' },
  benefitList: { gap: 1, paddingHorizontal: 12, paddingVertical: 8 },
  benefit: { minHeight: 28, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  benefitText: { flex: 1, textAlign: 'center', fontSize: 10, fontWeight: '600' },
  actionRow: { flexDirection: 'row', gap: 8, padding: 10, paddingTop: 3 },
  renewButton: { minHeight: 37, flex: 1, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  renewText: { fontSize: 11, fontWeight: '800' },
  reminderButton: { minHeight: 37, flex: 1, borderWidth: 1, borderRadius: 11, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5 },
  reminderText: { fontSize: 10, fontWeight: '700' },
  expiringSection: { gap: 8 },
  expiringTitle: { fontSize: 14, fontWeight: '800' },
  policyRow: { padding: 10, flexDirection: 'row', alignItems: 'center', gap: 8 },
  policyCopy: { flex: 1, gap: 3 },
  policyName: { fontSize: 10, fontWeight: '700' },
  policyExpiry: { fontSize: 9 },
  note: { fontSize: 9, lineHeight: 14, textAlign: 'center' },
  pressed: { opacity: 0.74 },
});
