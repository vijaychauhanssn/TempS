/**
 * Authentication stays in the app's existing device-local demo flow until an
 * approved identity provider and API contract are configured.
 */
export type AuthMode = 'device-demo' | 'live';

export const authService = {
  getMode(): AuthMode {
    return process.env.EXPO_PUBLIC_AUTH_MODE === 'live' ? 'live' : 'device-demo';
  },
};
