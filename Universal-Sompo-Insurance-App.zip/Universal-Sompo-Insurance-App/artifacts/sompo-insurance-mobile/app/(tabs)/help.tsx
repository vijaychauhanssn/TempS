import React from 'react';
import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppPage, SectionHeading, SurfaceCard } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

const links = [
  { title: 'Contact Us', detail: 'Call or email our support team.', icon: 'call-outline' as const, route: '/contact' as const },
  { title: 'Frequently asked questions', detail: 'Find answers to common questions.', icon: 'help-circle-outline' as const, route: '/faq' as const },
  { title: 'Resources', detail: 'Browse health and insurance guides.', icon: 'book-outline' as const, route: '/resources' as const },
];

export default function HelpScreen() {
  const colors = useColors();
  return (
    <AppPage contentStyle={styles.content}>
      <View style={styles.titleBlock}>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>HERE TO HELP</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Support</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Choose the quickest way to get the information you need.
        </Text>
      </View>
      <SurfaceCard style={styles.emergencyCard}>
        <View style={[styles.emergencyIcon, { backgroundColor: colors.primaryPale }]}>
          <Ionicons name="medical-outline" size={22} color={colors.primary} />
        </View>
        <View style={styles.emergencyCopy}>
          <Text style={[styles.emergencyTitle, { color: colors.foreground }]}>
            Need urgent help?
          </Text>
          <Text style={[styles.emergencyDetail, { color: colors.mutedForeground }]}>
            Toll-free support · 1800-22-4030
          </Text>
        </View>
        <Pressable
          onPress={() => void Linking.openURL('tel:1800224030').catch(() => undefined)}
          accessibilityRole="button"
          accessibilityLabel="Call toll-free support"
          style={[styles.callButton, { backgroundColor: colors.primary }]}
        >
          <Ionicons name="call" size={18} color={colors.white} />
        </Pressable>
      </SurfaceCard>
      <SectionHeading title="Support and information" />
      <View style={styles.linkList}>
        {links.map((item) => (
          <Pressable
            key={item.title}
            onPress={() => router.push(item.route)}
            style={({ pressed }) => [pressed && styles.pressed]}
          >
            <SurfaceCard style={styles.linkCard}>
              <View style={[styles.linkIcon, { backgroundColor: colors.primaryWash }]}>
                <Ionicons name={item.icon} size={22} color={colors.primary} />
              </View>
              <View style={styles.linkCopy}>
                <Text style={[styles.linkTitle, { color: colors.foreground }]}>
                  {item.title}
                </Text>
                <Text style={[styles.linkDetail, { color: colors.mutedForeground }]}>
                  {item.detail}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={17} color={colors.mutedForeground} />
            </SurfaceCard>
          </Pressable>
        ))}
      </View>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 16, gap: 16 },
  titleBlock: { gap: 5, paddingTop: 4 },
  eyebrow: { fontSize: 10, fontWeight: '800', letterSpacing: 1.2 },
  title: { fontSize: 28, fontWeight: '800' },
  subtitle: { fontSize: 13, lineHeight: 19 },
  emergencyCard: { flexDirection: 'row', alignItems: 'center', gap: 11, padding: 13 },
  emergencyIcon: { width: 44, height: 44, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  emergencyCopy: { flex: 1, gap: 4 },
  emergencyTitle: { fontSize: 13, fontWeight: '800' },
  emergencyDetail: { fontSize: 11 },
  callButton: { width: 39, height: 39, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  linkList: { gap: 9 },
  linkCard: { flexDirection: 'row', alignItems: 'center', gap: 11, padding: 12 },
  linkIcon: { width: 43, height: 43, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  linkCopy: { flex: 1, gap: 4 },
  linkTitle: { fontSize: 13, fontWeight: '700' },
  linkDetail: { fontSize: 11 },
  pressed: { opacity: 0.76 },
});
