import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import BrandHeader from '../components/BrandHeader';
import { colors } from '../theme/colors';

const items = [
  ['person-outline', 'Personal details'], ['shield-outline', 'My policies'], ['notifications-outline', 'Notification preferences'],
  ['document-text-outline', 'Documents'], ['help-circle-outline', 'Help & support'], ['lock-closed-outline', 'Privacy & security']
] as const;
export default function ProfileScreen() {
  return (
    <View style={styles.screen}>
      <BrandHeader />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.heading}>My Profile</Text>
        <View style={styles.profileCard}><View style={styles.avatar}><Ionicons name="person" size={30} color={colors.primary}/></View><Text style={styles.name}>Demo User</Text><Text style={styles.phone}>+91 ••••• ••000</Text><Text style={styles.demo}>Demo account</Text></View>
        <View style={styles.list}>{items.map(([icon, label]) => <Pressable key={label} onPress={() => Alert.alert(label, 'Connect this option to the relevant application screen or API.')} style={styles.item}><Ionicons name={icon} size={21} color={colors.primary}/><Text style={styles.itemText}>{label}</Text><Ionicons name="chevron-forward" size={19} color={colors.muted}/></Pressable>)}</View>
        <Text style={styles.version}>Universal Sompo · Mobile app prototype</Text>
      </ScrollView>
    </View>
  );
}
const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  content: { padding: 18, paddingBottom: 30 },
  heading: { fontSize: 24, fontWeight: '800', color: colors.text, marginVertical: 12 },
  profileCard: { backgroundColor: '#FFF', borderRadius: 18, alignItems: 'center', padding: 24, marginBottom: 18 },
  avatar: { width: 72, height: 72, borderRadius: 36, backgroundColor: colors.roseLight, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  name: { fontSize: 17, color: colors.text, fontWeight: '800' },
  phone: { color: colors.muted, fontSize: 12, marginTop: 5 },
  demo: { color: colors.primary, backgroundColor: colors.roseLight, overflow: 'hidden', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 5, marginTop: 12, fontSize: 10, fontWeight: '700' },
  list: { backgroundColor: '#FFF', borderRadius: 16, paddingHorizontal: 14 },
  item: { flexDirection: 'row', alignItems: 'center', gap: 13, paddingVertical: 17, borderBottomWidth: 1, borderBottomColor: '#F0ECEE' },
  itemText: { flex: 1, color: colors.text, fontSize: 13, fontWeight: '600' },
  version: { color: colors.muted, fontSize: 10, textAlign: 'center', marginTop: 24 },
});