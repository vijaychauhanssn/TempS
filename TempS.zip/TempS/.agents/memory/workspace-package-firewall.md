---
name: Workspace installs and package firewall
description: Replit package-firewall behavior encountered when installing a multi-package workspace.
---

When Replit's package registry blocks a dependency from a workspace that is not needed for the current app, install only the needed workspace and its dependency closure first. Do not change the lockfile or override the blocked package unless that workspace is actually required.

**Why:** The imported app's full workspace install was blocked on a transitive API-server package, while the mobile app and its shared dependency installed successfully from the same lockfile.

**How to apply:** For app-specific preview or development, prefer a pnpm workspace filter. Install the full workspace only when the requested workflow requires its other packages.
