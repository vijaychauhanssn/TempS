import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppHeader, AppPage, LabeledInput, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

export default function OfflineCalculatorScreen() {
  const colors = useColors();
  const [height, setHeight] = useState('188');
  const [weight, setWeight] = useState('87');
  const [result, setResult] = useState<number | null>(null);
  const [error, setError] = useState('');

  const calculate = () => {
    const heightInMeters = Number(height) / 100;
    const weightInKg = Number(weight);
    if (
      !Number.isFinite(heightInMeters) ||
      !Number.isFinite(weightInKg) ||
      heightInMeters < 0.5 ||
      heightInMeters > 2.5 ||
      weightInKg < 10 ||
      weightInKg > 350
    ) {
      setError('Enter a height between 50–250 cm and weight between 10–350 kg.');
      setResult(null);
      return;
    }
    setError('');
    setResult(weightInKg / (heightInMeters * heightInMeters));
  };

  const category =
    result === null
      ? ''
      : result < 18.5
        ? 'Below the typical adult range'
        : result < 25
          ? 'Within the typical adult range'
          : result < 30
            ? 'Above the typical adult range'
            : 'Well above the typical adult range';

  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="Offline Calculator" onBack={() => router.back()} />
      <View style={styles.heading}>
        <View style={[styles.icon, { backgroundColor: colors.primaryWash }]}>
          <Ionicons name="calculator-outline" size={25} color={colors.primary} />
        </View>
        <Text style={[styles.title, { color: colors.foreground }]}>BMI estimate</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          A simple calculation that works offline on this device.
        </Text>
      </View>
      <SurfaceCard style={styles.form}>
        <LabeledInput
          label="Height (cm)"
          value={height}
          onChangeText={setHeight}
          keyboardType="decimal-pad"
          testID="bmi-height"
        />
        <LabeledInput
          label="Weight (kg)"
          value={weight}
          onChangeText={setWeight}
          keyboardType="decimal-pad"
          testID="bmi-weight"
        />
        {error ? (
          <Text accessibilityRole="alert" style={[styles.error, { color: colors.primary }]}>
            {error}
          </Text>
        ) : null}
        <PrimaryButton label="Calculate" onPress={calculate} testID="bmi-calculate" />
      </SurfaceCard>
      {result !== null ? (
        <SurfaceCard style={[styles.result, { borderColor: colors.primaryPale }]}>
          <Text style={[styles.resultLabel, { color: colors.mutedForeground }]}>
            Your BMI estimate
          </Text>
          <Text style={[styles.resultValue, { color: colors.primary }]}>
            {result.toFixed(1)}
          </Text>
          <Text style={[styles.category, { color: colors.foreground }]}>{category}</Text>
        </SurfaceCard>
      ) : null}
      <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
        This is a general wellness calculation, not medical advice or an insurance premium quote.
      </Text>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 16, gap: 16 },
  heading: { alignItems: 'center', gap: 8, paddingVertical: 8 },
  icon: { width: 57, height: 57, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 22, fontWeight: '800' },
  subtitle: { fontSize: 12, lineHeight: 17, textAlign: 'center' },
  form: { gap: 14 },
  error: { fontSize: 12, fontWeight: '600' },
  result: { alignItems: 'center', gap: 5, borderWidth: 1 },
  resultLabel: { fontSize: 12 },
  resultValue: { fontSize: 38, fontWeight: '800' },
  category: { fontSize: 13, fontWeight: '700', textAlign: 'center' },
  disclaimer: { fontSize: 10, lineHeight: 15, textAlign: 'center', paddingHorizontal: 10 },
});
