import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppHeader, LabeledInput, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { SelectField } from '@/components/FormFields';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';
import { demoStates, getDemoCities, getDemoPincodes } from '@/src/services/locationService';
import { createDemoHealthReference } from '@/src/services/healthService';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const includedTests = [
  'Hemogram and ESR',
  'Liver Function Test',
  'Urine Routine',
  'Fasting Blood Sugar',
  'HBA1C',
  'Lipid Profile',
  'Blood Urea',
  'Serum Creatinine',
  'Thyroid Profile - T3/T4/TSH',
];

export default function HealthCheckupScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [address, setAddress] = useState('');
  const [pincode, setPincode] = useState('');
  const [stateName, setStateName] = useState('');
  const [city, setCity] = useState('');
  const [error, setError] = useState('');
  const [reference, setReference] = useState('');
  const cities = getDemoCities(stateName);
  const pincodes = getDemoPincodes(stateName, city);

  const submit = () => {
    if (address.trim().length < 5 || !stateName || !city || !pincodes.includes(pincode)) {
      setError('Enter your home address and choose a state, city, and pincode.');
      return;
    }
    setError('');
    setReference(createDemoHealthReference('KBL'));
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.page, { backgroundColor: colors.screen }]}
      contentContainerStyle={[
        styles.content,
        { paddingTop: Math.max(insets.top, 12) + 6, paddingBottom: Math.max(insets.bottom, 12) + 20 },
      ]}
      bottomOffset={72}
      keyboardShouldPersistTaps="handled"
    >
      <AppHeader title="Health checkup details" onBack={() => router.back()} />
      <View style={styles.heading}>
        <Text style={[styles.title, { color: colors.foreground }]}>Health Checkup</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Complete tests for a complete you.</Text>
      </View>

      <SurfaceCard style={styles.testsCard}>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>This checkup includes</Text>
        {includedTests.map((test) => (
          <View key={test} style={styles.testRow}>
            <Ionicons name="checkmark-circle" size={15} color={colors.success} />
            <Text style={[styles.testText, { color: colors.foreground }]}>{test}</Text>
          </View>
        ))}
      </SurfaceCard>

      <Pressable
        accessibilityRole="button"
        onPress={() => router.push({ pathname: '/find-hospitals', params: { category: 'Diagnostic Labs' } })}
        style={({ pressed }) => [pressed && styles.pressed]}
      >
        <View style={[styles.findCard, { backgroundColor: colors.primaryWash }]}>
          <View style={styles.findCopy}>
            <Text style={[styles.findTitle, { color: colors.foreground }]}>Find Diagnostic Centres Near You</Text>
            <Text style={[styles.findDetail, { color: colors.mutedForeground }]}>
              Enter your area pincode to see sample centres.
            </Text>
          </View>
          <Ionicons name="location" size={24} color={colors.primary} />
        </View>
      </Pressable>

      {!reference ? (
        <SurfaceCard style={styles.formCard}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Home Collection</Text>
          <Text style={[styles.copy, { color: colors.mutedForeground }]}>
            Add your address details to save a local demo request.
          </Text>
          <LabeledInput
            label="Address *"
            value={address}
            onChangeText={setAddress}
            placeholder="Enter address"
            multiline
            style={styles.address}
          />
          <View style={styles.twoColumns}>
            <SelectField
              label="State *"
              value={stateName}
              placeholder="Select state"
              options={demoStates}
              onChange={(value) => {
                setStateName(value);
                setCity('');
                setPincode('');
              }}
              testID="checkup-state"
            />
            <SelectField
              label="City *"
              value={city}
              placeholder={stateName ? 'Select city' : 'Select state first'}
              options={cities}
              disabled={!stateName}
              onChange={(value) => {
                setCity(value);
                setPincode('');
              }}
              testID="checkup-city"
            />
          </View>
          <SelectField
            label="Pincode *"
            value={pincode}
            placeholder={city ? 'Select pincode' : 'Select city first'}
            options={pincodes}
            disabled={!city}
            searchable={false}
            onChange={setPincode}
            testID="checkup-pincode"
          />
          {error ? <Text accessibilityRole="alert" style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
          <PrimaryButton label="Save demo request" icon="arrow-forward" onPress={submit} />
        </SurfaceCard>
      ) : (
        <SurfaceCard style={styles.successCard}>
          <Ionicons name="checkmark-circle" size={32} color={colors.success} />
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Request saved</Text>
          <Text style={[styles.copy, { color: colors.mutedForeground }]}>
            Demo reference {reference}. No diagnostic centre has been contacted.
          </Text>
          <PrimaryButton label="Back to KBL services" onPress={() => router.replace('/kbl')} />
        </SurfaceCard>
      )}
      <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
        The test list follows the supplied reference. Availability, pricing, and home collection are not connected to a provider.
      </Text>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 14, gap: 11 },
  heading: { gap: 3, paddingHorizontal: 2 },
  title: { fontSize: 17, fontWeight: '800' },
  subtitle: { fontSize: 9, lineHeight: 13 },
  testsCard: { gap: 6, padding: 11 },
  sectionTitle: { fontSize: 12, fontWeight: '800' },
  testRow: { minHeight: 21, flexDirection: 'row', alignItems: 'center', gap: 7 },
  testText: { fontSize: 9, fontWeight: '600' },
  findCard: { minHeight: 68, padding: 10, borderRadius: 12, flexDirection: 'row', alignItems: 'center', gap: 8 },
  findCopy: { flex: 1, gap: 4 },
  findTitle: { fontSize: 11, fontWeight: '800' },
  findDetail: { fontSize: 9, lineHeight: 13 },
  formCard: { gap: 10, padding: 12 },
  twoColumns: { flexDirection: 'row', gap: 8 },
  copy: { fontSize: 9, lineHeight: 14 },
  address: { minHeight: 68, paddingTop: 10, textAlignVertical: 'top' },
  error: { fontSize: 9, lineHeight: 14 },
  successCard: { alignItems: 'center', gap: 10, padding: 18 },
  disclaimer: { fontSize: 8, lineHeight: 13, textAlign: 'center' },
  pressed: { opacity: 0.77 },
});
