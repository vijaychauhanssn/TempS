import React, { useMemo, useState } from 'react';
import {
  FlatList,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';

type SelectFieldProps = {
  label: string;
  value: string;
  placeholder?: string;
  options: readonly string[];
  onChange: (value: string) => void;
  disabled?: boolean;
  searchable?: boolean;
  testID?: string;
};

export function SelectField({
  label,
  value,
  placeholder = 'Select',
  options,
  onChange,
  disabled = false,
  searchable = true,
  testID,
}: SelectFieldProps) {
  const colors = useColors();
  const [visible, setVisible] = useState(false);
  const [search, setSearch] = useState('');
  const filteredOptions = useMemo(() => {
    const query = search.trim().toLowerCase();
    return query ? options.filter((option) => option.toLowerCase().includes(query)) : [...options];
  }, [options, search]);

  const close = () => {
    setVisible(false);
    setSearch('');
  };

  return (
    <>
      <View style={styles.field}>
        <Text style={[styles.label, { color: colors.foreground }]}>{label}</Text>
        <Pressable
          testID={testID}
          accessibilityRole="button"
          accessibilityLabel={`${label}: ${value || placeholder}`}
          accessibilityState={{ disabled }}
          disabled={disabled}
          onPress={() => setVisible(true)}
          style={({ pressed }) => [
            styles.select,
            {
              backgroundColor: colors.card,
              borderColor: colors.borderStrong,
              opacity: disabled ? 0.5 : 1,
            },
            pressed && !disabled && styles.pressed,
          ]}
        >
          <Text
            numberOfLines={1}
            style={[styles.selectText, { color: value ? colors.foreground : colors.placeholder }]}
          >
            {value || placeholder}
          </Text>
          <Ionicons name="chevron-down" size={17} color={colors.foreground} />
        </Pressable>
      </View>
      <Modal
        transparent
        visible={visible}
        animationType="slide"
        onRequestClose={close}
      >
        <View style={[styles.modalOverlay, { backgroundColor: colors.scrim }]}>
          <Pressable
            accessibilityLabel="Close list"
            onPress={close}
            style={StyleSheet.absoluteFill}
          />
          <View style={[styles.sheet, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <View style={styles.sheetHeader}>
              <Text style={[styles.sheetTitle, { color: colors.foreground }]}>{label}</Text>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Close list"
                onPress={close}
                hitSlop={10}
              >
                <Ionicons name="close" size={22} color={colors.mutedForeground} />
              </Pressable>
            </View>
            {searchable ? (
              <View style={[styles.searchBox, { backgroundColor: colors.screen, borderColor: colors.border }]}>
                <Ionicons name="search-outline" size={17} color={colors.mutedForeground} />
                <TextInput
                  value={search}
                  onChangeText={setSearch}
                  placeholder={`Search ${label.toLowerCase()}`}
                  placeholderTextColor={colors.placeholder}
                  style={[styles.searchInput, { color: colors.foreground }]}
                  autoCapitalize="none"
                  accessibilityLabel={`Search ${label}`}
                />
              </View>
            ) : null}
            <FlatList
              data={filteredOptions}
              keyExtractor={(item) => item}
              keyboardShouldPersistTaps="handled"
              showsVerticalScrollIndicator={false}
              scrollEnabled={filteredOptions.length > 0}
              renderItem={({ item }) => (
                <Pressable
                  accessibilityRole="button"
                  accessibilityState={{ selected: item === value }}
                  onPress={() => {
                    onChange(item);
                    close();
                  }}
                  style={[styles.optionRow, { borderBottomColor: colors.border }]}
                >
                  <Text style={[styles.optionText, { color: colors.foreground }]}>{item}</Text>
                  {item === value ? <Ionicons name="checkmark" size={18} color={colors.primary} /> : null}
                </Pressable>
              )}
              ListEmptyComponent={
                <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                  No matching options.
                </Text>
              }
            />
          </View>
        </View>
      </Modal>
    </>
  );
}

type DatePickerFieldProps = {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  displayFormat?: 'DD/MM/YYYY' | 'DD-MM-YYYY';
  minDate?: Date;
  maxDate?: Date;
  testID?: string;
};

function parseDate(value: string): Date | undefined {
  const match = value.trim().match(/^(\d{2})[/-](\d{2})[/-](\d{4})$/);
  if (!match) return undefined;
  const date = new Date(Number(match[3]), Number(match[2]) - 1, Number(match[1]));
  if (
    date.getFullYear() !== Number(match[3])
    || date.getMonth() !== Number(match[2]) - 1
    || date.getDate() !== Number(match[1])
  ) return undefined;
  return date;
}

function formatDate(date: Date, format: 'DD/MM/YYYY' | 'DD-MM-YYYY'): string {
  const separator = format === 'DD/MM/YYYY' ? '/' : '-';
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  return `${day}${separator}${month}${separator}${date.getFullYear()}`;
}

export function isValidDateValue(value: string): boolean {
  return Boolean(parseDate(value));
}

export function DatePickerField({
  label,
  value,
  onChange,
  placeholder = 'Select date',
  displayFormat = 'DD/MM/YYYY',
  minDate,
  maxDate,
  testID,
}: DatePickerFieldProps) {
  const colors = useColors();
  const [visible, setVisible] = useState(false);
  const [showYearPicker, setShowYearPicker] = useState(false);
  const [month, setMonth] = useState(() => {
    const date = parseDate(value) ?? new Date();
    return new Date(date.getFullYear(), date.getMonth(), 1);
  });
  const today = new Date();
  const selectedDate = parseDate(value);
  const monthName = month.toLocaleString('en', { month: 'long' });
  const dayCount = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  const firstWeekday = new Date(month.getFullYear(), month.getMonth(), 1).getDay();
  const calendarCells: Array<number | null> = [
    ...Array.from({ length: firstWeekday }, () => null),
    ...Array.from({ length: dayCount }, (_, index) => index + 1),
  ];
  while (calendarCells.length % 7 !== 0) calendarCells.push(null);

  const isOutsideRange = (date: Date) =>
    Boolean(
      (minDate && date < new Date(minDate.getFullYear(), minDate.getMonth(), minDate.getDate()))
      || (maxDate && date > new Date(maxDate.getFullYear(), maxDate.getMonth(), maxDate.getDate())),
    );

  const open = () => {
    const date = selectedDate ?? new Date();
    setMonth(new Date(date.getFullYear(), date.getMonth(), 1));
    setShowYearPicker(false);
    setVisible(true);
  };

  const years = Array.from(
    { length: Math.max(1, (maxDate?.getFullYear() ?? today.getFullYear()) - (minDate?.getFullYear() ?? 1920) + 1) },
    (_, index) => (maxDate?.getFullYear() ?? today.getFullYear()) - index,
  );

  return (
    <>
      <View style={styles.field}>
        <Text style={[styles.label, { color: colors.foreground }]}>{label}</Text>
        <Pressable
          testID={testID}
          accessibilityRole="button"
          accessibilityLabel={`${label}: ${value || placeholder}`}
          onPress={open}
          style={({ pressed }) => [
            styles.select,
            { backgroundColor: colors.card, borderColor: colors.borderStrong },
            pressed && styles.pressed,
          ]}
        >
          <Text style={[styles.selectText, { color: value ? colors.foreground : colors.placeholder }]}>
            {value || placeholder}
          </Text>
          <Ionicons name="calendar-outline" size={18} color={colors.mutedForeground} />
        </Pressable>
      </View>
      <Modal transparent visible={visible} animationType="slide" onRequestClose={() => setVisible(false)}>
        <View style={[styles.modalOverlay, { backgroundColor: colors.scrim }]}>
          <Pressable
            accessibilityLabel="Close date picker"
            onPress={() => setVisible(false)}
            style={StyleSheet.absoluteFill}
          />
          <View style={[styles.calendarSheet, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <View style={styles.sheetHeader}>
              <Text style={[styles.sheetTitle, { color: colors.foreground }]}>{label}</Text>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Close date picker"
                onPress={() => setVisible(false)}
                hitSlop={10}
              >
                <Ionicons name="close" size={22} color={colors.mutedForeground} />
              </Pressable>
            </View>
            {showYearPicker ? (
              <FlatList
                data={years}
                keyExtractor={(year) => String(year)}
                initialScrollIndex={Math.max(0, years.indexOf(month.getFullYear()) - 2)}
                getItemLayout={(_, index) => ({ length: 46, offset: 46 * index, index })}
                renderItem={({ item: year }) => (
                  <Pressable
                    accessibilityRole="button"
                    accessibilityState={{ selected: year === month.getFullYear() }}
                    onPress={() => {
                      setMonth(new Date(year, month.getMonth(), 1));
                      setShowYearPicker(false);
                    }}
                    style={[styles.optionRow, { borderBottomColor: colors.border }]}
                  >
                    <Text style={[styles.optionText, { color: colors.foreground }]}>{year}</Text>
                    {year === month.getFullYear() ? <Ionicons name="checkmark" size={18} color={colors.primary} /> : null}
                  </Pressable>
                )}
              />
            ) : (
              <>
                <View style={styles.monthRow}>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel="Previous month"
                    onPress={() => setMonth((current) => new Date(current.getFullYear(), current.getMonth() - 1, 1))}
                    hitSlop={8}
                    style={styles.monthArrow}
                  >
                    <Ionicons name="chevron-back" size={20} color={colors.primary} />
                  </Pressable>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel="Choose year"
                    onPress={() => setShowYearPicker(true)}
                    style={styles.monthLabel}
                  >
                    <Text style={[styles.monthText, { color: colors.foreground }]}>
                      {monthName} {month.getFullYear()}
                    </Text>
                    <Ionicons name="chevron-down" size={15} color={colors.primary} />
                  </Pressable>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel="Next month"
                    onPress={() => setMonth((current) => new Date(current.getFullYear(), current.getMonth() + 1, 1))}
                    hitSlop={8}
                    style={styles.monthArrow}
                  >
                    <Ionicons name="chevron-forward" size={20} color={colors.primary} />
                  </Pressable>
                </View>
                <View style={styles.weekRow}>
                  {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map((day) => (
                    <Text key={day} style={[styles.weekday, { color: colors.mutedForeground }]}>{day}</Text>
                  ))}
                </View>
                <View style={styles.calendarGrid}>
                  {calendarCells.map((day, index) => {
                    if (!day) return <View key={`empty-${index}`} style={styles.dayCell} />;
                    const date = new Date(month.getFullYear(), month.getMonth(), day);
                    const selected = selectedDate?.toDateString() === date.toDateString();
                    const disabled = isOutsideRange(date);
                    return (
                      <Pressable
                        key={date.toISOString()}
                        accessibilityRole="button"
                        accessibilityLabel={date.toLocaleDateString()}
                        accessibilityState={{ selected, disabled }}
                        disabled={disabled}
                        onPress={() => {
                          onChange(formatDate(date, displayFormat));
                          setVisible(false);
                        }}
                        style={[
                          styles.dayCell,
                          selected && { backgroundColor: colors.primary },
                        ]}
                      >
                        <Text style={[
                          styles.dayText,
                          { color: selected ? colors.white : disabled ? colors.placeholder : colors.foreground },
                        ]}>
                          {day}
                        </Text>
                      </Pressable>
                    );
                  })}
                </View>
                <Pressable
                  accessibilityRole="button"
                  onPress={() => {
                    onChange(formatDate(today, displayFormat));
                    setMonth(new Date(today.getFullYear(), today.getMonth(), 1));
                    setVisible(false);
                  }}
                  style={[styles.todayButton, { borderColor: colors.primary }]}
                >
                  <Text style={[styles.todayText, { color: colors.primary }]}>Today</Text>
                </Pressable>
              </>
            )}
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  field: { flex: 1, gap: 6 },
  label: { fontSize: 11, fontWeight: '700' },
  select: {
    minHeight: 44,
    paddingHorizontal: 11,
    borderWidth: 1,
    borderRadius: 9,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  selectText: { flex: 1, fontSize: 11 },
  pressed: { opacity: 0.78 },
  modalOverlay: { flex: 1, justifyContent: 'flex-end', padding: 14, paddingBottom: 18 },
  sheet: {
    width: '100%',
    maxHeight: '82%',
    borderRadius: 20,
    borderWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: 16,
    paddingTop: 15,
    paddingBottom: 10,
  },
  calendarSheet: {
    width: '100%',
    borderRadius: 20,
    borderWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: 16,
    paddingTop: 15,
    paddingBottom: 15,
  },
  sheetHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingBottom: 12 },
  sheetTitle: { fontSize: 15, fontWeight: '800' },
  searchBox: {
    minHeight: 41,
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 10,
    marginBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  searchInput: { flex: 1, minHeight: 39, fontSize: 12 },
  optionRow: {
    minHeight: 45,
    borderBottomWidth: StyleSheet.hairlineWidth,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  optionText: { flex: 1, fontSize: 12, fontWeight: '600' },
  emptyText: { paddingVertical: 20, fontSize: 12, textAlign: 'center' },
  monthRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 8 },
  monthArrow: { width: 40, height: 38, alignItems: 'center', justifyContent: 'center' },
  monthLabel: { flexDirection: 'row', alignItems: 'center', gap: 6, padding: 5 },
  monthText: { fontSize: 14, fontWeight: '800' },
  weekRow: { flexDirection: 'row', marginTop: 4, marginBottom: 5 },
  weekday: { flex: 1, textAlign: 'center', fontSize: 10, fontWeight: '700' },
  calendarGrid: { flexDirection: 'row', flexWrap: 'wrap' },
  dayCell: { width: `${100 / 7}%`, aspectRatio: 1, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  dayText: { fontSize: 12, fontWeight: '600' },
  todayButton: { minHeight: 37, borderWidth: 1, borderRadius: 19, alignItems: 'center', justifyContent: 'center', marginTop: 10 },
  todayText: { fontSize: 11, fontWeight: '800' },
});
