export type DemoSupportRequest = {
  reference: string;
  topic: string;
  createdAt: string;
};

export function createDemoSupportRequest(topic: string): DemoSupportRequest {
  return {
    reference: `SR-${Date.now().toString().slice(-6)}`,
    topic,
    createdAt: new Date().toISOString(),
  };
}
