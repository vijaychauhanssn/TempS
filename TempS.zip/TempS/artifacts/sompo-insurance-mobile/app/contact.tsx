import React from 'react';
import { Alert, Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppHeader, AppPage, SurfaceCard } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

async function openContact(url: string, fallback: string) {
  try {
    await Linking.openURL(url);
  } catch {
    Alert.alert('Contact support', fallback);
  }
}

export default function ContactScreen() {
  const colors = useColors();
  const contacts = [
    { title: 'Toll Free Number', detail: '1800-22-4030', icon: 'call-outline' as const, url: 'tel:1800224030' },
    { title: 'Toll Free Number', detail: '1800-200-4030', icon: 'call-outline' as const, url: 'tel:18002004030' },
    { title: 'Contact Us', detail: 'contactus@universalsompo.com', icon: 'mail-outline' as const, url: 'mailto:contactus@universalsompo.com' },
  ];

  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="Contact Us" onBack={() => router.back()} />
      <View style={styles.hero}>
        <View style={[styles.heroIcon, { backgroundColor: colors.primaryPale }]}>
          <Ionicons name="call" size={29} color={colors.primary} />
        </View>
        <Text style={[styles.title, { color: colors.foreground }]}>We’re here to help</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Choose a support option to open your phone or email app.
        </Text>
      </View>
      <SurfaceCard style={styles.contactCard}>
        {contacts.map((item, index) => (
          <Pressable
            key={item.detail}
            onPress={() =>
              void openContact(
                item.url,
                `${item.title}: ${item.detail}`,
              )
            }
            accessibilityRole="button"
            style={({ pressed }) => [
              styles.contactRow,
              pressed && styles.pressed,
            ]}
          >
            <View style={[styles.contactIcon, { backgroundColor: colors.primaryWash }]}>
              <Ionicons name={item.icon} size={18} color={colors.primary} />
            </View>
            <View style={styles.contactCopy}>
              <Text style={[styles.contactTitle, { color: colors.foreground }]}>
                {item.title}
              </Text>
              <Text style={[styles.contactDetail, { color: colors.mutedForeground }]}>
                {item.detail}
              </Text>
            </View>
            <Ionicons name="open-outline" size={18} color={colors.foreground} />
            {index < contacts.length - 1 ? (
              <View style={[styles.divider, { backgroundColor: colors.border }]} />
            ) : null}
          </Pressable>
        ))}
      </SurfaceCard>
      <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
        Contact details are shown as supplied in the reference screens. This demo does not send messages or service requests.
      </Text>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 16, gap: 18 },
  hero: { alignItems: 'center', paddingVertical: 20, gap: 9 },
  heroIcon: { width: 68, height: 68, borderRadius: 25, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 23, fontWeight: '800', textAlign: 'center' },
  subtitle: { fontSize: 13, lineHeight: 19, textAlign: 'center', maxWidth: 290 },
  contactCard: { padding: 9, gap: 0 },
  contactRow: { minHeight: 67, flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 6 },
  contactIcon: { width: 38, height: 38, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  contactCopy: { flex: 1, gap: 4 },
  contactTitle: { fontSize: 13, fontWeight: '800' },
  contactDetail: { fontSize: 12 },
  divider: { height: StyleSheet.hairlineWidth, position: 'absolute', left: 54, right: 4, bottom: 0 },
  disclaimer: { fontSize: 10, lineHeight: 15, textAlign: 'center', paddingHorizontal: 8 },
  pressed: { opacity: 0.73 },
});
