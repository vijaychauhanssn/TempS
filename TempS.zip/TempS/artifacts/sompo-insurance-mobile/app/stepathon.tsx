import React, { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Pedometer } from 'expo-sensors';
import { Linking, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppHeader, AppPage, LabeledInput, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

const STEPATHON_KEY = 'universal-sompo:stepathon';
const goalOptions = [5000, 8000, 10000];
const todayKey = () => {
  const date = new Date();
  return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
};

export default function StepathonScreen() {
  const colors = useColors();
  const [goal, setGoal] = useState(8000);
  const [manualSteps, setManualSteps] = useState(0);
  const [manualInput, setManualInput] = useState('');
  const [sensorSteps, setSensorSteps] = useState(0);
  const [sensorAvailable, setSensorAvailable] = useState<boolean | null>(null);
  const [permissionGranted, setPermissionGranted] = useState(false);
  const [canAskAgain, setCanAskAgain] = useState(true);
  const [tracking, setTracking] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [message, setMessage] = useState('');
  const steps = Platform.OS === 'web' || sensorAvailable === false ? manualSteps : sensorSteps;
  const progress = Math.min(steps / goal, 1);

  useEffect(() => {
    let mounted = true;
    void AsyncStorage.getItem(STEPATHON_KEY)
      .then((value) => {
        if (!mounted || !value) return;
        const saved = JSON.parse(value) as { day?: string; goal?: number; manualSteps?: number };
        if (typeof saved.goal === 'number' && goalOptions.includes(saved.goal)) setGoal(saved.goal);
        if (saved.day === todayKey() && typeof saved.manualSteps === 'number') setManualSteps(saved.manualSteps);
      })
      .catch(() => setMessage('Could not restore your saved step goal.'))
      .finally(() => {
        if (mounted) setIsLoaded(true);
      });
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!isLoaded) return;
    void AsyncStorage.setItem(
      STEPATHON_KEY,
      JSON.stringify({ day: todayKey(), goal, manualSteps }),
    ).catch(() => setMessage('Your step goal could not be saved on this device.'));
  }, [goal, isLoaded, manualSteps]);

  useEffect(() => {
    if (Platform.OS === 'web') return;
    let mounted = true;
    void (async () => {
      try {
        const [available, permission] = await Promise.all([
          Pedometer.isAvailableAsync(),
          Pedometer.getPermissionsAsync(),
        ]);
        if (!mounted) return;
        setSensorAvailable(available);
        setPermissionGranted(permission.granted);
        setCanAskAgain(permission.canAskAgain);
        if (!available) setMessage('This device does not provide a step counter. You can enter steps manually.');
        if (available && permission.granted) setTracking(true);
      } catch {
        if (mounted) setSensorAvailable(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!tracking || Platform.OS === 'web') return;
    let mounted = true;
    let subscription: ReturnType<typeof Pedometer.watchStepCount> | undefined;
    void (async () => {
      let startCount = 0;
      if (Platform.OS === 'ios') {
        try {
          const now = new Date();
          const start = new Date(now);
          start.setHours(0, 0, 0, 0);
          startCount = (await Pedometer.getStepCountAsync(start, now)).steps;
        } catch {
          startCount = 0;
        }
      }
      if (!mounted) return;
      setSensorSteps(startCount);
      subscription = Pedometer.watchStepCount(({ steps: newSteps }) => {
        if (mounted) setSensorSteps(startCount + newSteps);
      });
    })();
    return () => {
      mounted = false;
      subscription?.remove();
    };
  }, [tracking]);

  const connectStepCounter = async () => {
    setMessage('');
    try {
      const permission = await Pedometer.requestPermissionsAsync();
      setPermissionGranted(permission.granted);
      setCanAskAgain(permission.canAskAgain);
      if (!permission.granted) {
        setMessage('Step-count permission was not granted. You can enter steps manually instead.');
        return;
      }
      const available = await Pedometer.isAvailableAsync();
      setSensorAvailable(available);
      if (!available) {
        setMessage('A step counter is not available on this device. You can enter steps manually.');
        return;
      }
      setTracking(true);
      setMessage('Device step counting is on while the app is open.');
    } catch {
      setMessage('Could not connect to the device step counter.');
    }
  };

  const saveManualSteps = () => {
    const value = Number(manualInput);
    if (!Number.isInteger(value) || value < 0 || value > 100000) {
      setMessage('Enter a whole number of steps between 0 and 100,000.');
      return;
    }
    setManualSteps(value);
    setManualInput('');
    setMessage('Your step total was saved on this device.');
  };

  const openSettings = () => {
    if (Platform.OS === 'web') return;
    void Linking.openSettings().catch(() => setMessage('Open your device settings to allow motion access.'));
  };

  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="My Stepathon" onBack={() => router.back()} />
      <View style={[styles.hero, { backgroundColor: colors.primaryWash }]}>
        <View style={[styles.heroIcon, { backgroundColor: colors.white }]}>
          <Ionicons name="footsteps-outline" size={26} color={colors.primary} />
        </View>
        <View style={styles.heroCopy}>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>WALK A LITTLE MORE</Text>
          <Text style={[styles.heroTitle, { color: colors.foreground }]}>Your daily challenge</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Choose a goal and track today's steps.</Text>
        </View>
      </View>

      <SurfaceCard style={styles.progressCard}>
        <View style={styles.progressHeading}>
          <View>
            <Text style={[styles.stepsLabel, { color: colors.mutedForeground }]}>TODAY'S STEPS</Text>
            <Text style={[styles.stepsValue, { color: colors.foreground }]}>{steps.toLocaleString()}</Text>
          </View>
          <Text style={[styles.goalText, { color: colors.primary }]}>{goal.toLocaleString()} goal</Text>
        </View>
        <View style={[styles.progressTrack, { backgroundColor: colors.primaryPale }]}>
          <View style={[styles.progressFill, { backgroundColor: colors.primary, width: `${Math.round(progress * 100)}%` }]} />
        </View>
        <Text style={[styles.progressNote, { color: colors.mutedForeground }]}>
          {progress >= 1 ? 'Goal reached. Great work today.' : `${Math.max(goal - steps, 0).toLocaleString()} steps to reach your goal.`}
        </Text>
      </SurfaceCard>

      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Daily step goal</Text>
        <View style={styles.goalOptions}>
          {goalOptions.map((option) => (
            <Pressable
              key={option}
              onPress={() => setGoal(option)}
              style={[
                styles.goalOption,
                { borderColor: goal === option ? colors.primary : colors.border, backgroundColor: goal === option ? colors.primaryWash : colors.card },
              ]}
            >
              <Text style={[styles.goalOptionText, { color: goal === option ? colors.primary : colors.foreground }]}>
                {option.toLocaleString()}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      {Platform.OS === 'web' || sensorAvailable === false ? (
        <SurfaceCard style={styles.manualCard}>
          <Text style={[styles.manualTitle, { color: colors.foreground }]}>Record steps manually</Text>
          <Text style={[styles.manualNote, { color: colors.mutedForeground }]}>
            Step sensors are unavailable in this preview. Enter a step total from your device or wearable.
          </Text>
          <LabeledInput
            label="Today's step total"
            value={manualInput}
            onChangeText={setManualInput}
            placeholder="e.g. 3500"
            keyboardType="number-pad"
          />
          <PrimaryButton label="Save step total" icon="checkmark" onPress={saveManualSteps} />
        </SurfaceCard>
      ) : (
        <SurfaceCard style={styles.sensorCard}>
          <View style={styles.sensorCopy}>
            <Text style={[styles.sensorTitle, { color: colors.foreground }]}>
              {tracking ? 'Device step counter connected' : 'Connect your device step counter'}
            </Text>
            <Text style={[styles.manualNote, { color: colors.mutedForeground }]}>
              Uses your phone’s motion permission. Step updates arrive while the app is open.
            </Text>
          </View>
          {tracking ? (
            <View style={[styles.connectedBadge, { backgroundColor: colors.primaryWash }]}>
              <Ionicons name="checkmark-circle" size={18} color={colors.success} />
              <Text style={[styles.connectedText, { color: colors.success }]}>Connected</Text>
            </View>
          ) : permissionGranted === false && !canAskAgain ? (
            <PrimaryButton label="Open Settings" icon="settings-outline" onPress={openSettings} />
          ) : (
            <PrimaryButton label="Enable step tracking" icon="footsteps-outline" onPress={() => void connectStepCounter()} />
          )}
        </SurfaceCard>
      )}

      {message ? <Text style={[styles.message, { color: colors.mutedForeground }]}>{message}</Text> : null}
      <Pressable onPress={() => router.push('/be-fit')} style={[styles.beFitLink, { borderColor: colors.border }]}>
        <Ionicons name="fitness-outline" size={19} color={colors.primary} />
        <Text style={[styles.beFitText, { color: colors.foreground }]}>Explore Be-Fit classes and nearby centres</Text>
        <Ionicons name="chevron-forward" size={15} color={colors.mutedForeground} />
      </Pressable>
      <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
        Step totals come from your phone sensor or manual entry; no Fitbit account is connected.
      </Text>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 14, gap: 13 },
  hero: { minHeight: 94, borderRadius: 16, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 10 },
  heroIcon: { width: 48, height: 48, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  heroCopy: { flex: 1, gap: 4 },
  eyebrow: { fontSize: 8, fontWeight: '800', letterSpacing: 1 },
  heroTitle: { fontSize: 16, fontWeight: '800' },
  subtitle: { fontSize: 10, lineHeight: 14 },
  progressCard: { padding: 14, gap: 11 },
  progressHeading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  stepsLabel: { fontSize: 8, fontWeight: '800', letterSpacing: 0.7 },
  stepsValue: { fontSize: 29, fontWeight: '800', marginTop: 2 },
  goalText: { fontSize: 10, fontWeight: '800' },
  progressTrack: { height: 10, borderRadius: 6, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 6 },
  progressNote: { fontSize: 9 },
  section: { gap: 7 },
  sectionTitle: { fontSize: 13, fontWeight: '800' },
  goalOptions: { flexDirection: 'row', gap: 8 },
  goalOption: { flex: 1, minHeight: 40, borderWidth: 1, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  goalOptionText: { fontSize: 11, fontWeight: '800' },
  manualCard: { gap: 9, padding: 12 },
  manualTitle: { fontSize: 12, fontWeight: '800' },
  manualNote: { fontSize: 9, lineHeight: 14 },
  sensorCard: { gap: 11, padding: 12 },
  sensorCopy: { gap: 5 },
  sensorTitle: { fontSize: 12, fontWeight: '800' },
  connectedBadge: { alignSelf: 'flex-start', borderRadius: 15, paddingHorizontal: 9, paddingVertical: 6, flexDirection: 'row', alignItems: 'center', gap: 5 },
  connectedText: { fontSize: 9, fontWeight: '800' },
  message: { fontSize: 9, lineHeight: 14 },
  beFitLink: { minHeight: 48, borderWidth: 1, borderRadius: 13, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 8 },
  beFitText: { flex: 1, fontSize: 10, fontWeight: '700' },
  disclaimer: { fontSize: 9, lineHeight: 14, textAlign: 'center' },
});
