import React, { useState } from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { AppHeader, AppPage, LabeledInput, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

const sampleVehicleNumber = 'UP14MH1888';
const sampleChallans = [
  { id: 'UP2898028478293748', date: '12/03/2026', region: 'UP', status: 'PENDING', amount: '₹100', reason: 'Violation of parking rules.' },
  { id: 'UP8284134889381938', date: '11/03/2026', region: 'UP', status: 'DISPOSED', amount: '₹2,000', reason: 'Riding without a helmet.' },
  { id: 'UP2989828478293748', date: '08/03/2026', region: 'UP', status: 'DISPOSED', amount: '₹300', reason: 'Driving in a restricted parking zone.' },
];

export default function MyChallanScreen() {
  const colors = useColors();
  const { vehicleNumber: initialNumber = '' } = useLocalSearchParams<{ vehicleNumber?: string }>();
  const [vehicleNumber, setVehicleNumber] = useState(initialNumber.toUpperCase());
  const [searchedNumber, setSearchedNumber] = useState('');
  const [error, setError] = useState('');

  const submit = () => {
    const normalized = vehicleNumber.toUpperCase().replace(/[\s-]/g, '');
    if (!/^[A-Z]{2}\d{1,2}[A-Z]{0,3}\d{1,4}$/.test(normalized)) {
      setError('Enter a valid vehicle registration number.');
      return;
    }
    setError('');
    setSearchedNumber(normalized);
  };

  const results = searchedNumber === sampleVehicleNumber ? sampleChallans : [];

  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="My Challan" onBack={() => router.back()} />
      <View style={styles.heading}>
        <View style={[styles.headingIcon, { backgroundColor: colors.primaryWash }]}>
          <Image source={require('../assets/images/reference-icons/challan.png')} style={styles.headingImage} resizeMode="contain" />
        </View>
        <View style={styles.headingCopy}>
          <Text style={[styles.title, { color: colors.foreground }]}>Check Your Challan</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Enter vehicle no. to view challan details.</Text>
        </View>
      </View>

      <LabeledInput
        label="Vehicle Number"
        value={vehicleNumber}
        onChangeText={(value) => setVehicleNumber(value.toUpperCase())}
        placeholder="Enter vehicle no."
        autoCapitalize="characters"
      />
      {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
      <PrimaryButton label="Submit" icon="search-outline" onPress={submit} />

      {searchedNumber ? (
        <View style={styles.resultsSection}>
          <View style={styles.resultsHeader}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Challan Amount Details</Text>
            <Text style={[styles.vehicleLabel, { color: colors.mutedForeground }]}>{searchedNumber}</Text>
          </View>
          {results.length ? results.map((challan) => (
            <ChallanCard key={challan.id} challan={challan} />
          )) : (
            <SurfaceCard style={styles.emptyCard}>
              <Ionicons name="checkmark-circle-outline" size={27} color={colors.success} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No sample challans found</Text>
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                This demo does not query live traffic or RTO records.
              </Text>
            </SurfaceCard>
          )}
        </View>
      ) : null}

      <View style={styles.tip}>
        <Ionicons name="information-circle-outline" size={15} color={colors.primary} />
        <Text style={[styles.note, { color: colors.mutedForeground }]}>
          Try {sampleVehicleNumber} to preview the sample challan list. Real challans are not checked.
        </Text>
      </View>
      <Pressable onPress={() => router.push('/my-vehicle')} style={styles.link}>
        <Text style={[styles.linkText, { color: colors.primary }]}>Manage my vehicles</Text>
        <Ionicons name="arrow-forward" size={14} color={colors.primary} />
      </Pressable>
    </AppPage>
  );
}

function ChallanCard({ challan }: { challan: (typeof sampleChallans)[number] }) {
  const colors = useColors();
  const isPending = challan.status === 'PENDING';
  return (
    <SurfaceCard style={styles.challanCard}>
      <View style={[styles.statusBar, { backgroundColor: isPending ? colors.gold : colors.success }]} />
      <View style={styles.challanContent}>
        <View style={styles.challanTop}>
          <Text numberOfLines={1} style={[styles.challanId, { color: colors.foreground }]}>{challan.id}</Text>
          <Text style={[styles.status, { color: isPending ? colors.gold : colors.success }]}>{challan.status}</Text>
        </View>
        <Text style={[styles.challanMeta, { color: colors.mutedForeground }]}>{challan.date} · {challan.region}</Text>
        <View style={styles.challanBottom}>
          <Text style={[styles.reason, { color: colors.mutedForeground }]}>{challan.reason}</Text>
          <Text style={[styles.amount, { color: colors.foreground }]}>{challan.amount}</Text>
        </View>
      </View>
    </SurfaceCard>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 14, gap: 12 },
  heading: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  headingIcon: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  headingImage: { width: 35, height: 35, borderRadius: 12 },
  headingCopy: { flex: 1, gap: 3 },
  title: { fontSize: 15, fontWeight: '800' },
  subtitle: { fontSize: 10, lineHeight: 14 },
  error: { fontSize: 10 },
  resultsSection: { gap: 8, marginTop: 4 },
  resultsHeader: { gap: 3 },
  sectionTitle: { fontSize: 14, fontWeight: '800' },
  vehicleLabel: { fontSize: 9, fontWeight: '700' },
  challanCard: { padding: 0, overflow: 'hidden', flexDirection: 'row', borderRadius: 12 },
  statusBar: { width: 4 },
  challanContent: { flex: 1, padding: 9, gap: 5 },
  challanTop: { flexDirection: 'row', justifyContent: 'space-between', gap: 6 },
  challanId: { flex: 1, fontSize: 10, fontWeight: '800' },
  status: { fontSize: 8, fontWeight: '800' },
  challanMeta: { fontSize: 8 },
  challanBottom: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  reason: { flex: 1, fontSize: 9, lineHeight: 13 },
  amount: { fontSize: 12, fontWeight: '800' },
  emptyCard: { alignItems: 'center', gap: 7, padding: 18 },
  emptyTitle: { fontSize: 12, fontWeight: '800' },
  emptyText: { fontSize: 9, lineHeight: 14, textAlign: 'center' },
  tip: { flexDirection: 'row', alignItems: 'flex-start', gap: 6 },
  note: { flex: 1, fontSize: 9, lineHeight: 14 },
  link: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 5, paddingVertical: 6 },
  linkText: { fontSize: 10, fontWeight: '800' },
});
