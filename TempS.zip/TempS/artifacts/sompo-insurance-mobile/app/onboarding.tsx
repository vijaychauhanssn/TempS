import { OnboardingScreen } from './index';

export default OnboardingScreen;
