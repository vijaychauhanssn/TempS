import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, ScrollView, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { RootStackParamList } from '../../App';
import BrandHeader from '../components/BrandHeader';
import PrimaryButton from '../components/PrimaryButton';
import { colors } from '../theme/colors';

type Props = NativeStackScreenProps<RootStackParamList, 'Login'>;
export default function LoginScreen({ navigation }: Props) {
  const [mobile, setMobile] = useState('');
  const [otp, setOtp] = useState('');
  const [sent, setSent] = useState(false);
  const [role, setRole] = useState<'individual' | 'corporate'>('individual');
  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: '#FFF' }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <BrandHeader />
      <ScrollView contentContainerStyle={styles.page} keyboardShouldPersistTaps="handled">
        <Text style={styles.welcome}>Welcome to Universal Sompo</Text>
        <Text style={styles.subtitle}>Sign in to access your insurance services.</Text>
        <View style={styles.roleRow}>
          <Text onPress={() => setRole('individual')} style={[styles.role, role === 'individual' && styles.roleActive]}>Individual</Text>
          <Text onPress={() => setRole('corporate')} style={[styles.role, role === 'corporate' && styles.roleActive]}>Corporate</Text>
        </View>
        <Text style={styles.label}>Mobile number</Text>
        <View style={styles.inputWrap}><Ionicons name="call-outline" size={19} color={colors.muted}/><TextInput value={mobile} onChangeText={setMobile} placeholder="Enter registered mobile number" keyboardType="phone-pad" maxLength={10} style={styles.input}/></View>
        {sent && <><Text style={styles.label}>OTP</Text><View style={styles.inputWrap}><Ionicons name="keypad-outline" size={19} color={colors.muted}/><TextInput value={otp} onChangeText={setOtp} placeholder="Enter OTP" keyboardType="number-pad" maxLength={6} style={styles.input}/></View></>}
        <PrimaryButton title={sent ? 'Verify & Continue' : 'Send OTP'} onPress={() => {
          if (mobile.length !== 10) { Alert.alert('Check mobile number', 'Enter a 10-digit mobile number.'); return; }
          if (!sent) { setSent(true); Alert.alert('Demo flow', 'OTP sending is not connected to a backend yet.'); return; }
          if (otp.length < 4) { Alert.alert('Check OTP', 'Enter the OTP from your service.'); return; }
          navigation.replace('Main');
        }} style={{ marginTop: 22 }} />
        <Text style={styles.or}>OR</Text>
        <PrimaryButton title="Continue as demo user" secondary onPress={() => navigation.replace('Main')} />
        <Text style={styles.terms}>By continuing, you agree to the Terms & Conditions and Privacy Policy.</Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
const styles = StyleSheet.create({
  page: { padding: 22, flexGrow: 1 },
  welcome: { fontSize: 23, color: colors.text, fontWeight: '800', marginTop: 24 },
  subtitle: { color: colors.muted, fontSize: 13, lineHeight: 20, marginTop: 8, marginBottom: 22 },
  roleRow: { flexDirection: 'row', padding: 4, backgroundColor: colors.background, borderRadius: 14, marginBottom: 22 },
  role: { flex: 1, textAlign: 'center', paddingVertical: 12, color: colors.muted, borderRadius: 11, overflow: 'hidden', fontWeight: '600' },
  roleActive: { color: colors.primary, backgroundColor: '#FFF', elevation: 1 },
  label: { fontSize: 13, fontWeight: '700', color: colors.text, marginBottom: 8, marginTop: 12 },
  inputWrap: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: colors.border, borderRadius: 12, paddingHorizontal: 12 },
  input: { flex: 1, paddingVertical: 14, paddingHorizontal: 9, color: colors.text },
  or: { textAlign: 'center', color: colors.muted, marginVertical: 18, fontSize: 12 },
  terms: { textAlign: 'center', color: colors.muted, fontSize: 11, lineHeight: 18, marginTop: 28 },
});