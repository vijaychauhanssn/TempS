import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppHeader, AppPage, SurfaceCard } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

const claimActions = [
  { label: 'Claim Intimation', icon: 'document-text-outline' as const, action: 'initiate' },
  { label: 'Claim Status', icon: 'clipboard-outline' as const, action: 'status' },
  { label: 'Download Claim Forms', icon: 'download-outline' as const, action: 'forms' },
];

function ClaimGroup({ title, type }: { title: string; type: 'Health' | 'Motor' }) {
  const colors = useColors();
  return (
    <View style={styles.group}>
      <Text style={[styles.groupTitle, { color: colors.foreground }]}>{title}</Text>
      <SurfaceCard style={styles.actionCard}>
        {claimActions.map((item, index) => (
          <React.Fragment key={item.action}>
            {index > 0 ? <View style={[styles.divider, { backgroundColor: colors.border }]} /> : null}
            <Pressable
              accessibilityRole="button"
              onPress={() =>
                router.push({
                  pathname: '/kbl-details',
                  params: { action: item.action, claimType: type },
                })
              }
              style={({ pressed }) => [styles.actionRow, pressed && styles.pressed]}
            >
              <View style={[styles.actionIcon, { backgroundColor: colors.primaryWash }]}>
                <Ionicons name={item.icon} size={20} color={colors.primary} />
              </View>
              <Text style={[styles.actionLabel, { color: colors.foreground }]}>{item.label}</Text>
              <Ionicons name="arrow-forward" size={16} color={colors.mutedForeground} />
            </Pressable>
          </React.Fragment>
        ))}
      </SurfaceCard>
    </View>
  );
}

export default function ClaimsScreen() {
  const colors = useColors();
  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="Claim" onBack={() => router.back()} />
      <View style={[styles.intro, { backgroundColor: colors.primaryWash }]}>
        <Ionicons name="shield-checkmark-outline" size={23} color={colors.primary} />
        <Text style={[styles.introText, { color: colors.foreground }]}>
          Start a claim, check its status, or view the forms you may need.
        </Text>
      </View>
      <ClaimGroup title="Health Claim" type="Health" />
      <ClaimGroup title="Motor Claim" type="Motor" />
      <Text style={[styles.note, { color: colors.mutedForeground }]}>
        This demo uses sample claim information and does not submit a request to the insurer.
      </Text>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 13, gap: 12 },
  intro: { borderRadius: 12, padding: 11, flexDirection: 'row', alignItems: 'center', gap: 9 },
  introText: { flex: 1, fontSize: 11, lineHeight: 16, fontWeight: '600' },
  group: { gap: 7 },
  groupTitle: { fontSize: 14, fontWeight: '800' },
  actionCard: { paddingHorizontal: 10, paddingVertical: 4, gap: 1, borderRadius: 15 },
  actionRow: { minHeight: 52, flexDirection: 'row', alignItems: 'center', gap: 9 },
  actionIcon: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  actionLabel: { flex: 1, fontSize: 11, fontWeight: '700' },
  divider: { height: StyleSheet.hairlineWidth, marginLeft: 42 },
  note: { fontSize: 9, lineHeight: 14, textAlign: 'center', paddingHorizontal: 10 },
  pressed: { opacity: 0.73 },
});
