import React from 'react';
import { Pressable, Text, StyleSheet, ViewStyle } from 'react-native';
import { colors } from '../theme/colors';

export default function PrimaryButton({ title, onPress, secondary = false, style }: {
  title: string; onPress: () => void; secondary?: boolean; style?: ViewStyle;
}) {
  return (
    <Pressable onPress={onPress} style={[styles.button, secondary && styles.secondary, style]}>
      <Text style={[styles.label, secondary && styles.secondaryLabel]}>{title}</Text>
    </Pressable>
  );
}
const styles = StyleSheet.create({
  button: { minHeight: 48, borderRadius: 25, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 18 },
  secondary: { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: colors.primary },
  label: { color: '#FFFFFF', fontWeight: '700', fontSize: 15 },
  secondaryLabel: { color: colors.primary },
});