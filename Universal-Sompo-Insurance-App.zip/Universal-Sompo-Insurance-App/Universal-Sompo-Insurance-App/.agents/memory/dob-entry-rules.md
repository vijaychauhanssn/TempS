---
name: DOB entry rules
description: Project requirement for editable date-of-birth fields across the mobile app.
---

Every editable DOB field in the Universal Sompo mobile app must use the shared calendar picker, not free-text date entry. DOB selection must disallow future dates and preserve the format expected by the existing flow.

**Why:** The user explicitly requested date pickers for all DOB fields and corrected a partial implementation.

**How to apply:** When adding or changing a screen with DOB, search all app routes for DOB/date-of-birth fields and confirm each editable field uses the shared picker.
