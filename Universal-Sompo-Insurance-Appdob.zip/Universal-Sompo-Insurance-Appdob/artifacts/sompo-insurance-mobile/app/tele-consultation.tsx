import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppHeader, LabeledInput, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { DatePickerField, isValidDateValue } from '@/components/FormFields';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';
import { createDemoHealthReference } from '@/src/services/healthService';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function TeleConsultationScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [reason, setReason] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [error, setError] = useState('');
  const [reference, setReference] = useState('');

  const submit = () => {
    if (reason.trim().length < 8 || !isValidDateValue(date) || !/^\d{1,2}:\d{2}\s?(AM|PM)$/i.test(time.trim())) {
      setError('Add a consultation reason, choose a date, and enter a time (e.g. 10:30 AM).');
      return;
    }
    setError('');
    setReference(createDemoHealthReference('KBL'));
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.page, { backgroundColor: colors.screen }]}
      contentContainerStyle={[
        styles.content,
        { paddingTop: Math.max(insets.top, 12) + 6, paddingBottom: Math.max(insets.bottom, 12) + 20 },
      ]}
      bottomOffset={72}
      keyboardShouldPersistTaps="handled"
    >
      <AppHeader title="Tele Consulting" onBack={() => router.back()} />
      <View style={[styles.brandStrip, { backgroundColor: colors.primary }]}>
        <View style={styles.brand}>
          <Ionicons name="shield-checkmark" size={14} color={colors.primary} />
          <Text style={[styles.brandText, { color: colors.primaryDeep }]}>Universal Sompo</Text>
        </View>
        <View style={styles.kbl}>
          <Ionicons name="business-outline" size={14} color={colors.white} />
          <Text style={[styles.brandText, { color: colors.white }]}>Karnataka Bank</Text>
        </View>
      </View>

      {!reference ? (
        <>
          <View style={styles.hero}>
            <View style={styles.heroCopy}>
              <Text style={[styles.heroTitle, { color: colors.foreground }]}>Book A Consultation</Text>
              <Text style={[styles.heroDetail, { color: colors.mutedForeground }]}>
                We’re here to help you.
              </Text>
            </View>
            <View style={[styles.heroIcon, { backgroundColor: colors.primaryWash }]}>
              <Ionicons name="calendar-outline" size={33} color={colors.primary} />
              <Ionicons name="medical" size={19} color={colors.success} style={styles.medicalIcon} />
            </View>
          </View>
          <SurfaceCard style={styles.formCard}>
            <LabeledInput
              label="Reason for Consultation *"
              value={reason}
              onChangeText={setReason}
              placeholder="Please describe more about your issue"
              multiline
              maxLength={250}
              style={styles.reason}
            />
            <Text style={[styles.counter, { color: colors.mutedForeground }]}>{reason.length}/250</Text>
            <View style={styles.twoColumns}>
              <DatePickerField
                label="Select date *"
                value={date}
                onChange={setDate}
                displayFormat="DD/MM/YYYY"
                minDate={new Date()}
                testID="teleconsult-date"
              />
              <LabeledInput
                label="Time *"
                value={time}
                onChangeText={setTime}
                placeholder="e.g. 10:00 AM"
                autoCapitalize="characters"
              />
            </View>
            {error ? <Text accessibilityRole="alert" style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
          </SurfaceCard>
          <View style={styles.footer}>
            <PrimaryButton label="Submit demo request" icon="arrow-forward" onPress={submit} />
          </View>
          <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
            Demo only. No doctor is booked and no medical advice is provided by this screen.
          </Text>
        </>
      ) : (
        <SurfaceCard style={styles.successCard}>
          <View style={[styles.successIcon, { backgroundColor: colors.primaryWash }]}>
            <Ionicons name="checkmark" size={29} color={colors.success} />
          </View>
          <Text style={[styles.heroTitle, { color: colors.foreground }]}>Request saved</Text>
          <Text style={[styles.heroDetail, { color: colors.mutedForeground }]}>
            Demo reference {reference}. No consultation has been scheduled.
          </Text>
          <PrimaryButton label="Back to KBL services" onPress={() => router.replace('/kbl')} />
        </SurfaceCard>
      )}
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 14, gap: 12 },
  brandStrip: { minHeight: 42, marginHorizontal: -14, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  brand: { backgroundColor: '#ffffff', borderRadius: 10, paddingHorizontal: 8, paddingVertical: 6, flexDirection: 'row', alignItems: 'center', gap: 4 },
  kbl: { backgroundColor: 'rgba(60,0,80,0.45)', borderRadius: 10, paddingHorizontal: 8, paddingVertical: 6, flexDirection: 'row', alignItems: 'center', gap: 4 },
  brandText: { fontSize: 8, fontWeight: '800' },
  hero: { minHeight: 130, flexDirection: 'row', alignItems: 'center', gap: 10 },
  heroCopy: { flex: 1, gap: 5 },
  heroTitle: { fontSize: 17, lineHeight: 22, fontWeight: '800' },
  heroDetail: { fontSize: 10, lineHeight: 15 },
  heroIcon: { width: 91, height: 91, borderRadius: 35, alignItems: 'center', justifyContent: 'center' },
  medicalIcon: { position: 'absolute', right: 10, bottom: 11 },
  formCard: { gap: 9, padding: 11 },
  reason: { minHeight: 96, textAlignVertical: 'top', paddingTop: 10 },
  counter: { alignSelf: 'flex-end', marginTop: -5, fontSize: 8 },
  twoColumns: { flexDirection: 'row', gap: 8 },
  error: { fontSize: 9, lineHeight: 14 },
  footer: { marginTop: 'auto' },
  disclaimer: { fontSize: 8, textAlign: 'center', lineHeight: 13 },
  successCard: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, padding: 20 },
  successIcon: { width: 57, height: 57, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
});
