import React, { useState } from 'react';
import { Alert, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppHeader, LabeledInput, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';

const requestTypes = ['Policy details', 'Payment', 'Claim', 'Update profile'];

export default function ServiceRequestScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { mode = 'register' } = useLocalSearchParams<{ mode?: string }>();
  const [requestType, setRequestType] = useState('Policy details');
  const [description, setDescription] = useState('');
  const [reference, setReference] = useState('');
  const [result, setResult] = useState(false);
  const [error, setError] = useState('');
  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;
  const tracking = mode === 'track';

  const submit = () => {
    if (!description.trim() || (tracking && description.trim().length < 5)) {
      setError(tracking ? 'Enter a request reference with at least 5 characters.' : 'Describe the help you need.');
      return;
    }
    setError('');
    if (tracking) {
      setResult(true);
    } else {
      setReference(`SR-DEMO-${Date.now().toString().slice(-6)}`);
    }
  };

  const title = tracking ? 'Service Request Tracker' : 'Service Request';
  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.page, { backgroundColor: colors.screen }]}
      contentContainerStyle={[styles.content, { paddingTop: topInset + 8, paddingBottom: bottomInset + 22 }]}
      bottomOffset={70}
      keyboardShouldPersistTaps="handled"
    >
      <AppHeader title={title} onBack={() => router.back()} />
      {tracking ? (
        <>
          <View style={[styles.info, { backgroundColor: colors.primaryWash }]}>
            <Ionicons name="search-outline" size={20} color={colors.primary} />
            <Text style={[styles.infoText, { color: colors.foreground }]}>Enter a service request reference to check its sample status.</Text>
          </View>
          <LabeledInput label="Request Reference *" value={description} onChangeText={setDescription} placeholder="e.g. SR-DEMO-123456" autoCapitalize="characters" />
          {result ? (
            <SurfaceCard style={styles.statusCard}>
              <View style={[styles.statusIcon, { backgroundColor: colors.primaryWash }]}>
                <Ionicons name="time-outline" size={23} color={colors.primary} />
              </View>
              <Text style={[styles.statusTitle, { color: colors.foreground }]}>Sample request received</Text>
              <Text style={[styles.body, { color: colors.mutedForeground }]}>
                {description.toUpperCase()} · In progress
              </Text>
              <Text style={[styles.note, { color: colors.mutedForeground }]}>
                This status is illustrative and not connected to the insurer.
              </Text>
            </SurfaceCard>
          ) : null}
        </>
      ) : reference ? (
        <SurfaceCard style={styles.statusCard}>
          <View style={[styles.statusIcon, { backgroundColor: colors.primaryWash }]}>
            <Ionicons name="checkmark" size={25} color={colors.success} />
          </View>
          <Text style={[styles.statusTitle, { color: colors.foreground }]}>Request saved</Text>
          <Text style={[styles.body, { color: colors.mutedForeground }]}>Reference {reference}</Text>
          <Text style={[styles.note, { color: colors.mutedForeground }]}>Saved locally for demonstration. It was not sent to support.</Text>
        </SurfaceCard>
      ) : (
        <>
          <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Select a request type</Text>
          <View style={styles.typeList}>
            {requestTypes.map((item) => (
              <Pressable
                key={item}
                onPress={() => setRequestType(item)}
                style={[styles.typeChip, { backgroundColor: requestType === item ? colors.primary : colors.card, borderColor: requestType === item ? colors.primary : colors.border }]}
              >
                <Text style={[styles.typeText, { color: requestType === item ? colors.white : colors.foreground }]}>{item}</Text>
              </Pressable>
            ))}
          </View>
          <LabeledInput
            label="How can we help? *"
            value={description}
            onChangeText={setDescription}
            placeholder="Describe your request"
            multiline
            style={styles.multiline}
          />
        </>
      )}
      {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
      {(!tracking && !reference) || (tracking && !result) ? (
        <View style={styles.footer}>
          <PrimaryButton label={tracking ? 'Track Request' : 'Submit Request'} icon="arrow-forward" onPress={submit} />
        </View>
      ) : null}
      {tracking && result ? (
        <PrimaryButton label="Search another request" icon="refresh-outline" onPress={() => { setResult(false); setDescription(''); }} />
      ) : null}
      <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>Service requests are local demo records only.</Text>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 15, gap: 13 },
  info: { padding: 11, borderRadius: 12, flexDirection: 'row', alignItems: 'center', gap: 8 },
  infoText: { flex: 1, fontSize: 10, lineHeight: 15 },
  fieldLabel: { fontSize: 11, fontWeight: '700' },
  typeList: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  typeChip: { minHeight: 34, borderWidth: 1, borderRadius: 17, paddingHorizontal: 10, alignItems: 'center', justifyContent: 'center' },
  typeText: { fontSize: 9, fontWeight: '700' },
  multiline: { minHeight: 100, textAlignVertical: 'top', paddingTop: 11 },
  error: { fontSize: 10, lineHeight: 15 },
  footer: { marginTop: 'auto', paddingTop: 10 },
  statusCard: { alignItems: 'center', gap: 9, padding: 20 },
  statusIcon: { width: 51, height: 51, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  statusTitle: { fontSize: 17, fontWeight: '800' },
  body: { fontSize: 11, lineHeight: 16 },
  note: { fontSize: 9, textAlign: 'center', lineHeight: 14 },
  disclaimer: { fontSize: 9, textAlign: 'center', lineHeight: 14 },
});
