import React, { useMemo, useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  AppHeader,
  LabeledInput,
  PrimaryButton,
  SurfaceCard,
} from '@/components/AppUI';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';

const steps = ['Plan', 'Details', 'KYC', 'Review'];
const idvOptions = ['₹65,900', '₹85,927', '₹1,00,000'];
const addOns = ['Electrical Accessory', 'Consumables', 'Roadside Assistance'];

function Stepper({ step }: { step: number }) {
  const colors = useColors();
  return (
    <View style={styles.stepper}>
      {steps.map((label, index) => {
        const current = index + 1;
        const active = step >= current;
        return (
          <View key={label} style={styles.stepItem}>
            <View style={styles.stepLineRow}>
              {index > 0 ? <View style={[styles.stepLine, { backgroundColor: active ? colors.primary : colors.border }]} /> : null}
              <View style={[styles.stepCircle, { backgroundColor: active ? colors.primary : colors.card, borderColor: active ? colors.primary : colors.border }]}>
                <Text style={[styles.stepNumber, { color: active ? colors.white : colors.mutedForeground }]}>{current}</Text>
              </View>
              {index < steps.length - 1 ? <View style={[styles.stepLine, { backgroundColor: step > current ? colors.primary : colors.border }]} /> : null}
            </View>
            <Text style={[styles.stepLabel, { color: active ? colors.primary : colors.mutedForeground }]}>{label}</Text>
          </View>
        );
      })}
    </View>
  );
}

function ChoicePill({
  label,
  active,
  onPress,
}: {
  label: string;
  active: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={[
        styles.choicePill,
        {
          backgroundColor: active ? colors.primary : colors.card,
          borderColor: active ? colors.primary : colors.border,
        },
      ]}
    >
      <Text style={[styles.choiceText, { color: active ? colors.white : colors.foreground }]}>{label}</Text>
    </Pressable>
  );
}

export default function MotorQuoteScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{
    vehicle?: string;
    registration?: string;
    brand?: string;
    model?: string;
    registrationYear?: string;
    state?: string;
    rto?: string;
  }>();
  const vehicle = params.vehicle ?? 'Four Wheeler';
  const [step, setStep] = useState(1);
  const [plan, setPlan] = useState('Comprehensive');
  const [duration, setDuration] = useState('1 Year');
  const [idv, setIdv] = useState(idvOptions[1]);
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([]);
  const [kycName, setKycName] = useState('');
  const [gender, setGender] = useState('');
  const [dob, setDob] = useState('');
  const [idType, setIdType] = useState('Aadhaar');
  const [idNumber, setIdNumber] = useState('');
  const [mobile, setMobile] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [pincode, setPincode] = useState('');
  const [stateName, setStateName] = useState(params.state ?? '');
  const [city, setCity] = useState('');
  const [error, setError] = useState('');
  const [quoteRef, setQuoteRef] = useState('');
  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;

  const premium = useMemo(() => {
    const base = plan === 'Comprehensive' ? 15051 : 10500;
    const addons = selectedAddOns.length * 415;
    const subtotal = base + addons;
    const tax = Math.round(subtotal * 0.18);
    return { subtotal, tax, total: subtotal + tax };
  }, [plan, selectedAddOns]);

  const toggleAddOn = (item: string) => {
    setSelectedAddOns((current) =>
      current.includes(item) ? current.filter((value) => value !== item) : [...current, item],
    );
  };

  const nextStep = () => {
    if (step === 1) {
      setStep(2);
      setError('');
      return;
    }
    if (step === 2) {
      if (!kycName.trim() || !gender || !/^\d{2}\/\d{2}\/\d{4}$/.test(dob) || idNumber.trim().length < 4 || mobile.replace(/\D/g, '').length < 10) {
        setError('Complete the required KYC details before continuing.');
        return;
      }
      setError('');
      setStep(3);
      return;
    }
    if (step === 3) {
      if (!ownerName.trim() || !/^\S+@\S+\.\S+$/.test(email) || !address.trim() || pincode.replace(/\D/g, '').length !== 6 || !stateName || !city) {
        setError('Complete the owner details, a valid email and 6-digit pincode.');
        return;
      }
      setError('');
      setStep(4);
      return;
    }
    if (step === 4) {
      setQuoteRef(`DEMO-${Date.now().toString().slice(-6)}`);
      setStep(5);
    }
  };

  const label = step <= 4 ? steps[step - 1] : 'Saved';

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.page, { backgroundColor: colors.screen }]}
      contentContainerStyle={[
        styles.content,
        { paddingTop: topInset + 8, paddingBottom: bottomInset + 24 },
      ]}
      bottomOffset={70}
      keyboardShouldPersistTaps="handled"
    >
      <AppHeader title={`${vehicle} Insurance`} onBack={() => router.back()} />
      {step <= 4 ? <Stepper step={step} /> : null}
      {step <= 4 ? (
        <Text style={[styles.stepCaption, { color: colors.primary }]}>
          Step {step} of 4 · {label}
        </Text>
      ) : null}

      {step === 1 ? (
        <>
          <SurfaceCard style={styles.vehicleSummary}>
            <View style={[styles.summaryIcon, { backgroundColor: colors.primaryWash }]}>
              <Ionicons name={vehicle.toLowerCase().includes('two') ? 'bicycle-outline' : 'car-sport-outline'} size={21} color={colors.primary} />
            </View>
            <View style={styles.summaryCopy}>
              <Text style={[styles.summaryTitle, { color: colors.foreground }]}>{params.brand ?? 'Maruti Suzuki'} {params.model ?? 'Vehicle'}</Text>
              <Text style={[styles.summaryDetail, { color: colors.mutedForeground }]}>{params.registration ?? 'DEMO-01'} · {params.registrationYear ?? '2022'}</Text>
            </View>
            <Pressable onPress={() => router.replace({ pathname: '/vehicle-details', params: { vehicle } })}>
              <Text style={[styles.link, { color: colors.primary }]}>Edit</Text>
            </Pressable>
          </SurfaceCard>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Select Plan & Duration</Text>
          <View style={styles.planOptions}>
            {[
              { name: 'Comprehensive', detail: 'Own damage + third-party', amount: '₹17,760' },
              { name: 'Third Party', detail: 'Third-party liability cover', amount: '₹12,390' },
            ].map((option) => {
              const active = plan === option.name;
              return (
                <Pressable
                  key={option.name}
                  onPress={() => setPlan(option.name)}
                  style={[
                    styles.planOption,
                    {
                      backgroundColor: colors.card,
                      borderColor: active ? colors.primary : colors.border,
                    },
                  ]}
                >
                  <Ionicons name={active ? 'radio-button-on' : 'radio-button-off'} size={18} color={active ? colors.primary : colors.mutedForeground} />
                  <View style={styles.planOptionCopy}>
                    <Text style={[styles.planOptionTitle, { color: colors.foreground }]}>{option.name}</Text>
                    <Text style={[styles.planOptionDetail, { color: colors.mutedForeground }]}>{option.detail}</Text>
                  </View>
                  <Text style={[styles.planAmount, { color: colors.primary }]}>{option.amount}</Text>
                </Pressable>
              );
            })}
          </View>
          <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Policy duration</Text>
          <View style={styles.pillRow}>
            {['1 Year', '2 Years', '3 Years'].map((item) => (
              <ChoicePill key={item} label={item} active={duration === item} onPress={() => setDuration(item)} />
            ))}
          </View>
          <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Select the right IDV for you</Text>
          <Text style={[styles.helper, { color: colors.mutedForeground }]}>Choose an insured declared value that fits your vehicle.</Text>
          <View style={styles.pillRow}>
            {idvOptions.map((item) => (
              <ChoicePill key={item} label={item} active={idv === item} onPress={() => setIdv(item)} />
            ))}
          </View>
          <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Add-ons & Coverages</Text>
          {addOns.map((item) => (
            <Pressable key={item} onPress={() => toggleAddOn(item)} style={styles.addOnRow}>
              <Ionicons
                name={selectedAddOns.includes(item) ? 'checkbox' : 'square-outline'}
                size={19}
                color={selectedAddOns.includes(item) ? colors.primary : colors.mutedForeground}
              />
              <Text style={[styles.addOnText, { color: colors.foreground }]}>{item}</Text>
              <Text style={[styles.addOnPrice, { color: colors.mutedForeground }]}>+ ₹415</Text>
            </Pressable>
          ))}
          <PremiumSummary subtotal={premium.subtotal} tax={premium.tax} total={premium.total} />
          <PrimaryButton label="Continue" icon="arrow-forward" onPress={nextStep} />
        </>
      ) : null}

      {step === 2 ? (
        <>
          <SectionLabel title="KYC Details" icon="person-outline" />
          <LabeledInput label="Name *" value={kycName} onChangeText={setKycName} placeholder="Enter your name" />
          <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Gender *</Text>
          <View style={styles.pillRow}>
            {['Male', 'Female', 'Other'].map((item) => (
              <ChoicePill key={item} label={item} active={gender === item} onPress={() => setGender(item)} />
            ))}
          </View>
          <LabeledInput label="Date of Birth *" value={dob} onChangeText={setDob} placeholder="DD/MM/YYYY" keyboardType="numbers-and-punctuation" maxLength={10} />
          <Text style={[styles.fieldLabel, { color: colors.foreground }]}>ID Type *</Text>
          <View style={styles.pillRow}>
            {['Aadhaar', 'PAN', 'Driving licence'].map((item) => (
              <ChoicePill key={item} label={item} active={idType === item} onPress={() => setIdType(item)} />
            ))}
          </View>
          <LabeledInput label="ID Number *" value={idNumber} onChangeText={setIdNumber} placeholder={`Enter ${idType} number`} autoCapitalize="characters" />
          <LabeledInput label="Mobile Number *" value={mobile} onChangeText={setMobile} placeholder="+91 98765 43210" keyboardType="phone-pad" maxLength={13} />
          {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
          <PrimaryButton label="Submit KYC" icon="arrow-forward" onPress={nextStep} />
        </>
      ) : null}

      {step === 3 ? (
        <>
          <SectionLabel title="Owner Details" icon="person-circle-outline" />
          <Text style={[styles.helper, { color: colors.mutedForeground }]}>Enter the registered owner’s details.</Text>
          <LabeledInput label="Full Name *" value={ownerName} onChangeText={setOwnerName} placeholder="Enter full name" />
          <LabeledInput label="Email ID *" value={email} onChangeText={setEmail} placeholder="name@example.com" keyboardType="email-address" autoCapitalize="none" />
          <LabeledInput label="Registered Address *" value={address} onChangeText={setAddress} placeholder="Enter your address" multiline style={styles.addressInput} />
          <LabeledInput label="Pincode *" value={pincode} onChangeText={(value) => setPincode(value.replace(/\D/g, '').slice(0, 6))} placeholder="6-digit pincode" keyboardType="number-pad" maxLength={6} />
          <LabeledInput label="State *" value={stateName} onChangeText={setStateName} placeholder="Enter state" />
          <LabeledInput label="City *" value={city} onChangeText={setCity} placeholder="Enter city" />
          {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
          <PrimaryButton label="Review details" icon="arrow-forward" onPress={nextStep} />
        </>
      ) : null}

      {step === 4 ? (
        <>
          <View style={[styles.reviewBanner, { backgroundColor: colors.primaryWash }]}>
            <Ionicons name="checkmark-circle" size={25} color={colors.success} />
            <Text style={[styles.reviewBannerText, { color: colors.foreground }]}>Review your details before continuing.</Text>
          </View>
          <SurfaceCard style={styles.reviewCard}>
            <ReviewLine label="Vehicle" value={`${params.brand ?? 'Maruti Suzuki'} ${params.model ?? ''}`} />
            <ReviewLine label="Registration" value={params.registration ?? 'DEMO-01'} />
            <ReviewLine label="Owner" value={ownerName} />
            <ReviewLine label="Contact" value={`${mobile} · ${email}`} />
            <ReviewLine label="Policy plan" value={`${plan} · ${duration}`} />
            <ReviewLine label="IDV" value={idv} />
            <ReviewLine label="Add-ons" value={selectedAddOns.length ? selectedAddOns.join(', ') : 'None selected'} />
          </SurfaceCard>
          <PremiumSummary subtotal={premium.subtotal} tax={premium.tax} total={premium.total} />
          <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
            Illustrative estimate only. No payment will be taken.
          </Text>
          <PrimaryButton label="Continue to payment" icon="arrow-forward" onPress={nextStep} />
        </>
      ) : null}

      {step === 5 ? (
        <SurfaceCard style={styles.savedCard}>
          <View style={[styles.savedIcon, { backgroundColor: colors.primaryWash }]}>
            <Ionicons name="checkmark" size={29} color={colors.success} />
          </View>
          <Text style={[styles.savedTitle, { color: colors.foreground }]}>Demo quote saved</Text>
          <Text style={[styles.helper, { color: colors.mutedForeground }]}>
            Reference {quoteRef} · {vehicle} · ₹{premium.total.toLocaleString('en-IN')}
          </Text>
          <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
            This is not an insurer quote and no payment or policy was created.
          </Text>
          <PrimaryButton label="Back to Home" icon="home-outline" onPress={() => router.replace('/(tabs)/home')} />
        </SurfaceCard>
      ) : null}
      {error && step === 1 ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
    </KeyboardAwareScrollViewCompat>
  );
}

function SectionLabel({ title, icon }: { title: string; icon: keyof typeof Ionicons.glyphMap }) {
  const colors = useColors();
  return (
    <View style={[styles.sectionLabel, { backgroundColor: colors.primaryWash }]}>
      <Ionicons name={icon} size={18} color={colors.primary} />
      <Text style={[styles.sectionLabelText, { color: colors.primary }]}>{title}</Text>
    </View>
  );
}

function PremiumSummary({
  subtotal,
  tax,
  total,
}: {
  subtotal: number;
  tax: number;
  total: number;
}) {
  const colors = useColors();
  return (
    <SurfaceCard style={styles.premiumCard}>
      <View style={styles.premiumLine}>
        <Text style={[styles.premiumLabel, { color: colors.mutedForeground }]}>Net premium</Text>
        <Text style={[styles.premiumValue, { color: colors.foreground }]}>₹{subtotal.toLocaleString('en-IN')}</Text>
      </View>
      <View style={styles.premiumLine}>
        <Text style={[styles.premiumLabel, { color: colors.mutedForeground }]}>GST (18%)</Text>
        <Text style={[styles.premiumValue, { color: colors.foreground }]}>₹{tax.toLocaleString('en-IN')}</Text>
      </View>
      <View style={[styles.totalLine, { borderTopColor: colors.border }]}>
        <Text style={[styles.totalLabel, { color: colors.primary }]}>Total premium</Text>
        <Text style={[styles.totalValue, { color: colors.primary }]}>₹{total.toLocaleString('en-IN')}</Text>
      </View>
    </SurfaceCard>
  );
}

function ReviewLine({ label, value }: { label: string; value: string }) {
  const colors = useColors();
  return (
    <View style={styles.reviewLine}>
      <Text style={[styles.reviewLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.reviewValue, { color: colors.foreground }]}>{value || 'Not provided'}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 15, gap: 11 },
  stepper: { flexDirection: 'row', alignItems: 'flex-start', marginHorizontal: 2 },
  stepItem: { flex: 1, alignItems: 'center', gap: 4 },
  stepLineRow: { flexDirection: 'row', alignItems: 'center', width: '100%' },
  stepCircle: { width: 23, height: 23, borderRadius: 12, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  stepNumber: { fontSize: 10, fontWeight: '800' },
  stepLine: { flex: 1, height: 2 },
  stepLabel: { fontSize: 9, fontWeight: '700' },
  stepCaption: { fontSize: 10, fontWeight: '800' },
  vehicleSummary: { flexDirection: 'row', alignItems: 'center', gap: 9, padding: 10 },
  summaryIcon: { width: 39, height: 39, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  summaryCopy: { flex: 1, gap: 3 },
  summaryTitle: { fontSize: 12, fontWeight: '800' },
  summaryDetail: { fontSize: 10 },
  link: { fontSize: 10, fontWeight: '800' },
  sectionTitle: { fontSize: 14, fontWeight: '800' },
  planOptions: { gap: 8 },
  planOption: { minHeight: 57, borderRadius: 12, borderWidth: 1, padding: 9, flexDirection: 'row', alignItems: 'center', gap: 8 },
  planOptionCopy: { flex: 1, gap: 3 },
  planOptionTitle: { fontSize: 11, fontWeight: '800' },
  planOptionDetail: { fontSize: 9 },
  planAmount: { fontSize: 10, fontWeight: '800' },
  fieldLabel: { fontSize: 11, fontWeight: '700', marginTop: 1 },
  helper: { fontSize: 10, lineHeight: 15 },
  pillRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  choicePill: { minHeight: 33, borderWidth: 1, borderRadius: 17, paddingHorizontal: 10, alignItems: 'center', justifyContent: 'center' },
  choiceText: { fontSize: 9, fontWeight: '700' },
  addOnRow: { minHeight: 33, flexDirection: 'row', alignItems: 'center', gap: 7 },
  addOnText: { flex: 1, fontSize: 10, fontWeight: '600' },
  addOnPrice: { fontSize: 9 },
  premiumCard: { gap: 8, padding: 12 },
  premiumLine: { flexDirection: 'row', justifyContent: 'space-between' },
  premiumLabel: { fontSize: 10 },
  premiumValue: { fontSize: 10, fontWeight: '700' },
  totalLine: { borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 8, flexDirection: 'row', justifyContent: 'space-between' },
  totalLabel: { fontSize: 12, fontWeight: '800' },
  totalValue: { fontSize: 13, fontWeight: '800' },
  sectionLabel: { minHeight: 35, borderRadius: 11, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', gap: 7 },
  sectionLabelText: { fontSize: 11, fontWeight: '800' },
  addressInput: { minHeight: 72, textAlignVertical: 'top', paddingTop: 10 },
  error: { fontSize: 10, lineHeight: 15 },
  reviewBanner: { padding: 11, borderRadius: 12, flexDirection: 'row', alignItems: 'center', gap: 8 },
  reviewBannerText: { flex: 1, fontSize: 11, fontWeight: '700' },
  reviewCard: { gap: 11, padding: 13 },
  reviewLine: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10 },
  reviewLabel: { fontSize: 10 },
  reviewValue: { flex: 1, textAlign: 'right', fontSize: 10, fontWeight: '700' },
  disclaimer: { textAlign: 'center', fontSize: 9, lineHeight: 14 },
  savedCard: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, padding: 20 },
  savedIcon: { width: 56, height: 56, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  savedTitle: { fontSize: 19, fontWeight: '800' },
});
