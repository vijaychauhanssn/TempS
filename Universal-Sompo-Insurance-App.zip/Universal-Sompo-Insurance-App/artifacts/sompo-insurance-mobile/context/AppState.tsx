import React, {
  createContext,
  PropsWithChildren,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export type UserProfile = {
  fullName: string;
  email: string;
  mobile: string;
  gender: string;
  dateOfBirth: string;
  bloodGroup: string;
  height: string;
  weight: string;
  dailyActivity: string;
  emergencyName: string;
  emergencyPhone: string;
};

export const DEFAULT_PROFILE: UserProfile = {
  fullName: 'Saurav Sharma',
  email: 'sauravsharma31@gmail.com',
  mobile: '9823124723',
  gender: 'Male',
  dateOfBirth: '12/04/1996',
  bloodGroup: 'AB−',
  height: `6'2"`,
  weight: '87 kg',
  dailyActivity: 'No Exercise',
  emergencyName: 'Ravi Sharma',
  emergencyPhone: '9784948484',
};

type AppStateValue = {
  profile: UserProfile;
  isReady: boolean;
  hasSession: boolean;
  saveProfile: (nextProfile: UserProfile) => Promise<void>;
  completeLogin: () => Promise<void>;
  logout: () => Promise<void>;
  deleteLocalAccount: () => Promise<void>;
};

const PROFILE_KEY = 'universal-sompo:profile';
const SESSION_KEY = 'universal-sompo:demo-session';
const AppStateContext = createContext<AppStateValue | null>(null);

export function AppStateProvider({ children }: PropsWithChildren) {
  const [profile, setProfile] = useState<UserProfile>(DEFAULT_PROFILE);
  const [hasSession, setHasSession] = useState(false);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    let mounted = true;
    const hydrate = async () => {
      try {
        const [storedProfile, storedSession] = await Promise.all([
          AsyncStorage.getItem(PROFILE_KEY),
          AsyncStorage.getItem(SESSION_KEY),
        ]);
        if (!mounted) return;
        if (storedProfile) {
          const parsed = JSON.parse(storedProfile) as Partial<UserProfile>;
          setProfile({ ...DEFAULT_PROFILE, ...parsed });
        }
        setHasSession(storedSession === 'active');
      } catch (error) {
        console.warn('Could not restore the local demo account.', error);
      } finally {
        if (mounted) setIsReady(true);
      }
    };
    void hydrate();
    return () => {
      mounted = false;
    };
  }, []);

  const value = useMemo<AppStateValue>(
    () => ({
      profile,
      isReady,
      hasSession,
      saveProfile: async (nextProfile) => {
        await AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(nextProfile));
        setProfile(nextProfile);
      },
      completeLogin: async () => {
        await AsyncStorage.setItem(SESSION_KEY, 'active');
        setHasSession(true);
      },
      logout: async () => {
        await AsyncStorage.removeItem(SESSION_KEY);
        setHasSession(false);
      },
      deleteLocalAccount: async () => {
        await AsyncStorage.multiRemove([PROFILE_KEY, SESSION_KEY]);
        setProfile(DEFAULT_PROFILE);
        setHasSession(false);
      },
    }),
    [profile, isReady, hasSession],
  );

  return (
    <AppStateContext.Provider value={value}>
      {children}
    </AppStateContext.Provider>
  );
}

export function useAppState() {
  const value = useContext(AppStateContext);
  if (!value) {
    throw new Error('useAppState must be used inside AppStateProvider.');
  }
  return value;
}
