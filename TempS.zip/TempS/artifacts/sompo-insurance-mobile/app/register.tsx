import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import {
  AppHeader,
  BrandLogo,
  HelperText,
  LabeledInput,
  PrimaryButton,
} from '@/components/AppUI';
import { DEFAULT_PROFILE, useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function RegisterScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { saveProfile, completeLogin } = useAppState();
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const submit = async () => {
    setError('');
    if (!name.trim()) {
      setError('Enter your name to create a demo profile.');
      return;
    }
    if (mobile.replace(/\D/g, '').length !== 10) {
      setError('Enter a valid 10-digit mobile number.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setError('Enter a valid email address.');
      return;
    }
    await saveProfile({
      ...DEFAULT_PROFILE,
      fullName: name.trim(),
      mobile: mobile.replace(/\D/g, ''),
      email: email.trim(),
    });
    await completeLogin();
    router.replace('/(tabs)/home');
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.screen }]}>
      <KeyboardAwareScrollViewCompat
        style={styles.scroll}
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: (insets.top || 0) + (insets.top === 0 ? 67 : 12),
            paddingBottom: (insets.bottom || 0) + 24,
          },
        ]}
        keyboardShouldPersistTaps="handled"
        bottomOffset={54}
      >
        <AppHeader title="Register" onBack={() => router.back()} />
        <BrandLogo width={292} />
        <Text style={[styles.welcome, { color: colors.foreground }]}>
          Welcome to{' '}
          <Text style={{ color: colors.primary, fontWeight: '800' }}>
            Universal Sompo
          </Text>
        </Text>
        <View
          style={[
            styles.formPanel,
            { backgroundColor: colors.white, borderColor: colors.border },
          ]}
        >
          <Text style={[styles.heading, { color: colors.foreground }]}>
            Create your account
          </Text>
          <LabeledInput
            label="Your Name"
            placeholder="Enter your name"
            value={name}
            onChangeText={setName}
            autoCapitalize="words"
            testID="register-name"
          />
          <LabeledInput
            label="Mobile Number"
            placeholder="Enter your mobile number"
            value={mobile}
            onChangeText={setMobile}
            keyboardType="phone-pad"
            maxLength={14}
            testID="register-mobile"
          />
          <LabeledInput
            label="E-mail ID"
            placeholder="Enter your email ID"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            testID="register-email"
          />
          {error ? (
            <Text accessibilityRole="alert" style={[styles.error, { color: colors.primary }]}>
              {error}
            </Text>
          ) : null}
          <HelperText>
            Demo profile only. No account is created with the insurer.
          </HelperText>
          <PrimaryButton
            label="Register"
            icon="chevron-forward"
            onPress={() => void submit()}
            testID="register-submit"
          />
        </View>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 18, gap: 14 },
  welcome: { fontSize: 18, textAlign: 'center', fontWeight: '600' },
  formPanel: {
    flexGrow: 1,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: StyleSheet.hairlineWidth,
    padding: 20,
    gap: 17,
  },
  heading: { textAlign: 'center', fontSize: 23, fontWeight: '800' },
  error: { fontSize: 13, fontWeight: '600' },
});
