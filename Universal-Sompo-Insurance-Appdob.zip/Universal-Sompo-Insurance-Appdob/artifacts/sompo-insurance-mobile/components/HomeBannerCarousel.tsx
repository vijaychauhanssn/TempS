import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  NativeScrollEvent,
  NativeSyntheticEvent,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import type { HomeBanner } from '@/src/services/homeService';
import { useColors } from '@/hooks/useColors';

const fallbackImage = require('../assets/images/home-hero.png');

const approvedIconNames = new Set<keyof typeof Ionicons.glyphMap>([
  'shield-checkmark',
  'heart',
  'car-sport',
  'fitness',
  'walk',
  'document-text',
  'location',
]);

export function getApprovedBannerIcon(
  value?: string,
): keyof typeof Ionicons.glyphMap | undefined {
  if (!value) return undefined;
  return approvedIconNames.has(value as keyof typeof Ionicons.glyphMap)
    ? (value as keyof typeof Ionicons.glyphMap)
    : undefined;
}

export function HomeBannerCarousel({
  banners,
  loading,
  error,
  isActive,
  onRetry,
  onSelect,
}: {
  banners: HomeBanner[];
  loading: boolean;
  error: string | null;
  isActive: boolean;
  onRetry: () => void;
  onSelect: (banner: HomeBanner) => void;
}) {
  const colors = useColors();
  const { width } = useWindowDimensions();
  const slideWidth = Math.max(280, width - 26);
  const slideHeight = Math.max(104, Math.min(138, Math.round(slideWidth * 0.35)));
  const scrollRef = useRef<ScrollView>(null);
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    setActiveIndex(0);
    scrollRef.current?.scrollTo({ x: 0, animated: false });
  }, [banners.length]);

  useEffect(() => {
    if (!isActive || banners.length < 2) return undefined;
    const timer = setInterval(() => {
      setActiveIndex((current) => {
        const next = (current + 1) % banners.length;
        scrollRef.current?.scrollTo({ x: next * slideWidth, animated: true });
        return next;
      });
    }, 5000);
    return () => clearInterval(timer);
  }, [banners.length, isActive, slideWidth]);

  const onScrollEnd = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    setActiveIndex(
      Math.max(0, Math.min(
        banners.length - 1,
        Math.round(event.nativeEvent.contentOffset.x / slideWidth),
      )),
    );
  };

  if (loading) {
    return (
      <View
        accessibilityLabel="Loading home banners"
        style={[
          styles.loading,
          {
            height: slideHeight,
            backgroundColor: colors.muted,
            borderColor: colors.border,
          },
        ]}
      >
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  if (error) {
    return (
      <View style={[styles.messageCard, { borderColor: colors.border, backgroundColor: colors.card }]}>
        <Ionicons name="cloud-offline-outline" size={22} color={colors.mutedForeground} />
        <Text style={[styles.messageTitle, { color: colors.foreground }]}>Banners aren’t available</Text>
        <Text style={[styles.messageCopy, { color: colors.mutedForeground }]}>{error}</Text>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Retry loading home banners"
          onPress={onRetry}
          style={[styles.retry, { backgroundColor: colors.primaryWash }]}
        >
          <Ionicons name="refresh" size={15} color={colors.primary} />
          <Text style={[styles.retryText, { color: colors.primary }]}>Retry</Text>
        </Pressable>
      </View>
    );
  }

  if (!banners.length) {
    return (
      <View style={[styles.messageCard, { borderColor: colors.border, backgroundColor: colors.card }]}>
        <Ionicons name="images-outline" size={22} color={colors.mutedForeground} />
        <Text style={[styles.messageTitle, { color: colors.foreground }]}>No promotions right now</Text>
      </View>
    );
  }

  return (
    <View style={styles.carousel}>
      <ScrollView
        ref={scrollRef}
        horizontal
        pagingEnabled
        snapToInterval={slideWidth}
        decelerationRate="fast"
        disableIntervalMomentum
        showsHorizontalScrollIndicator={false}
        onMomentumScrollEnd={onScrollEnd}
        accessibilityLabel="Home promotional banners"
      >
        {banners.map((banner) => (
          <BannerSlide
            key={banner.id}
            banner={banner}
            width={slideWidth}
            height={slideHeight}
            onPress={() => onSelect(banner)}
          />
        ))}
      </ScrollView>
      {banners.length > 1 ? (
        <View style={styles.pagination} accessibilityLabel={`Banner ${activeIndex + 1} of ${banners.length}`}>
          {banners.map((banner, index) => (
            <View
              key={banner.id}
              style={[
                styles.dot,
                {
                  width: index === activeIndex ? 17 : 6,
                  backgroundColor: index === activeIndex ? colors.primary : colors.primaryPale,
                },
              ]}
            />
          ))}
        </View>
      ) : null}
    </View>
  );
}

function BannerSlide({
  banner,
  width,
  height,
  onPress,
}: {
  banner: HomeBanner;
  width: number;
  height: number;
  onPress: () => void;
}) {
  const colors = useColors();
  const [useFallback, setUseFallback] = useState(false);
  const [imageUnavailable, setImageUnavailable] = useState(false);
  const hasCopy = Boolean(banner.title || banner.description || banner.ctaLabel || banner.icon);
  const imageSource = useFallback
    ? fallbackImage
    : banner.imageUrl
      ? { uri: banner.imageUrl }
      : banner.imageSource ?? fallbackImage;
  const icon = getApprovedBannerIcon(banner.icon);

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={[banner.title, banner.description, banner.ctaLabel].filter(Boolean).join('. ') || 'Open banner destination'}
      onPress={onPress}
      style={({ pressed }) => [
        styles.slide,
        {
          width,
          height,
          backgroundColor: colors.primaryPale,
          borderColor: colors.border,
        },
        pressed && styles.pressed,
      ]}
    >
      {imageUnavailable ? (
        <View style={[StyleSheet.absoluteFill, styles.imageFallback, { backgroundColor: colors.primaryWash }]}>
          <Ionicons name="shield-checkmark-outline" size={30} color={colors.primary} />
        </View>
      ) : (
        <Image
          source={imageSource}
          resizeMode="cover"
          onError={() => {
            if (!useFallback) setUseFallback(true);
            else setImageUnavailable(true);
          }}
          style={StyleSheet.absoluteFill}
          accessibilityLabel={banner.title || 'Universal Sompo promotional banner'}
        />
      )}
      {hasCopy ? (
        <>
          <LinearGradient
            colors={['rgba(27, 9, 14, 0.72)', 'rgba(27, 9, 14, 0.08)']}
            start={{ x: 0, y: 1 }}
            end={{ x: 0.8, y: 0 }}
            style={StyleSheet.absoluteFill}
          />
          <View style={styles.bannerCopy}>
            {icon ? <Ionicons name={icon} size={19} color={colors.white} /> : null}
            {banner.title ? <Text style={styles.bannerTitle}>{banner.title}</Text> : null}
            {banner.description ? <Text style={styles.bannerDescription}>{banner.description}</Text> : null}
            {banner.ctaLabel ? (
              <View style={[styles.cta, { backgroundColor: colors.white }]}>
                <Text style={[styles.ctaText, { color: colors.primary }]}>{banner.ctaLabel}</Text>
                <Ionicons name="arrow-forward" size={13} color={colors.primary} />
              </View>
            ) : null}
          </View>
        </>
      ) : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  carousel: { gap: 5 },
  slide: {
    borderRadius: 15,
    borderWidth: StyleSheet.hairlineWidth,
    overflow: 'hidden',
    justifyContent: 'flex-end',
  },
  imageFallback: { alignItems: 'center', justifyContent: 'center' },
  bannerCopy: { paddingHorizontal: 13, paddingVertical: 10, gap: 4, maxWidth: '82%' },
  bannerTitle: { color: '#ffffff', fontSize: 17, lineHeight: 21, fontWeight: '800' },
  bannerDescription: { color: '#ffffff', fontSize: 11, lineHeight: 15 },
  cta: { alignSelf: 'flex-start', borderRadius: 16, minHeight: 26, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2 },
  ctaText: { fontSize: 10, fontWeight: '800' },
  pagination: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 5, height: 8 },
  dot: { height: 6, borderRadius: 4 },
  loading: { borderRadius: 15, borderWidth: StyleSheet.hairlineWidth, alignItems: 'center', justifyContent: 'center' },
  messageCard: { minHeight: 104, borderRadius: 15, borderWidth: StyleSheet.hairlineWidth, padding: 12, alignItems: 'center', justifyContent: 'center', gap: 5 },
  messageTitle: { fontSize: 12, fontWeight: '800', textAlign: 'center' },
  messageCopy: { fontSize: 10, textAlign: 'center' },
  retry: { minHeight: 28, paddingHorizontal: 11, borderRadius: 15, flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2 },
  retryText: { fontSize: 10, fontWeight: '800' },
  pressed: { opacity: 0.82 },
});
