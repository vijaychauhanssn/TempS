import AsyncStorage from '@react-native-async-storage/async-storage';

export type DemoHealthClaim = {
  reference: string;
  member: string;
  policyNumber: string;
  hospital: string;
  incidentDate: string;
  createdAt: string;
  status: 'Saved on this device';
};

const CLAIMS_KEY = 'universal-sompo:demo-health-claims';

export async function listDemoHealthClaims(): Promise<DemoHealthClaim[]> {
  const value = await AsyncStorage.getItem(CLAIMS_KEY);
  if (!value) return [];
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? (parsed as DemoHealthClaim[]) : [];
  } catch {
    return [];
  }
}

export async function saveDemoHealthClaim(
  details: Omit<DemoHealthClaim, 'reference' | 'createdAt' | 'status'>,
): Promise<DemoHealthClaim> {
  const claim: DemoHealthClaim = {
    ...details,
    reference: `DEMO-${Date.now().toString().slice(-6)}`,
    createdAt: new Date().toISOString(),
    status: 'Saved on this device',
  };
  const current = await listDemoHealthClaims();
  await AsyncStorage.setItem(CLAIMS_KEY, JSON.stringify([claim, ...current]));
  return claim;
}
