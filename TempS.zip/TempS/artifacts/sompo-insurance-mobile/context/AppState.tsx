import React, {
  createContext,
  PropsWithChildren,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export type UserProfile = {
  fullName: string;
  email: string;
  mobile: string;
  gender: string;
  dateOfBirth: string;
  bloodGroup: string;
  height: string;
  weight: string;
  dailyActivity: string;
  emergencyName: string;
  emergencyPhone: string;
};

export type UserPolicy = {
  id: string;
  name: string;
  company: string;
  policyNumber: string;
  sumAssured: string;
  expiryDate: string;
  category: 'Health' | 'Motor' | 'Other';
  isSample?: boolean;
};

export const DEFAULT_PROFILE: UserProfile = {
  fullName: 'Saurav Sharma',
  email: 'sauravsharma31@gmail.com',
  mobile: '9823124723',
  gender: 'Male',
  dateOfBirth: '12/04/1996',
  bloodGroup: 'AB−',
  height: `6'2"`,
  weight: '87 kg',
  dailyActivity: 'No Exercise',
  emergencyName: 'Ravi Sharma',
  emergencyPhone: '9784948484',
};

const SAMPLE_POLICIES: UserPolicy[] = [
  {
    id: 'sample-health-family',
    name: 'Group Health Insurance Policy',
    company: 'Non Employer–Employee',
    policyNumber: 'USGIC/HLT/214356/00',
    sumAssured: '₹2,00,000',
    expiryDate: '12 Jul 2027',
    category: 'Health',
    isSample: true,
  },
  {
    id: 'sample-motor-bike',
    name: 'Bajaj Auto CT 100',
    company: 'Two Wheeler Insurance',
    policyNumber: 'USGIC/MTR/214312',
    sumAssured: '₹2,14,312',
    expiryDate: '12 Jul 2027',
    category: 'Motor',
    isSample: true,
  },
  {
    id: 'sample-health-individual',
    name: 'Group Health Insurance Policy',
    company: 'Non Employer–Employee',
    policyNumber: 'USGIC/HLT/214357/00',
    sumAssured: '₹2,00,000',
    expiryDate: '12 Jul 2027',
    category: 'Health',
    isSample: true,
  },
];

type AppStateValue = {
  profile: UserProfile;
  policies: UserPolicy[];
  isReady: boolean;
  hasSession: boolean;
  saveProfile: (nextProfile: UserProfile) => Promise<void>;
  addPolicy: (policy: UserPolicy) => Promise<void>;
  removePolicy: (policyId: string) => Promise<void>;
  completeLogin: () => Promise<void>;
  logout: () => Promise<void>;
  deleteLocalAccount: () => Promise<void>;
};

const PROFILE_KEY = 'universal-sompo:profile';
const SESSION_KEY = 'universal-sompo:demo-session';
const POLICIES_KEY = 'universal-sompo:policies';
const AppStateContext = createContext<AppStateValue | null>(null);

export function AppStateProvider({ children }: PropsWithChildren) {
  const [profile, setProfile] = useState<UserProfile>(DEFAULT_PROFILE);
  const [policies, setPolicies] = useState<UserPolicy[]>(SAMPLE_POLICIES);
  const [hasSession, setHasSession] = useState(false);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    let mounted = true;
    const hydrate = async () => {
      try {
        const [storedProfile, storedSession, storedPolicies] = await Promise.all([
          AsyncStorage.getItem(PROFILE_KEY),
          AsyncStorage.getItem(SESSION_KEY),
          AsyncStorage.getItem(POLICIES_KEY),
        ]);
        if (!mounted) return;
        if (storedProfile) {
          const parsed = JSON.parse(storedProfile) as Partial<UserProfile>;
          setProfile({ ...DEFAULT_PROFILE, ...parsed });
        }
        if (storedPolicies) {
          setPolicies(JSON.parse(storedPolicies) as UserPolicy[]);
        }
        setHasSession(storedSession === 'active');
      } catch (error) {
        console.warn('Could not restore the local demo account.', error);
      } finally {
        if (mounted) setIsReady(true);
      }
    };
    void hydrate();
    return () => {
      mounted = false;
    };
  }, []);

  const value = useMemo<AppStateValue>(
    () => ({
      profile,
      policies,
      isReady,
      hasSession,
      saveProfile: async (nextProfile) => {
        await AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(nextProfile));
        setProfile(nextProfile);
      },
      addPolicy: async (policy) => {
        const nextPolicies = [policy, ...policies];
        await AsyncStorage.setItem(POLICIES_KEY, JSON.stringify(nextPolicies));
        setPolicies(nextPolicies);
      },
      removePolicy: async (policyId) => {
        const nextPolicies = policies.filter((policy) => policy.id !== policyId);
        await AsyncStorage.setItem(POLICIES_KEY, JSON.stringify(nextPolicies));
        setPolicies(nextPolicies);
      },
      completeLogin: async () => {
        await AsyncStorage.setItem(SESSION_KEY, 'active');
        setHasSession(true);
      },
      logout: async () => {
        await AsyncStorage.removeItem(SESSION_KEY);
        setHasSession(false);
      },
      deleteLocalAccount: async () => {
        await AsyncStorage.multiRemove([PROFILE_KEY, SESSION_KEY, POLICIES_KEY]);
        setProfile(DEFAULT_PROFILE);
        setPolicies(SAMPLE_POLICIES);
        setHasSession(false);
      },
    }),
    [profile, policies, isReady, hasSession],
  );

  return (
    <AppStateContext.Provider value={value}>
      {children}
    </AppStateContext.Provider>
  );
}

export function useAppState() {
  const value = useContext(AppStateContext);
  if (!value) {
    throw new Error('useAppState must be used inside AppStateProvider.');
  }
  return value;
}
