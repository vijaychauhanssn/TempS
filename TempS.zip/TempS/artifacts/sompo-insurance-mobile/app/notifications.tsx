import React, { useMemo, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppHeader, AppPage, SurfaceCard } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

type NotificationItem = {
  id: number;
  title: string;
  body: string;
  type: 'Notification' | 'Pending Action';
  unread: boolean;
};

const initialItems: NotificationItem[] = [
  {
    id: 1,
    title: 'Step Goal Achieved',
    body: 'Congratulations rohit! You have successfully achieved your steps goal for today. Keep up the great work.',
    type: 'Notification',
    unread: true,
  },
  {
    id: 2,
    title: 'Step Goal Achieved',
    body: 'Congratulations rohit! You have successfully achieved your steps goal for today. Keep up the great work.',
    type: 'Notification',
    unread: true,
  },
  {
    id: 3,
    title: 'Step Goal Achieved',
    body: 'Congratulations rohit! You have successfully achieved your steps goal for today. Keep up the great work.',
    type: 'Notification',
    unread: false,
  },
  {
    id: 4,
    title: 'Complete your profile',
    body: 'Add your emergency contact details to keep your profile up to date.',
    type: 'Pending Action',
    unread: true,
  },
];

export default function NotificationsScreen() {
  const colors = useColors();
  const [activeTab, setActiveTab] = useState<'Notification' | 'Pending Action'>('Notification');
  const [items, setItems] = useState<NotificationItem[]>(initialItems);
  const visibleItems = useMemo(
    () => items.filter((item) => item.type === activeTab),
    [activeTab, items],
  );

  const clearAll = () => {
    if (!visibleItems.length) return;
    Alert.alert('Clear all?', `Remove all ${activeTab.toLowerCase()} items from this demo?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Clear all',
        style: 'destructive',
        onPress: () =>
          setItems((current) => current.filter((item) => item.type !== activeTab)),
      },
    ]);
  };

  const openItem = (item: NotificationItem) => {
    setItems((current) =>
      current.map((entry) =>
        entry.id === item.id ? { ...entry, unread: false } : entry,
      ),
    );
    if (item.type === 'Pending Action') router.push('/profile-edit');
    else router.push('/(tabs)/wellness');
  };

  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="Notification" onBack={() => router.back()} />
      <View style={[styles.tabBar, { borderBottomColor: colors.border }]}>
        {(['Notification', 'Pending Action'] as const).map((tab) => (
          <Pressable
            key={tab}
            onPress={() => setActiveTab(tab)}
            style={[
              styles.tab,
              activeTab === tab && { backgroundColor: colors.primary },
            ]}
          >
            <Text
              style={[
                styles.tabText,
                { color: activeTab === tab ? colors.white : colors.mutedForeground },
              ]}
            >
              {tab}
            </Text>
          </Pressable>
        ))}
        <Pressable onPress={clearAll} hitSlop={7} accessibilityRole="button">
          <Text style={[styles.clearText, { color: colors.primary }]}>Clear All</Text>
        </Pressable>
      </View>

      {visibleItems.length ? (
        <View style={styles.list}>
          {visibleItems.map((item) => (
            <Pressable
              key={item.id}
              onPress={() => openItem(item)}
              accessibilityRole="button"
              style={({ pressed }) => [pressed && styles.pressed]}
            >
              <SurfaceCard style={styles.notificationCard}>
                <View style={styles.notificationCopy}>
                  <Text style={[styles.itemTitle, { color: colors.foreground }]}>
                    {item.title}
                  </Text>
                  <Text
                    numberOfLines={2}
                    style={[styles.itemBody, { color: colors.mutedForeground }]}
                  >
                    {item.body}
                  </Text>
                </View>
                <View style={styles.itemMeta}>
                  {item.unread ? (
                    <View style={[styles.unreadDot, { backgroundColor: colors.primary }]} />
                  ) : null}
                  <Text style={[styles.when, { color: colors.mutedForeground }]}>
                    4 days ago
                  </Text>
                  <Ionicons name="chevron-forward" size={18} color={colors.mutedForeground} />
                </View>
              </SurfaceCard>
            </Pressable>
          ))}
        </View>
      ) : (
        <SurfaceCard style={styles.emptyCard}>
          <View style={[styles.emptyIcon, { backgroundColor: colors.primaryWash }]}>
            <Ionicons name="notifications-off-outline" size={25} color={colors.primary} />
          </View>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
            Nothing to see here
          </Text>
          <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
            New {activeTab.toLowerCase()} items will appear here.
          </Text>
        </SurfaceCard>
      )}
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 12, gap: 13 },
  tabBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingBottom: 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  tab: { borderRadius: 18, paddingHorizontal: 13, paddingVertical: 8 },
  tabText: { fontSize: 12, fontWeight: '700' },
  clearText: { fontSize: 11, fontWeight: '700', marginLeft: 'auto' },
  list: { gap: 9 },
  notificationCard: {
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    borderRadius: 13,
  },
  notificationCopy: { flex: 1, gap: 5 },
  itemTitle: { fontSize: 12, fontWeight: '800' },
  itemBody: { fontSize: 10, lineHeight: 14 },
  itemMeta: { alignItems: 'center', gap: 4 },
  unreadDot: { width: 6, height: 6, borderRadius: 4, alignSelf: 'flex-end' },
  when: { fontSize: 9 },
  emptyCard: { minHeight: 190, alignItems: 'center', justifyContent: 'center', gap: 9, marginTop: 18 },
  emptyIcon: { width: 50, height: 50, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { fontSize: 16, fontWeight: '800' },
  emptyText: { fontSize: 12, textAlign: 'center' },
  pressed: { opacity: 0.76 },
});
