import React, { useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppHeader, LabeledInput, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

const memberOptions = ['Self', 'Spouse', 'Child', 'Mother', 'Father', 'Mother-in-law', 'Father-in-law'];

function MemberChoice({
  label,
  selected,
  onPress,
}: {
  label: string;
  selected: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable onPress={onPress} style={styles.memberRow}>
      <Ionicons name={selected ? 'checkbox' : 'square-outline'} size={19} color={selected ? colors.primary : colors.mutedForeground} />
      <Text style={[styles.memberText, { color: colors.foreground }]}>{label}</Text>
    </Pressable>
  );
}

export default function HealthBuyScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { plan = 'complete' } = useLocalSearchParams<{ plan?: string }>();
  const { profile } = useAppState();
  const [step, setStep] = useState(1);
  const [name, setName] = useState(profile.fullName);
  const [mobile, setMobile] = useState(profile.mobile);
  const [email, setEmail] = useState(profile.email);
  const [gender, setGender] = useState(profile.gender);
  const [dob, setDob] = useState(profile.dateOfBirth);
  const [pincode, setPincode] = useState('');
  const [stateName, setStateName] = useState('');
  const [city, setCity] = useState('');
  const [policyType, setPolicyType] = useState('Gold Plan');
  const [members, setMembers] = useState<string[]>(['Self']);
  const [consent, setConsent] = useState(false);
  const [error, setError] = useState('');
  const [requestId, setRequestId] = useState('');
  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;

  const toggleMember = (member: string) => {
    setMembers((current) =>
      current.includes(member)
        ? current.filter((value) => value !== member)
        : [...current, member],
    );
  };

  const next = () => {
    if (step === 1) {
      if (!name.trim() || mobile.replace(/\D/g, '').length < 10 || !/^\S+@\S+\.\S+$/.test(email) || !gender || !/^\d{2}\/\d{2}\/\d{4}$/.test(dob) || pincode.length !== 6 || !stateName.trim() || !city.trim() || !consent) {
        setError('Complete all required details and accept the terms to continue.');
        return;
      }
      setError('');
      setStep(2);
      return;
    }
    if (step === 2) {
      if (!policyType || members.length === 0) {
        setError('Choose a plan and at least one covered member.');
        return;
      }
      setError('');
      setStep(3);
      return;
    }
    if (step === 3) {
      setRequestId(`DEMO-${Date.now().toString().slice(-6)}`);
      setStep(4);
    }
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.page, { backgroundColor: colors.screen }]}
      contentContainerStyle={[
        styles.content,
        { paddingTop: topInset + 8, paddingBottom: bottomInset + 22 },
      ]}
      bottomOffset={70}
      keyboardShouldPersistTaps="handled"
    >
      <AppHeader title={step === 1 ? 'Buy Policy' : 'Health Insurance'} onBack={() => router.back()} />
      <View style={[styles.progress, { backgroundColor: colors.primaryPale }]}>
        <View style={[styles.progressFill, { backgroundColor: colors.primary, width: `${Math.min(step, 3) / 3 * 100}%` }]} />
      </View>
      {step < 4 ? (
        <Text style={[styles.stepText, { color: colors.primary }]}>Step {step} of 3</Text>
      ) : null}

      {step === 1 ? (
        <>
          <View style={[styles.hero, { backgroundColor: colors.primaryPale }]}>
            <View style={styles.heroCopy}>
              <Text style={[styles.heroEyebrow, { color: colors.primary }]}>HEALTHCARE INSURANCE</Text>
              <Text style={[styles.heroTitle, { color: colors.foreground }]}>Cover your family’s wellbeing.</Text>
            </View>
            <Ionicons name="people-outline" size={45} color={colors.primary} />
          </View>
          <View style={styles.formHeading}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>I want to buy {plan.replace('-', ' ')} health insurance for</Text>
            <Text style={[styles.requiredNote, { color: colors.primary }]}>* Required details</Text>
          </View>
          <LabeledInput label="Name *" value={name} onChangeText={setName} placeholder="Enter your name" />
          <LabeledInput label="Mobile Number *" value={mobile} onChangeText={setMobile} placeholder="Enter mobile number" keyboardType="phone-pad" maxLength={13} />
          <LabeledInput label="Email ID *" value={email} onChangeText={setEmail} placeholder="Enter email address" keyboardType="email-address" autoCapitalize="none" />
          <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Gender *</Text>
          <View style={styles.pillRow}>
            {['Male', 'Female', 'Other'].map((item) => (
              <Pressable
                key={item}
                onPress={() => setGender(item)}
                style={[styles.choice, { backgroundColor: gender === item ? colors.primary : colors.card, borderColor: gender === item ? colors.primary : colors.border }]}
              >
                <Text style={[styles.choiceText, { color: gender === item ? colors.white : colors.foreground }]}>{item}</Text>
              </Pressable>
            ))}
          </View>
          <LabeledInput label="Date of Birth *" value={dob} onChangeText={setDob} placeholder="DD/MM/YYYY" keyboardType="numbers-and-punctuation" maxLength={10} />
          <LabeledInput label="Pincode *" value={pincode} onChangeText={(value) => setPincode(value.replace(/\D/g, '').slice(0, 6))} placeholder="Enter pincode" keyboardType="number-pad" maxLength={6} />
          <View style={styles.twoColumns}>
            <LabeledInput label="State *" value={stateName} onChangeText={setStateName} placeholder="Select state" style={styles.halfInput} />
            <LabeledInput label="City *" value={city} onChangeText={setCity} placeholder="Select city" style={styles.halfInput} />
          </View>
          <Pressable onPress={() => setConsent((value) => !value)} style={styles.consentRow}>
            <Ionicons name={consent ? 'checkbox' : 'square-outline'} size={17} color={consent ? colors.primary : colors.mutedForeground} />
            <Text style={[styles.consentText, { color: colors.foreground }]}>I agree to the Terms & Conditions.</Text>
          </Pressable>
        </>
      ) : null}

      {step === 2 ? (
        <>
          <View style={[styles.banner, { backgroundColor: colors.primaryWash }]}>
            <Ionicons name="heart-outline" size={22} color={colors.primary} />
            <View style={styles.bannerCopy}>
              <Text style={[styles.bannerTitle, { color: colors.foreground }]}>Complete Health Insurance</Text>
              <Text style={[styles.bannerDetail, { color: colors.mutedForeground }]}>Choose a sample plan and who you want to cover.</Text>
            </View>
          </View>
          <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Select the policy type *</Text>
          <View style={styles.planList}>
            {['Gold Plan', 'Silver Plan', 'Digi-Pro Plan'].map((item) => (
              <Pressable
                key={item}
                onPress={() => setPolicyType(item)}
                style={[styles.planChoice, { backgroundColor: colors.card, borderColor: policyType === item ? colors.primary : colors.border }]}
              >
                <Ionicons name={policyType === item ? 'radio-button-on' : 'radio-button-off'} size={17} color={policyType === item ? colors.primary : colors.mutedForeground} />
                <Text style={[styles.planChoiceText, { color: colors.foreground }]}>{item}</Text>
              </Pressable>
            ))}
          </View>
          <View style={styles.memberHeader}>
            <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Who would you like to cover? *</Text>
            <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>DOB {dob}</Text>
          </View>
          <SurfaceCard style={styles.memberCard}>
            {memberOptions.map((member) => (
              <MemberChoice key={member} label={member} selected={members.includes(member)} onPress={() => toggleMember(member)} />
            ))}
          </SurfaceCard>
        </>
      ) : null}

      {step === 3 ? (
        <>
          <View style={[styles.banner, { backgroundColor: colors.primaryWash }]}>
            <Ionicons name="document-text-outline" size={22} color={colors.primary} />
            <View style={styles.bannerCopy}>
              <Text style={[styles.bannerTitle, { color: colors.foreground }]}>Review your details</Text>
              <Text style={[styles.bannerDetail, { color: colors.mutedForeground }]}>Confirm the sample quote request before saving it.</Text>
            </View>
          </View>
          <SurfaceCard style={styles.reviewCard}>
            <ReviewLine label="Applicant" value={name} />
            <ReviewLine label="Mobile" value={mobile} />
            <ReviewLine label="Email" value={email} />
            <ReviewLine label="City / State" value={`${city}, ${stateName}`} />
            <ReviewLine label="Plan" value={policyType} />
            <ReviewLine label="Covered members" value={members.join(', ')} />
          </SurfaceCard>
          <Text style={[styles.note, { color: colors.mutedForeground }]}>
            No premium, policy or insurer request will be created by this demo.
          </Text>
        </>
      ) : null}

      {step === 4 ? (
        <SurfaceCard style={styles.successCard}>
          <View style={[styles.successIcon, { backgroundColor: colors.primaryWash }]}>
            <Ionicons name="checkmark" size={29} color={colors.success} />
          </View>
          <Text style={[styles.successTitle, { color: colors.foreground }]}>Demo request saved</Text>
          <Text style={[styles.note, { color: colors.mutedForeground }]}>
            Reference {requestId} · {policyType} · {members.length} covered {members.length === 1 ? 'member' : 'members'}
          </Text>
          <PrimaryButton label="Back to Home" icon="home-outline" onPress={() => router.replace('/(tabs)/home')} />
        </SurfaceCard>
      ) : null}

      {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
      {step < 4 ? (
        <View style={styles.footer}>
          <PrimaryButton
            label={step === 3 ? 'Get Demo Quote' : 'Continue'}
            icon="arrow-forward"
            onPress={next}
          />
        </View>
      ) : null}
    </KeyboardAwareScrollViewCompat>
  );
}

function ReviewLine({ label, value }: { label: string; value: string }) {
  const colors = useColors();
  return (
    <View style={styles.reviewLine}>
      <Text style={[styles.reviewLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.reviewValue, { color: colors.foreground }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 14, gap: 11 },
  progress: { height: 5, borderRadius: 3, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 3 },
  stepText: { fontSize: 9, fontWeight: '800' },
  hero: { minHeight: 79, borderRadius: 14, padding: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  heroCopy: { flex: 1, gap: 4 },
  heroEyebrow: { fontSize: 8, fontWeight: '800', letterSpacing: 0.8 },
  heroTitle: { fontSize: 15, lineHeight: 19, fontWeight: '800' },
  formHeading: { gap: 3 },
  sectionTitle: { fontSize: 13, fontWeight: '800' },
  requiredNote: { fontSize: 9 },
  fieldLabel: { fontSize: 11, fontWeight: '700' },
  pillRow: { flexDirection: 'row', gap: 7 },
  choice: { flex: 1, minHeight: 35, borderWidth: 1, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  choiceText: { fontSize: 10, fontWeight: '700' },
  twoColumns: { flexDirection: 'row', gap: 8 },
  halfInput: { flex: 1 },
  consentRow: { flexDirection: 'row', alignItems: 'center', gap: 7, paddingVertical: 3 },
  consentText: { fontSize: 10, fontWeight: '600' },
  banner: { borderRadius: 12, padding: 11, flexDirection: 'row', alignItems: 'center', gap: 8 },
  bannerCopy: { flex: 1, gap: 3 },
  bannerTitle: { fontSize: 11, fontWeight: '800' },
  bannerDetail: { fontSize: 9, lineHeight: 13 },
  planList: { gap: 7 },
  planChoice: { minHeight: 40, borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 8 },
  planChoiceText: { fontSize: 11, fontWeight: '700' },
  memberHeader: { gap: 5 },
  memberCard: { gap: 1, paddingVertical: 6, paddingHorizontal: 11 },
  memberRow: { minHeight: 35, flexDirection: 'row', alignItems: 'center', gap: 8 },
  memberText: { fontSize: 11 },
  reviewCard: { gap: 11, padding: 13 },
  reviewLine: { flexDirection: 'row', justifyContent: 'space-between', gap: 12 },
  reviewLabel: { fontSize: 10 },
  reviewValue: { flex: 1, fontSize: 10, fontWeight: '700', textAlign: 'right' },
  note: { fontSize: 9, lineHeight: 14, textAlign: 'center' },
  error: { fontSize: 10, lineHeight: 15 },
  footer: { marginTop: 'auto', paddingTop: 8 },
  successCard: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, padding: 20 },
  successIcon: { width: 58, height: 58, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  successTitle: { fontSize: 19, fontWeight: '800' },
});
