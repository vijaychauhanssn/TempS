import React, { useMemo, useState } from 'react';
import {
  Alert,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  AppHeader,
  LabeledInput,
  PrimaryButton,
  SurfaceCard,
} from '@/components/AppUI';
import { DatePickerField, SelectField, isValidDateValue } from '@/components/FormFields';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';
import { demoStates, getDemoCities, getDemoPincodes } from '@/src/services/locationService';

type InsuredMember = {
  id: string;
  name: string;
  relationship: string;
  demoId: string;
};

const insuredMembers: InsuredMember[] = [
  { id: 'self', name: 'DILIP DAS', relationship: 'SELF', demoId: 'DEMO-001' },
  { id: 'spouse', name: 'RUPA DAS', relationship: 'SPOUSE', demoId: 'DEMO-002' },
  { id: 'son-1', name: 'AKASH DAS', relationship: 'SON', demoId: 'DEMO-003' },
  { id: 'son-2', name: 'DEVESH DAS', relationship: 'SON', demoId: 'DEMO-004' },
];

const hospitalsByCity: Record<string, string[]> = {
  Gaya: ['Anugrah Narayan Magadh Medical College', 'City Care Hospital'],
  Jamshedpur: ['Kantila Gandhi Memorial Hospital', 'Tata Main Hospital'],
  Patna: ['Ruban Patliputra Hospital Pvt. Ltd.', 'Aryan Hospital Pvt. Ltd.'],
  Ghaziabad: ['Yashoda Hospital', 'Max Super Speciality Hospital'],
  Noida: ['Universal Diagnostic Centre', 'Kailash Hospital'],
  Delhi: ['AIIMS Delhi', 'Safdarjung Hospital'],
  Mumbai: ['Breach Candy Hospital', 'Lilavati Hospital'],
  Pune: ['Sahyadri Hospital', 'Deenanath Mangeshkar Hospital'],
  Kolkata: ['AMRI Hospital', 'Apollo Multispeciality Hospitals'],
};

const claimTypes = ['Cashless', 'Reimbursement'];
const treatments = ['Hospitalization', 'Day care procedure', 'Emergency treatment', 'Other'];

function dateValueToDate(value: string): Date | undefined {
  if (!isValidDateValue(value)) return undefined;
  const [day, month, year] = value.split(/[/-]/).map(Number);
  return new Date(year, month - 1, day);
}

export default function HealthClaimIntimationScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [selectedMember, setSelectedMember] = useState<InsuredMember | null>(null);
  const [pendingMemberId, setPendingMemberId] = useState('');
  const [memberModalVisible, setMemberModalVisible] = useState(false);
  const [doctor, setDoctor] = useState('');
  const [admissionDate, setAdmissionDate] = useState('');
  const [dischargeDate, setDischargeDate] = useState('');
  const [stateName, setStateName] = useState('');
  const [city, setCity] = useState('');
  const [hospital, setHospital] = useState('');
  const [pincode, setPincode] = useState('');
  const [claimType, setClaimType] = useState('');
  const [diagnosis, setDiagnosis] = useState('');
  const [treatment, setTreatment] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [estimatedCost, setEstimatedCost] = useState('');
  const [documents, setDocuments] = useState<string[]>([]);
  const [error, setError] = useState('');
  const [reference, setReference] = useState('');

  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;
  const cities = getDemoCities(stateName);
  const pincodes = getDemoPincodes(stateName, city);
  const hospitals = useMemo(() => hospitalsByCity[city] ?? [], [city]);
  const pendingMember = insuredMembers.find((member) => member.id === pendingMemberId);

  const chooseDocument = async () => {
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        Alert.alert(
          'Photo access needed',
          'Allow photo access to attach a document image, or continue without an attachment.',
        );
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsMultipleSelection: true,
        selectionLimit: 5,
        quality: 0.85,
      });
      if (!result.canceled) {
        setDocuments((current) => [
          ...current,
          ...result.assets.map((asset) => asset.fileName || 'Attached document image'),
        ].slice(0, 5));
      }
    } catch {
      Alert.alert('Could not open photos', 'Try again or continue without an attachment.');
    }
  };

  const removeDocument = (index: number) => {
    setDocuments((current) => current.filter((_, currentIndex) => currentIndex !== index));
  };

  const continueIntimation = () => {
    const admission = dateValueToDate(admissionDate);
    const discharge = dateValueToDate(dischargeDate);
    const phoneDigits = mobile.replace(/\D/g, '');
    const cost = Number(estimatedCost.replace(/[^\d.]/g, ''));
    if (
      !selectedMember
      || !doctor.trim()
      || !admission
      || !discharge
      || discharge < admission
      || !stateName
      || !city
      || !hospital
      || !pincodes.includes(pincode)
      || !claimType
      || !diagnosis.trim()
      || !treatment
      || phoneDigits.length < 10
      || !/^\S+@\S+\.\S+$/.test(email.trim())
      || !Number.isFinite(cost)
      || cost <= 0
    ) {
      setError('Complete all required fields. The discharge date cannot be before admission.');
      return;
    }
    setError('');
    setReference(`DEMO-${Date.now().toString().slice(-6)}`);
  };

  return (
    <>
      <KeyboardAwareScrollViewCompat
        style={[styles.page, { backgroundColor: colors.screen }]}
        contentContainerStyle={[
          styles.content,
          { paddingTop: topInset + 8, paddingBottom: bottomInset + 22 },
        ]}
        bottomOffset={78}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <AppHeader title="Health Claim Intimation" onBack={() => router.back()} />
        {reference ? (
          <SurfaceCard style={styles.successCard}>
            <View style={[styles.successIcon, { backgroundColor: colors.primaryWash }]}>
              <Ionicons name="checkmark" size={28} color={colors.success} />
            </View>
            <Text style={[styles.successTitle, { color: colors.foreground }]}>Demo intimation saved</Text>
            <Text style={[styles.copy, { color: colors.mutedForeground }]}>
              Reference {reference}. This was saved in the demo only and was not sent to Universal Sompo.
            </Text>
            <PrimaryButton label="Back to claims" icon="arrow-forward" onPress={() => router.replace('/claims')} />
          </SurfaceCard>
        ) : (
          <>
            <SurfaceCard style={styles.policyCard}>
              <View style={[styles.policyIcon, { backgroundColor: colors.primaryWash }]}>
                <Ionicons name="shield-checkmark-outline" size={23} color={colors.primary} />
              </View>
              <View style={styles.policyCopy}>
                <Text style={[styles.policyTitle, { color: colors.foreground }]}>Supreme Healthcare</Text>
                <Text style={[styles.copy, { color: colors.mutedForeground }]}>Sample policy details · demo only</Text>
              </View>
            </SurfaceCard>

            <SurfaceCard style={styles.sectionCard}>
              <Text style={[styles.sectionTitle, { color: colors.primary }]}>Insured Member *</Text>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={selectedMember ? `Insured member ${selectedMember.name}` : 'Select insured member'}
                onPress={() => {
                  setPendingMemberId(selectedMember?.id ?? '');
                  setMemberModalVisible(true);
                }}
                style={[styles.memberSelect, { borderColor: colors.primary, backgroundColor: colors.white }]}
              >
                <View style={[styles.memberAvatar, { backgroundColor: colors.primaryWash }]}>
                  <Ionicons name="person" size={17} color={colors.primary} />
                </View>
                <View style={styles.memberSelectCopy}>
                  <Text style={[styles.memberName, { color: colors.foreground }]}>
                    {selectedMember?.name ?? 'Select an insured member'}
                  </Text>
                  <Text style={[styles.copy, { color: colors.mutedForeground }]}>
                    {selectedMember
                      ? `${selectedMember.relationship} · Member ID ${selectedMember.demoId}`
                      : 'Choose a member covered by this sample policy'}
                  </Text>
                </View>
                <Ionicons name="chevron-down" size={17} color={colors.primary} />
              </Pressable>
            </SurfaceCard>

            <SurfaceCard style={styles.sectionCard}>
              <Text style={[styles.sectionTitle, { color: colors.primary }]}>Hospitalization Details</Text>
              <LabeledInput
                label="Name of Doctor *"
                value={doctor}
                onChangeText={setDoctor}
                placeholder="Enter doctor name"
                autoCapitalize="words"
                testID="claim-doctor"
              />
              <View style={styles.twoColumns}>
                <DatePickerField
                  label="Date of Admission *"
                  value={admissionDate}
                  onChange={setAdmissionDate}
                  displayFormat="DD/MM/YYYY"
                  minDate={new Date(1920, 0, 1)}
                  maxDate={new Date()}
                  testID="claim-admission-date"
                />
                <DatePickerField
                  label="Date of Discharge *"
                  value={dischargeDate}
                  onChange={setDischargeDate}
                  displayFormat="DD/MM/YYYY"
                  minDate={dateValueToDate(admissionDate) ?? new Date(1920, 0, 1)}
                  maxDate={new Date()}
                  testID="claim-discharge-date"
                />
              </View>
              <View style={styles.twoColumns}>
                <SelectField
                  label="State *"
                  value={stateName}
                  placeholder="Select state"
                  options={demoStates}
                  onChange={(value) => {
                    setStateName(value);
                    setCity('');
                    setHospital('');
                    setPincode('');
                  }}
                  testID="claim-state"
                />
                <SelectField
                  label="City *"
                  value={city}
                  placeholder={stateName ? 'Select city' : 'Select state first'}
                  options={cities}
                  disabled={!stateName}
                  onChange={(value) => {
                    setCity(value);
                    setHospital('');
                    setPincode('');
                  }}
                  testID="claim-city"
                />
              </View>
              <SelectField
                label="Hospital Name *"
                value={hospital}
                placeholder={city ? 'Select hospital' : 'Select city first'}
                options={hospitals}
                disabled={!city || hospitals.length === 0}
                onChange={setHospital}
                testID="claim-hospital"
              />
              <SelectField
                label="Pincode *"
                value={pincode}
                placeholder={city ? 'Select pincode' : 'Select city first'}
                options={pincodes}
                disabled={!city}
                searchable={false}
                onChange={setPincode}
                testID="claim-pincode"
              />
              <SelectField
                label="Claim Type *"
                value={claimType}
                placeholder="Select claim type"
                options={claimTypes}
                searchable={false}
                onChange={setClaimType}
                testID="claim-type"
              />
              <LabeledInput
                label="Initial Diagnosis *"
                value={diagnosis}
                onChangeText={setDiagnosis}
                placeholder="Enter initial diagnosis"
                multiline
                style={styles.multiline}
                testID="claim-diagnosis"
              />
              <SelectField
                label="Treatment Type *"
                value={treatment}
                placeholder="Select treatment type"
                options={treatments}
                onChange={setTreatment}
                testID="claim-treatment"
              />
            </SurfaceCard>

            <SurfaceCard style={styles.sectionCard}>
              <Text style={[styles.sectionTitle, { color: colors.primary }]}>Contact Information</Text>
              <LabeledInput
                label="Mobile Number *"
                value={mobile}
                onChangeText={(value) => setMobile(value.replace(/\D/g, '').slice(0, 10))}
                placeholder="Enter 10-digit mobile number"
                keyboardType="phone-pad"
                maxLength={10}
                testID="claim-mobile"
              />
              <LabeledInput
                label="Email Address *"
                value={email}
                onChangeText={setEmail}
                placeholder="Enter email address"
                keyboardType="email-address"
                autoCapitalize="none"
                testID="claim-email"
              />
            </SurfaceCard>

            <SurfaceCard style={styles.sectionCard}>
              <Text style={[styles.sectionTitle, { color: colors.primary }]}>Claim Amount Details</Text>
              <LabeledInput
                label="Estimated Treatment Cost (₹) *"
                value={estimatedCost}
                onChangeText={(value) => setEstimatedCost(value.replace(/[^\d.]/g, ''))}
                placeholder="Enter estimated expenses"
                keyboardType="decimal-pad"
                testID="claim-estimated-cost"
              />
              <View style={styles.uploadHeading}>
                <View style={styles.policyCopy}>
                  <Text style={[styles.fieldTitle, { color: colors.foreground }]}>Upload Documents</Text>
                  <Text style={[styles.copy, { color: colors.mutedForeground }]}>
                    Attach up to five document images. Files remain on this device in demo mode.
                  </Text>
                </View>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Choose document images"
                  onPress={() => void chooseDocument()}
                  style={[styles.uploadButton, { backgroundColor: colors.primaryWash }]}
                  testID="claim-upload"
                >
                  <Ionicons name="cloud-upload-outline" size={20} color={colors.primary} />
                </Pressable>
              </View>
              {documents.map((document, index) => (
                <View key={`${document}-${index}`} style={[styles.documentRow, { borderColor: colors.border }]}>
                  <Ionicons name="document-attach-outline" size={17} color={colors.primary} />
                  <Text numberOfLines={1} style={[styles.documentName, { color: colors.foreground }]}>{document}</Text>
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel={`Remove ${document}`}
                    onPress={() => removeDocument(index)}
                    hitSlop={8}
                  >
                    <Ionicons name="close-circle" size={19} color={colors.mutedForeground} />
                  </Pressable>
                </View>
              ))}
            </SurfaceCard>

            {error ? <Text accessibilityRole="alert" style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
            <PrimaryButton label="Continue" icon="arrow-forward" onPress={continueIntimation} testID="claim-continue" />
            <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
              Demo flow only. No claim, payment, or insurer request is submitted.
            </Text>
          </>
        )}
      </KeyboardAwareScrollViewCompat>

      <Modal
        transparent
        visible={memberModalVisible}
        animationType="slide"
        onRequestClose={() => setMemberModalVisible(false)}
      >
        <View style={[styles.modalOverlay, { backgroundColor: colors.scrim }]}>
          <Pressable
            accessibilityLabel="Close insured member list"
            onPress={() => setMemberModalVisible(false)}
            style={StyleSheet.absoluteFill}
          />
          <SurfaceCard style={styles.memberSheet}>
            <View style={styles.sheetHeader}>
              <View style={styles.policyCopy}>
                <Text style={[styles.sheetTitle, { color: colors.foreground }]}>Select the Insured Member</Text>
                <Text style={[styles.copy, { color: colors.mutedForeground }]}>Choose one sample policy member.</Text>
              </View>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Close insured member list"
                onPress={() => setMemberModalVisible(false)}
                hitSlop={10}
              >
                <Ionicons name="close" size={22} color={colors.mutedForeground} />
              </Pressable>
            </View>
            {insuredMembers.map((member) => {
              const selected = pendingMemberId === member.id;
              return (
                <Pressable
                  key={member.id}
                  accessibilityRole="radio"
                  accessibilityState={{ selected }}
                  onPress={() => setPendingMemberId(member.id)}
                  style={[
                    styles.memberRow,
                    {
                      borderColor: selected ? colors.primary : colors.border,
                      backgroundColor: selected ? colors.primaryWash : colors.white,
                    },
                  ]}
                >
                  <View style={[styles.memberAvatar, { backgroundColor: colors.primaryWash }]}>
                    <Ionicons name="person" size={16} color={colors.primary} />
                  </View>
                  <View style={styles.memberSelectCopy}>
                    <Text style={[styles.memberName, { color: colors.foreground }]}>{member.name}</Text>
                    <Text style={[styles.copy, { color: colors.mutedForeground }]}>
                      Relationship · {member.relationship}
                    </Text>
                    <Text style={[styles.copy, { color: colors.mutedForeground }]}>
                      Member ID · {member.demoId}
                    </Text>
                  </View>
                  <Ionicons
                    name={selected ? 'radio-button-on' : 'radio-button-off'}
                    size={19}
                    color={selected ? colors.primary : colors.mutedForeground}
                  />
                </Pressable>
              );
            })}
            <PrimaryButton
              label="Confirm"
              icon="checkmark"
              disabled={!pendingMember}
              onPress={() => {
                if (pendingMember) setSelectedMember(pendingMember);
                setMemberModalVisible(false);
              }}
              testID="claim-member-confirm"
            />
          </SurfaceCard>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 14, gap: 11 },
  policyCard: { flexDirection: 'row', alignItems: 'center', gap: 9, padding: 11, borderColor: '#f3cdd5' },
  policyIcon: { width: 39, height: 39, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  policyCopy: { flex: 1, gap: 3 },
  policyTitle: { fontSize: 12, fontWeight: '800' },
  copy: { fontSize: 9, lineHeight: 14 },
  sectionCard: { gap: 10, padding: 11 },
  sectionTitle: { fontSize: 12, fontWeight: '800' },
  fieldTitle: { fontSize: 11, fontWeight: '700' },
  memberSelect: { minHeight: 54, borderWidth: 1, borderRadius: 11, paddingHorizontal: 9, paddingVertical: 7, flexDirection: 'row', alignItems: 'center', gap: 8 },
  memberSelectCopy: { flex: 1, gap: 3 },
  memberAvatar: { width: 33, height: 33, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  memberName: { fontSize: 10, fontWeight: '800' },
  twoColumns: { flexDirection: 'row', gap: 8 },
  multiline: { minHeight: 68, textAlignVertical: 'top', paddingTop: 10 },
  uploadHeading: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  uploadButton: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  documentRow: { minHeight: 38, borderWidth: 1, borderRadius: 9, paddingHorizontal: 8, flexDirection: 'row', alignItems: 'center', gap: 7 },
  documentName: { flex: 1, fontSize: 10, fontWeight: '600' },
  error: { fontSize: 10, lineHeight: 15 },
  disclaimer: { fontSize: 8, lineHeight: 12, textAlign: 'center', paddingHorizontal: 10 },
  successCard: { flex: 1, minHeight: 330, alignItems: 'center', justifyContent: 'center', gap: 12, padding: 20 },
  successIcon: { width: 56, height: 56, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  successTitle: { fontSize: 17, fontWeight: '800', textAlign: 'center' },
  modalOverlay: { flex: 1, justifyContent: 'flex-end', padding: 14, paddingBottom: 18 },
  memberSheet: { maxHeight: '88%', gap: 8, padding: 13 },
  sheetHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, paddingBottom: 5 },
  sheetTitle: { fontSize: 14, fontWeight: '800' },
  memberRow: { minHeight: 66, borderWidth: 1, borderRadius: 10, paddingHorizontal: 8, paddingVertical: 6, flexDirection: 'row', alignItems: 'center', gap: 8 },
});
