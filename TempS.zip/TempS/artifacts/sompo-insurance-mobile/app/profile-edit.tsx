import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import {
  AppHeader,
  HelperText,
  LabeledInput,
  PrimaryButton,
} from '@/components/AppUI';
import { UserProfile, useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function EditProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { profile, saveProfile } = useAppState();
  const [draft, setDraft] = useState<UserProfile>(profile);
  const [error, setError] = useState('');

  const change = (field: keyof UserProfile, value: string) => {
    setDraft((current) => ({ ...current, [field]: value }));
  };

  const save = async () => {
    if (!draft.fullName.trim()) {
      setError('Your name is required.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(draft.email.trim())) {
      setError('Enter a valid email address.');
      return;
    }
    await saveProfile(draft);
    router.back();
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.screen }]}>
      <KeyboardAwareScrollViewCompat
        style={styles.scroll}
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: (insets.top || 0) + (insets.top === 0 ? 67 : 12),
            paddingBottom: (insets.bottom || 0) + 24,
          },
        ]}
        keyboardShouldPersistTaps="handled"
        bottomOffset={60}
      >
        <AppHeader title="Edit Profile" onBack={() => router.back()} />
        <Text style={[styles.intro, { color: colors.mutedForeground }]}>
          Update the personal and emergency details saved on this device.
        </Text>
        <View style={styles.fields}>
          <LabeledInput label="Full Name" value={draft.fullName} onChangeText={(value) => change('fullName', value)} autoCapitalize="words" />
          <LabeledInput label="E-mail ID" value={draft.email} onChangeText={(value) => change('email', value)} keyboardType="email-address" autoCapitalize="none" />
          <LabeledInput label="Mobile Number" value={draft.mobile} onChangeText={(value) => change('mobile', value)} keyboardType="phone-pad" />
          <LabeledInput label="Gender" value={draft.gender} onChangeText={(value) => change('gender', value)} />
          <LabeledInput label="Date of Birth" placeholder="DD/MM/YYYY" value={draft.dateOfBirth} onChangeText={(value) => change('dateOfBirth', value)} />
          <LabeledInput label="Blood Group" value={draft.bloodGroup} onChangeText={(value) => change('bloodGroup', value)} />
          <LabeledInput label="Height" value={draft.height} onChangeText={(value) => change('height', value)} />
          <LabeledInput label="Weight" value={draft.weight} onChangeText={(value) => change('weight', value)} />
          <LabeledInput label="Daily Activity" value={draft.dailyActivity} onChangeText={(value) => change('dailyActivity', value)} />
          <LabeledInput label="Emergency Contact Person" value={draft.emergencyName} onChangeText={(value) => change('emergencyName', value)} />
          <LabeledInput label="Emergency Contact Number" value={draft.emergencyPhone} onChangeText={(value) => change('emergencyPhone', value)} keyboardType="phone-pad" />
          {error ? (
            <Text accessibilityRole="alert" style={[styles.error, { color: colors.primary }]}>
              {error}
            </Text>
          ) : null}
          <HelperText>Changes are saved locally on this device.</HelperText>
          <PrimaryButton label="Save Changes" icon="checkmark" onPress={() => void save()} testID="profile-save" />
        </View>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 18, gap: 11 },
  intro: { fontSize: 13, lineHeight: 19 },
  fields: { gap: 13, paddingVertical: 5 },
  error: { fontSize: 13, fontWeight: '600' },
});
