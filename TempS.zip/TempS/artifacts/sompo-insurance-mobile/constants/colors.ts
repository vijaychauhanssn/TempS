/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    text: '#24191d',
    tint: '#c8103d',
    background: '#ffffff',
    foreground: '#24191d',
    card: '#ffffff',
    cardForeground: '#24191d',
    primary: '#c8103d',
    primaryForeground: '#ffffff',
    primarySoft: '#ed5969',
    primaryDeep: '#970b2c',
    primaryLightText: '#ffe5eb',
    primaryMutedText: '#ffeef1',
    primaryPale: '#f6d3da',
    primaryWash: '#fff0f3',
    screen: '#fff8f9',
    white: '#ffffff',
    secondary: '#f4eaed',
    secondaryForeground: '#38242b',
    muted: '#f2ecee',
    mutedForeground: '#7d7075',
    placeholder: '#a99da2',
    accent: '#fde4e9',
    accentForeground: '#24191d',
    destructive: '#bd123b',
    destructiveForeground: '#ffffff',
    border: '#eadde0',
    borderStrong: '#d4c7cb',
    input: '#d4c7cb',
    success: '#2c8060',
    gold: '#efb91d',
    pink: '#fbe0e6',
    rose: '#f7d5dd',
    blue: '#dceef5',
    vehicle: '#f6e2d5',
    health: '#f8dce3',
    shadow: '#55212e',
    scrim: 'rgba(31, 18, 23, 0.52)',
  },

  radius: 16,
};

export default colors;
