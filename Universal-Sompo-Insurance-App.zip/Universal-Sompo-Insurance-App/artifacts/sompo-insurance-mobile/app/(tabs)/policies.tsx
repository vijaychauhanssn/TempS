import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import {
  AppPage,
  PrimaryButton,
  SectionHeading,
  SurfaceCard,
} from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

const categories = [
  { title: 'Health Insurance', detail: 'Individual and family health cover', icon: 'heart-outline' as const },
  { title: 'Car Insurance', detail: 'Cover for your four-wheeler', icon: 'car-sport-outline' as const },
  { title: 'Two-wheeler Insurance', detail: 'Protection for every ride', icon: 'bicycle-outline' as const },
  { title: 'Travel Insurance', detail: 'Support while you are away', icon: 'airplane-outline' as const },
];

export default function PoliciesScreen() {
  const colors = useColors();
  return (
    <AppPage contentStyle={styles.content}>
      <View style={styles.titleBlock}>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>INSURANCE VAULT</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>My Policies</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Keep your cover details together and easy to find.
        </Text>
      </View>
      <SurfaceCard style={styles.emptyCard}>
        <View style={[styles.emptyIcon, { backgroundColor: colors.primaryWash }]}>
          <Ionicons name="shield-checkmark-outline" size={29} color={colors.primary} />
        </View>
        <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
          No policies added yet
        </Text>
        <Text style={[styles.emptyCopy, { color: colors.mutedForeground }]}>
          Add a policy to start building your insurance vault.
        </Text>
        <PrimaryButton
          label="Explore insurance"
          icon="arrow-forward"
          onPress={() => router.push({ pathname: '/insurance', params: { type: 'Insurance' } })}
          style={styles.exploreButton}
        />
      </SurfaceCard>
      <SectionHeading title="Explore protection" />
      <View style={styles.list}>
        {categories.map((item) => (
          <Pressable
            key={item.title}
            onPress={() => router.push({ pathname: '/insurance', params: { type: item.title } })}
            style={({ pressed }) => pressed && { opacity: 0.76 }}
          >
            <SurfaceCard style={styles.categoryCard}>
              <View style={[styles.categoryIcon, { backgroundColor: colors.primaryWash }]}>
                <Ionicons name={item.icon} size={23} color={colors.primary} />
              </View>
              <View style={styles.categoryCopy}>
                <Text style={[styles.categoryTitle, { color: colors.foreground }]}>
                  {item.title}
                </Text>
                <Text style={[styles.categoryDetail, { color: colors.mutedForeground }]}>
                  {item.detail}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.mutedForeground} />
            </SurfaceCard>
          </Pressable>
        ))}
      </View>
      <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
        Demo screen · policies are not connected to a live account.
      </Text>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { gap: 17, paddingHorizontal: 16 },
  titleBlock: { gap: 5, paddingTop: 4 },
  eyebrow: { fontSize: 10, fontWeight: '800', letterSpacing: 1.2 },
  title: { fontSize: 28, fontWeight: '800' },
  subtitle: { fontSize: 13, lineHeight: 19 },
  emptyCard: { alignItems: 'center', padding: 20, gap: 9 },
  emptyIcon: { width: 58, height: 58, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { fontSize: 17, fontWeight: '800', textAlign: 'center' },
  emptyCopy: { fontSize: 12, lineHeight: 17, textAlign: 'center', maxWidth: 250 },
  exploreButton: { width: '100%', marginTop: 5 },
  list: { gap: 9 },
  categoryCard: { flexDirection: 'row', alignItems: 'center', gap: 11, padding: 12 },
  categoryIcon: { width: 44, height: 44, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  categoryCopy: { flex: 1, gap: 4 },
  categoryTitle: { fontSize: 13, fontWeight: '700' },
  categoryDetail: { fontSize: 11 },
  disclaimer: { fontSize: 10, textAlign: 'center', marginTop: 3 },
});
