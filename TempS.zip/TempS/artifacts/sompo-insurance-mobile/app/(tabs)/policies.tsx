import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppPage, IconButton, SurfaceCard } from '@/components/AppUI';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

const filters = ['All', 'Health', 'Motor', 'Other'] as const;

export default function PoliciesScreen() {
  const colors = useColors();
  const { policies } = useAppState();
  const [filter, setFilter] = useState<(typeof filters)[number]>('All');
  const [showFilters, setShowFilters] = useState(false);
  const visiblePolicies = useMemo(
    () => (filter === 'All' ? policies : policies.filter((policy) => policy.category === filter)),
    [filter, policies],
  );

  const cycleFilter = () => {
    const index = filters.indexOf(filter);
    setFilter(filters[(index + 1) % filters.length]);
    setShowFilters(true);
  };

  return (
    <AppPage contentStyle={styles.content}>
      <View style={styles.header}>
        <View style={styles.titleCopy}>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>INSURANCE VAULT</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>My Policy</Text>
        </View>
        <IconButton
          name="add"
          label="Add policy"
          color={colors.primary}
          onPress={() => router.push('/add-policy')}
        />
      </View>
      <View style={styles.descriptionRow}>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Use the smart vault to understand your insurance policies better.
        </Text>
        <Pressable
          onPress={cycleFilter}
          style={[styles.filterButton, { backgroundColor: colors.card, borderColor: colors.primary }]}
        >
          <Ionicons name="filter-outline" size={13} color={colors.primary} />
          <Text style={[styles.filterText, { color: colors.primary }]}>Filter</Text>
        </Pressable>
      </View>
      {showFilters ? (
        <View style={styles.filterRow}>
          {filters.map((item) => (
            <Pressable
              key={item}
              onPress={() => setFilter(item)}
              style={[
                styles.filterChip,
                {
                  backgroundColor: filter === item ? colors.primary : colors.card,
                  borderColor: filter === item ? colors.primary : colors.border,
                },
              ]}
            >
              <Text style={[styles.filterChipText, { color: filter === item ? colors.white : colors.foreground }]}>
                {item}
              </Text>
            </Pressable>
          ))}
        </View>
      ) : null}

      {visiblePolicies.length ? (
        <View style={styles.policyList}>
          {visiblePolicies.map((policy) => (
            <Pressable
              key={policy.id}
              onPress={() => router.push({ pathname: '/policy-detail', params: { id: policy.id } })}
              style={({ pressed }) => [pressed && styles.pressed]}
            >
              <SurfaceCard style={styles.policyCard}>
                <View style={styles.policyTitleRow}>
                  <View style={[styles.policyTypeIcon, { backgroundColor: colors.primaryWash }]}>
                    <Ionicons
                      name={policy.category === 'Motor' ? 'car-outline' : policy.category === 'Health' ? 'heart-outline' : 'shield-outline'}
                      size={19}
                      color={colors.primary}
                    />
                  </View>
                  <View style={styles.policyTitleCopy}>
                    <Text style={[styles.policyName, { color: colors.primary }]}>{policy.name}</Text>
                    <Text style={[styles.company, { color: colors.mutedForeground }]}>{policy.company}</Text>
                  </View>
                  <Ionicons name="chevron-forward" size={17} color={colors.mutedForeground} />
                </View>
                <View style={styles.detailLine}>
                  <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Sum Assured:</Text>
                  <Text style={[styles.detailValue, { color: colors.foreground }]}>{policy.sumAssured}</Text>
                </View>
                <View style={styles.detailLine}>
                  <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Policy No:</Text>
                  <Text style={[styles.detailValue, { color: colors.foreground }]}>{policy.policyNumber}</Text>
                </View>
                <View style={styles.detailLine}>
                  <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Expiry Date:</Text>
                  <Text style={[styles.detailValue, { color: colors.foreground }]}>{policy.expiryDate}</Text>
                </View>
              </SurfaceCard>
            </Pressable>
          ))}
        </View>
      ) : (
        <SurfaceCard style={styles.emptyCard}>
          <Ionicons name="shield-checkmark-outline" size={28} color={colors.primary} />
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No {filter === 'All' ? '' : `${filter.toLowerCase()} `}policies</Text>
          <Text style={[styles.emptyBody, { color: colors.mutedForeground }]}>
            Link a policy or explore insurance to add cover to your vault.
          </Text>
        </SurfaceCard>
      )}

      <Pressable onPress={() => router.push('/add-policy')} style={({ pressed }) => [pressed && styles.pressed]}>
        <SurfaceCard style={[styles.addBanner, { backgroundColor: colors.primaryWash }]}>
          <View style={[styles.addIcon, { backgroundColor: colors.white }]}>
            <Ionicons name="add" size={23} color={colors.primary} />
          </View>
          <View style={styles.addCopy}>
            <Text style={[styles.addTitle, { color: colors.foreground }]}>Can’t see your policy?</Text>
            <Text style={[styles.addBody, { color: colors.mutedForeground }]}>
              Link a policy to keep everything together.
            </Text>
          </View>
          <Ionicons name="arrow-forward" size={17} color={colors.primary} />
        </SurfaceCard>
      </Pressable>
      <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
        Sample policy information is for demonstration only.
      </Text>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { gap: 12, paddingHorizontal: 14 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  titleCopy: { gap: 3 },
  eyebrow: { fontSize: 9, fontWeight: '800', letterSpacing: 1.1 },
  title: { fontSize: 25, fontWeight: '800' },
  descriptionRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  subtitle: { flex: 1, fontSize: 11, lineHeight: 16 },
  filterButton: { borderWidth: 1, borderRadius: 15, paddingHorizontal: 10, paddingVertical: 6, flexDirection: 'row', alignItems: 'center', gap: 4 },
  filterText: { fontSize: 10, fontWeight: '700' },
  filterRow: { flexDirection: 'row', gap: 7, marginTop: -3 },
  filterChip: { borderWidth: 1, borderRadius: 15, paddingHorizontal: 11, paddingVertical: 6 },
  filterChipText: { fontSize: 10, fontWeight: '700' },
  policyList: { gap: 9 },
  policyCard: { padding: 12, gap: 6, borderRadius: 15 },
  policyTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  policyTypeIcon: { width: 35, height: 35, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  policyTitleCopy: { flex: 1, gap: 3 },
  policyName: { fontSize: 11, fontWeight: '800', textTransform: 'uppercase' },
  company: { fontSize: 9 },
  detailLine: { flexDirection: 'row', justifyContent: 'space-between', gap: 12 },
  detailLabel: { fontSize: 10 },
  detailValue: { fontSize: 10, fontWeight: '600', textAlign: 'right', flexShrink: 1 },
  emptyCard: { alignItems: 'center', padding: 20, gap: 8 },
  emptyTitle: { fontSize: 15, fontWeight: '800' },
  emptyBody: { maxWidth: 250, textAlign: 'center', fontSize: 11, lineHeight: 16 },
  addBanner: { flexDirection: 'row', alignItems: 'center', gap: 9, borderRadius: 15, padding: 11 },
  addIcon: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  addCopy: { flex: 1, gap: 3 },
  addTitle: { fontSize: 11, fontWeight: '800' },
  addBody: { fontSize: 9, lineHeight: 13 },
  disclaimer: { fontSize: 9, textAlign: 'center', lineHeight: 14 },
  pressed: { opacity: 0.74 },
});
