import React from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { AppHeader, AppPage, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

export default function PolicyDetailScreen() {
  const colors = useColors();
  const { id = '' } = useLocalSearchParams<{ id?: string }>();
  const { policies, removePolicy } = useAppState();
  const policy = policies.find((item) => item.id === id);

  if (!policy) {
    return (
      <AppPage contentStyle={styles.content}>
        <AppHeader title="Policy Details" onBack={() => router.back()} />
        <SurfaceCard style={styles.emptyCard}>
          <Ionicons name="document-outline" size={30} color={colors.mutedForeground} />
          <Text style={[styles.title, { color: colors.foreground }]}>Policy not found</Text>
          <PrimaryButton label="Back to My Policy" onPress={() => router.replace('/policies')} />
        </SurfaceCard>
      </AppPage>
    );
  }

  const remove = () => {
    Alert.alert('Remove policy?', 'This removes this policy from the local demo vault.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: () => {
          void removePolicy(policy.id);
          router.replace('/policies');
        },
      },
    ]);
  };

  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="Policy Details" onBack={() => router.back()} />
      <View style={[styles.hero, { backgroundColor: colors.primary }]}>
        <Ionicons name={policy.category === 'Motor' ? 'car-outline' : 'heart-outline'} size={25} color={colors.white} />
        <Text style={[styles.heroTitle, { color: colors.white }]}>{policy.name}</Text>
        <Text style={[styles.heroCompany, { color: colors.primaryMutedText }]}>{policy.company}</Text>
      </View>
      <SurfaceCard style={styles.details}>
        <Detail label="Policy number" value={policy.policyNumber} />
        <Detail label="Sum insured" value={policy.sumAssured} />
        <Detail label="Expiry date" value={policy.expiryDate} />
        <Detail label="Policy type" value={policy.category} />
        <Detail label="Data source" value={policy.isSample ? 'Sample policy' : 'Linked on this device'} />
      </SurfaceCard>
      <PrimaryButton
        label="Renew policy"
        icon="arrow-forward"
        onPress={() => router.push({ pathname: '/policy-renewal', params: { policyId: policy.id } })}
      />
      <PrimaryButton
        label="Start a claim"
        icon="document-text-outline"
        onPress={() => router.push('/claims')}
      />
      <PrimaryButton
        label="View certificate"
        icon="document-text-outline"
        onPress={() => Alert.alert('Policy certificate', 'Official certificates are not available in this demo.')}
      />
      <Text onPress={remove} style={[styles.removeLink, { color: colors.destructive }]}>Remove from this device</Text>
      <Text style={[styles.note, { color: colors.mutedForeground }]}>
        Sample policy details are illustrative and do not confirm active insurance cover.
      </Text>
    </AppPage>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  const colors = useColors();
  return (
    <View style={styles.detailRow}>
      <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.detailValue, { color: colors.foreground }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 15, gap: 12 },
  hero: { minHeight: 126, borderRadius: 18, padding: 17, alignItems: 'flex-start', justifyContent: 'center', gap: 7 },
  heroTitle: { fontSize: 17, fontWeight: '800' },
  heroCompany: { fontSize: 11 },
  details: { gap: 12, padding: 14 },
  detailRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 14 },
  detailLabel: { fontSize: 11 },
  detailValue: { flex: 1, fontSize: 11, fontWeight: '700', textAlign: 'right' },
  removeLink: { fontSize: 11, fontWeight: '700', textAlign: 'center', paddingVertical: 6 },
  note: { fontSize: 9, lineHeight: 14, textAlign: 'center' },
  emptyCard: { alignItems: 'center', gap: 12, padding: 22 },
  title: { fontSize: 18, fontWeight: '800' },
});
