# Universal Sompo Insurance Mobile

A React Native Expo demo that recreates the supplied Universal Sompo insurance app screens for Android and iOS.

## Run & Operate

- `pnpm --filter @workspace/sompo-insurance-mobile run dev` — run the Expo app
- `pnpm --filter @workspace/sompo-insurance-mobile run typecheck` — typecheck the mobile app
- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `DATABASE_URL` is used by the shared API/database packages; the mobile demo does not require it.

## Stack

- pnpm workspaces, Node.js 24, TypeScript
- Mobile app: Expo SDK 57, React Native, Expo Router, AsyncStorage
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/sompo-insurance-mobile/app/` — onboarding, authentication, tabs, and supporting screens
- `artifacts/sompo-insurance-mobile/components/` — shared mobile UI
- `artifacts/sompo-insurance-mobile/context/AppState.tsx` — local profile and demo session persistence
- `artifacts/sompo-insurance-mobile/assets/images/` — supplied-screen crops and app icon
- `lib/api-spec/openapi.yaml` — shared API contract

## Architecture decisions

- The insurance app is a local demo, not a connected insurer account. Profiles use AsyncStorage; login OTP is simulated with `123456`.
- The app has no mobile API or database dependency in this build. Connect authentication and insurer policy services before treating it as a production client.

## Product

The app recreates the supplied onboarding and login/register flow, a policy and insurance dashboard, profile vault, notifications, resources, support, FAQs, and an offline wellness calculator. Interactions use local demo data where no live service was supplied.

## User preferences

The user supplied reference screenshots and requested a cross-platform React Native Expo app in TypeScript that follows those screens.

## Gotchas

The demo OTP shown on the login screen is `123456`; it does not send an SMS or email. Policy and product data are illustrative only.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
