import React, { useState } from 'react';
import {
  Alert,
  Image,
  ImageBackground,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  AppPage,
  Avatar,
  Hairline,
  IconButton,
  OutlineButton,
  PrimaryButton,
  SectionHeading,
  SurfaceCard,
} from '@/components/AppUI';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

const buyItems = [
  { label: '4 Wheeler', icon: 'car-sport-outline' as const, vehicle: 'Four Wheeler' },
  { label: '2 Wheeler', icon: 'bicycle-outline' as const, vehicle: 'Two Wheeler' },
  { label: 'Health', icon: 'heart-outline' as const },
];

const moreItems = [
  { label: 'Health & wellness', icon: 'heart-outline' as const, route: '/(tabs)/wellness' as const },
  { label: 'Policy certificate', icon: 'document-text-outline' as const, route: '/policies' as const },
  { label: 'Check claim status', icon: 'search-outline' as const, route: '/claims' as const },
  { label: 'My vehicle', icon: 'car-outline' as const, route: '/renewal' as const },
  { label: 'Personal accident', icon: 'shield-checkmark-outline' as const, route: '/health-plan?plan=complete' as const },
  { label: 'Travel', icon: 'airplane-outline' as const, route: '/insurance?type=Travel%20Insurance' as const },
];

const quickLinks = [
  { label: 'Renew policy', icon: 'refresh-outline' as const, tone: 'pink', route: '/renewal' as const },
  { label: 'Claims', icon: 'document-text-outline' as const, tone: 'rose', route: '/claims' as const },
  { label: 'Find a hospital', icon: 'location-outline' as const, tone: 'blue', route: '/find-hospitals' as const },
  { label: 'Link a policy', icon: 'add-circle-outline' as const, tone: 'gold', route: '/add-policy' as const },
] as const;

const healthPlans = [
  { title: 'A Plus Health Insurance', detail: '4× cover · 15% direct discounts', icon: 'heart' as const, key: 'a-plus' },
  { title: 'Complete Healthcare', detail: 'Flexible family health cover', icon: 'people' as const, key: 'complete' },
  { title: 'Super Healthcare', detail: 'Cashless care across India', icon: 'medkit' as const, key: 'super' },
  { title: 'Arogya Sanjeevani', detail: 'Essential health protection', icon: 'shield-checkmark' as const, key: 'arogya' },
];

function HomeCategory({
  label,
  icon,
  onPress,
  compact = false,
}: {
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  onPress: () => void;
  compact?: boolean;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={({ pressed }) => [
        styles.categoryItem,
        compact && styles.compactCategory,
        pressed && styles.pressed,
      ]}
    >
      <View
        style={[
          styles.categoryIcon,
          { backgroundColor: compact ? colors.primaryWash : colors.primaryPale },
          compact && styles.compactCategoryIcon,
        ]}
      >
        <Ionicons name={icon} size={compact ? 19 : 23} color={colors.primary} />
      </View>
      <Text numberOfLines={2} style={[styles.categoryLabel, { color: colors.foreground }]}>
        {label}
      </Text>
    </Pressable>
  );
}

function HomeDrawer({
  visible,
  onClose,
}: {
  visible: boolean;
  onClose: () => void;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { profile, logout, deleteLocalAccount } = useAppState();
  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;

  const go = (path: '/profile' | '/calculator' | '/resources' | '/faq' | '/contact') => {
    onClose();
    router.push(path);
  };

  const dial = async () => {
    try {
      await Linking.openURL('tel:1800224030');
    } catch {
      Alert.alert('Emergency support', 'Call 1800-22-4030 for assistance.');
    }
  };

  const removeAccount = () => {
    Alert.alert(
      'Delete demo account?',
      'This removes the profile and demo sign-in saved on this device.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete account',
          style: 'destructive',
          onPress: () => {
            void deleteLocalAccount();
            onClose();
            router.replace('/welcome');
          },
        },
      ],
    );
  };

  const group = (
    title: string,
    items: {
      label: string;
      icon: keyof typeof Ionicons.glyphMap;
      onPress: () => void;
    }[],
  ) => (
    <View style={[styles.drawerGroup, { backgroundColor: colors.white }]}>
      <Text style={[styles.drawerGroupTitle, { color: colors.foreground }]}>{title}</Text>
      {items.map((item, index) => (
        <React.Fragment key={item.label}>
          {index > 0 ? <Hairline /> : null}
          <Pressable
            onPress={item.onPress}
            accessibilityRole="button"
            style={({ pressed }) => [styles.drawerItem, pressed && styles.pressed]}
          >
            <Ionicons name={item.icon} size={19} color={colors.mutedForeground} />
            <Text style={[styles.drawerItemText, { color: colors.foreground }]}>
              {item.label}
            </Text>
            <Ionicons name="chevron-forward" size={15} color={colors.mutedForeground} />
          </Pressable>
        </React.Fragment>
      ))}
    </View>
  );

  return (
    <Modal
      transparent
      animationType="fade"
      visible={visible}
      onRequestClose={onClose}
      statusBarTranslucent
    >
      <View style={styles.drawerOverlay}>
        <Pressable
          onPress={onClose}
          accessibilityLabel="Close menu"
          style={[StyleSheet.absoluteFill, { backgroundColor: colors.scrim }]}
        />
        <View
          style={[
            styles.drawer,
            {
              paddingTop: topInset + 10,
              paddingBottom: Math.max(insets.bottom, 12),
              backgroundColor: colors.screen,
              borderTopRightRadius: 28,
              borderBottomRightRadius: 28,
            },
          ]}
        >
          <View style={[styles.drawerProfile, { backgroundColor: colors.white, borderColor: colors.border }]}>
            <Avatar name={profile.fullName} size={54} />
            <View style={styles.drawerProfileCopy}>
              <Text numberOfLines={1} style={[styles.drawerName, { color: colors.foreground }]}>
                {profile.fullName}
              </Text>
              <Text numberOfLines={1} style={[styles.drawerEmail, { color: colors.mutedForeground }]}>
                {profile.email}
              </Text>
            </View>
            <Pressable
              onPress={() => go('/profile')}
              accessibilityRole="button"
              accessibilityLabel="Edit profile"
            >
              <Ionicons name="create-outline" size={21} color={colors.primary} />
            </Pressable>
          </View>

          <ScrollView
            style={styles.drawerScroll}
            contentContainerStyle={styles.drawerScrollContent}
            showsVerticalScrollIndicator={false}
          >
            {group('Account', [
              { label: 'My Profile', icon: 'person-circle-outline', onPress: () => go('/profile') },
              { label: 'My Policies', icon: 'document-text-outline', onPress: () => { onClose(); router.push('/policies'); } },
            ])}
            {group('App Features', [
              { label: 'Offline Calculator', icon: 'calculator-outline', onPress: () => go('/calculator') },
              { label: 'Resources', icon: 'book-outline', onPress: () => go('/resources') },
              { label: 'Privacy Policy', icon: 'lock-closed-outline', onPress: () => Alert.alert('Privacy Policy', 'This demo stores profile and policy details only on this device. No insurer service is connected.') },
              { label: 'Terms & Conditions', icon: 'document-text-outline', onPress: () => Alert.alert('Terms & Conditions', 'This is a visual demo. Insurance information and calculations are illustrative only.') },
            ])}
            {group('Support', [
              { label: 'Contact Us', icon: 'call-outline', onPress: () => go('/contact') },
              { label: 'Rate Us', icon: 'star-outline', onPress: () => Alert.alert('Thank you', 'App ratings are not connected in this demo.') },
              { label: 'FAQ', icon: 'help-circle-outline', onPress: () => go('/faq') },
              { label: 'Emergency', icon: 'medkit-outline', onPress: () => void dial() },
            ])}
          </ScrollView>

          <View style={styles.drawerActions}>
            <PrimaryButton
              label="Logout"
              icon="chevron-forward"
              onPress={() => {
                void logout();
                onClose();
                router.replace('/welcome');
              }}
            />
            <OutlineButton label="Delete Account" icon="trash-outline" onPress={removeAccount} />
            <Text style={[styles.version, { color: colors.mutedForeground }]}>Version · 2.86</Text>
          </View>
        </View>
      </View>
    </Modal>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const { profile, policies } = useAppState();
  const [drawerVisible, setDrawerVisible] = useState(false);

  const openInsurance = (vehicle?: string) => {
    if (vehicle) {
      router.push({ pathname: '/motor-insurance', params: { vehicle } });
    } else {
      router.push({ pathname: '/health-buy', params: { plan: 'complete' } });
    }
  };

  return (
    <>
      <AppPage contentStyle={styles.homeContent}>
        <View style={styles.homeHeader}>
          <Pressable
            onPress={() => setDrawerVisible(true)}
            accessibilityRole="button"
            accessibilityLabel="Open menu"
            style={styles.menuButton}
          >
            <Ionicons name="menu" size={26} color={colors.foreground} />
          </Pressable>
          <View style={styles.greeting}>
            <Text style={[styles.greetingSmall, { color: colors.mutedForeground }]}>Hi,</Text>
            <Text numberOfLines={1} style={[styles.greetingName, { color: colors.foreground }]}>
              {profile.fullName}
            </Text>
          </View>
          <Avatar name={profile.fullName} size={39} />
          <IconButton
            name="notifications-outline"
            label="Notifications"
            badge
            onPress={() => router.push('/notifications')}
          />
        </View>

        <ImageBackground
          source={require('../../assets/images/home-hero.png')}
          imageStyle={styles.promoImage}
          style={styles.promoHero}
        >
          <LinearGradient
            colors={[colors.primaryDeep, 'transparent']}
            start={{ x: 0, y: 1 }}
            end={{ x: 0.75, y: 0 }}
            style={styles.promoShade}
          />
          <View style={styles.promoCopy}>
            <Text style={[styles.promoEyebrow, { color: colors.white }]}>PROTECTION FOR WHAT MATTERS</Text>
            <Text style={[styles.promoTitle, { color: colors.white }]}>Cover for every chapter.</Text>
            <Pressable
              onPress={() => router.push('/policies')}
              style={({ pressed }) => [styles.promoButton, { backgroundColor: colors.white }, pressed && styles.pressed]}
            >
              <Text style={[styles.promoButtonText, { color: colors.primary }]}>Explore insurance</Text>
              <Ionicons name="arrow-forward" size={14} color={colors.primary} />
            </Pressable>
          </View>
        </ImageBackground>

        <SurfaceCard style={styles.policyPanel}>
          <View style={styles.policyPanelTop}>
            <View style={styles.policyIcon}>
              <Ionicons name="shield-checkmark" size={23} color={colors.primary} />
            </View>
            <View style={styles.policyPanelCopy}>
              <Text style={[styles.policyPanelTitle, { color: colors.foreground }]}>My Policy</Text>
              <Text style={[styles.policyPanelDetail, { color: colors.mutedForeground }]}>
                Your insurance policies, together.
              </Text>
            </View>
            <Text style={[styles.policyCount, { color: colors.primary }]}>
              {policies.length} {policies.length === 1 ? 'Policy' : 'Policies'}
            </Text>
          </View>
          <Hairline />
          <View style={styles.policyActions}>
            <Pressable
              onPress={() => router.push('/policies')}
              accessibilityRole="button"
              style={({ pressed }) => [styles.policyAction, { borderColor: colors.primary }, pressed && styles.pressed]}
            >
              <Ionicons name="document-text-outline" size={16} color={colors.primary} />
              <Text style={[styles.policyActionText, { color: colors.primary }]}>View policies</Text>
            </Pressable>
            <Pressable
              onPress={() => router.push('/add-policy')}
              accessibilityRole="button"
              style={({ pressed }) => [styles.policyAction, { backgroundColor: colors.primary }, pressed && styles.pressed]}
            >
              <Ionicons name="add" size={18} color={colors.white} />
              <Text style={[styles.policyActionText, { color: colors.white }]}>Add policy</Text>
            </Pressable>
          </View>
        </SurfaceCard>

        <View style={styles.section}>
          <SectionHeading title="Buy Insurance" actionLabel="See all" onAction={() => router.push('/policies')} />
          <View style={styles.buyGrid}>
            {buyItems.map((item) => (
              <HomeCategory
                key={item.label}
                label={item.label}
                icon={item.icon}
                onPress={() => openInsurance(item.vehicle)}
              />
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <SectionHeading title="More Than Just Insurance" actionLabel="Explore" onAction={() => router.push('/nearby')} />
          <SurfaceCard style={styles.moreGrid}>
            {moreItems.map((item) => (
              <HomeCategory
                key={item.label}
                label={item.label}
                icon={item.icon}
                compact
                onPress={() => router.push(item.route)}
              />
            ))}
          </SurfaceCard>
        </View>

        <View style={styles.section}>
          <SectionHeading title="Quick Links" />
          <View style={styles.quickGrid}>
            {quickLinks.map((item) => (
              <Pressable
                key={item.label}
                onPress={() => router.push(item.route)}
                style={({ pressed }) => [
                  styles.quickLink,
                  { backgroundColor: colors[item.tone] },
                  pressed && styles.pressed,
                ]}
              >
                <Ionicons name={item.icon} size={20} color={colors.primaryDeep} />
                <Text style={[styles.quickLabel, { color: colors.foreground }]}>{item.label}</Text>
                <Ionicons name="chevron-forward" size={15} color={colors.primary} />
              </Pressable>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <SectionHeading title="Insurance Plans That Are Made for You" actionLabel="View all" onAction={() => router.push('/health-plan?plan=a-plus')} />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.horizontalCards}>
            {healthPlans.map((plan, index) => (
              <PlanPreview
                key={plan.key}
                title={plan.title}
                description={plan.detail}
                icon={plan.icon}
                color={index % 2 === 0 ? colors.health : colors.vehicle}
                onPress={() => router.push({ pathname: '/health-plan', params: { plan: plan.key } })}
              />
            ))}
          </ScrollView>
        </View>

        <SurfaceCard style={styles.trustCard}>
          <View style={styles.trustHeading}>
            <Ionicons name="shield-checkmark" size={18} color={colors.primary} />
            <Text style={[styles.trustTitle, { color: colors.foreground }]}>Trusted by customers across India</Text>
          </View>
          <View style={styles.trustStats}>
            <TrustStat icon="people-outline" label="Care that puts you first" />
            <TrustStat icon="business-outline" label="Wide hospital network" />
            <TrustStat icon="headset-outline" label="Here when you need us" />
          </View>
        </SurfaceCard>

        <View style={styles.section}>
          <SectionHeading title="What Our Customers Are Saying" actionLabel="Read more" onAction={() => router.push('/faq')} />
          <SurfaceCard style={styles.testimonial}>
            <View style={styles.stars}>
              {Array.from({ length: 5 }, (_, index) => (
                <Ionicons key={index} name="star" size={15} color={colors.gold} />
              ))}
            </View>
            <Text style={[styles.quote, { color: colors.foreground }]}>
              “Easy to find the information I need and manage my cover in one place.”
            </Text>
            <Text style={[styles.quoteBy, { color: colors.mutedForeground }]}>Universal Sompo app user</Text>
          </SurfaceCard>
        </View>

        <View style={styles.section}>
          <SectionHeading title="Insightful Blogs" actionLabel="See all" onAction={() => router.push('/resources')} />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.horizontalCards}>
            <StoryCard
              title="Understanding health cover"
              category="HEALTH GUIDES"
              image={require('../../assets/images/resource-healthcare.png')}
              onPress={() => router.push('/resources')}
            />
            <StoryCard
              title="A clearer claims journey"
              category="INSURANCE TIPS"
              image={require('../../assets/images/resource-claimform.png')}
              onPress={() => router.push('/claims')}
            />
            <StoryCard
              title="Protecting your everyday"
              category="WELLNESS"
              image={require('../../assets/images/resource-supreme.png')}
              onPress={() => router.push('/resources')}
            />
          </ScrollView>
        </View>

        <View style={styles.section}>
          <SectionHeading title="Tutorial Videos" actionLabel="See all" onAction={() => router.push('/resources')} />
          <Pressable onPress={() => router.push('/webinar')} style={({ pressed }) => [pressed && styles.pressed]}>
            <ImageBackground
              source={require('../../assets/images/webinar-banner.png')}
              imageStyle={styles.webinarImage}
              style={styles.webinarCard}
            >
              <View style={[styles.playButton, { backgroundColor: colors.white }]}>
                <Ionicons name="play" size={20} color={colors.primary} />
              </View>
              <View style={[styles.webinarTextBlock, { backgroundColor: colors.scrim }]}>
                <Text style={[styles.webinarEyebrow, { color: colors.white }]}>HEALTH WEBINAR</Text>
                <Text style={[styles.webinarTitle, { color: colors.white }]}>Lifestyle habits for stress resilience</Text>
              </View>
            </ImageBackground>
          </Pressable>
        </View>

        <Text style={[styles.demoNote, { color: colors.mutedForeground }]}>
          Sample policies and product information are for demonstration only.
        </Text>
      </AppPage>
      <HomeDrawer visible={drawerVisible} onClose={() => setDrawerVisible(false)} />
    </>
  );
}

function PlanPreview({
  title,
  description,
  icon,
  color,
  onPress,
}: {
  title: string;
  description: string;
  icon: keyof typeof Ionicons.glyphMap;
  color: string;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.planCard,
        { backgroundColor: colors.card, borderColor: colors.border, shadowColor: colors.shadow },
        pressed && styles.pressed,
      ]}
    >
      <View style={[styles.planIcon, { backgroundColor: color }]}>
        <Ionicons name={icon} size={23} color={colors.primaryDeep} />
      </View>
      <Text numberOfLines={2} style={[styles.planTitle, { color: colors.foreground }]}>{title}</Text>
      <Text numberOfLines={2} style={[styles.planDescription, { color: colors.mutedForeground }]}>{description}</Text>
      <Text style={[styles.planLink, { color: colors.primary }]}>View plan  ›</Text>
    </Pressable>
  );
}

function TrustStat({
  icon,
  label,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
}) {
  const colors = useColors();
  return (
    <View style={styles.trustStat}>
      <Ionicons name={icon} size={18} color={colors.primary} />
      <Text style={[styles.trustStatLabel, { color: colors.mutedForeground }]}>{label}</Text>
    </View>
  );
}

function StoryCard({
  title,
  category,
  image,
  onPress,
}: {
  title: string;
  category: string;
  image: number;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.storyCard,
        { backgroundColor: colors.card, borderColor: colors.border },
        pressed && styles.pressed,
      ]}
    >
      <Image source={image} style={styles.storyImage} />
      <Text style={[styles.storyCategory, { color: colors.primary }]}>{category}</Text>
      <Text numberOfLines={2} style={[styles.storyTitle, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.storyLink, { color: colors.primary }]}>Read more  ›</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  homeContent: { paddingHorizontal: 13, gap: 14, paddingBottom: 18 },
  homeHeader: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  menuButton: { width: 31, alignItems: 'flex-start', justifyContent: 'center' },
  greeting: { flex: 1, gap: 1 },
  greetingSmall: { fontSize: 10, fontWeight: '600' },
  greetingName: { fontSize: 14, fontWeight: '800' },
  promoHero: {
    height: 126,
    borderRadius: 15,
    overflow: 'hidden',
    justifyContent: 'flex-end',
  },
  promoImage: { borderRadius: 15 },
  promoShade: { position: 'absolute', top: 0, right: 0, bottom: 0, left: 0, opacity: 0.82 },
  promoCopy: { gap: 4, paddingHorizontal: 13, paddingBottom: 12, width: '78%' },
  promoEyebrow: { fontSize: 8, fontWeight: '800', letterSpacing: 0.8 },
  promoTitle: { fontSize: 19, lineHeight: 22, fontWeight: '800' },
  promoButton: {
    alignSelf: 'flex-start',
    borderRadius: 15,
    minHeight: 28,
    paddingHorizontal: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    marginTop: 3,
  },
  promoButtonText: { fontSize: 10, fontWeight: '800' },
  policyPanel: { padding: 13, gap: 10, borderRadius: 17 },
  policyPanelTop: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  policyIcon: { width: 40, height: 40, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: 'transparent' },
  policyPanelCopy: { flex: 1, gap: 3 },
  policyPanelTitle: { fontSize: 17, fontWeight: '800' },
  policyPanelDetail: { fontSize: 10 },
  policyCount: { fontSize: 10, fontWeight: '800' },
  policyActions: { flexDirection: 'row', gap: 9 },
  policyAction: {
    flex: 1,
    minHeight: 36,
    borderRadius: 18,
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
  },
  policyActionText: { fontSize: 11, fontWeight: '800' },
  section: { gap: 7 },
  buyGrid: { flexDirection: 'row', justifyContent: 'space-between', gap: 7 },
  categoryItem: {
    flex: 1,
    minHeight: 75,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    padding: 5,
    borderRadius: 13,
    backgroundColor: 'transparent',
  },
  categoryIcon: {
    width: 42,
    height: 42,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoryLabel: { fontSize: 10, textAlign: 'center', fontWeight: '700', lineHeight: 13 },
  moreGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    paddingVertical: 8,
    paddingHorizontal: 4,
    gap: 2,
  },
  compactCategory: { flexBasis: '30%', minHeight: 76 },
  compactCategoryIcon: { width: 39, height: 39, borderRadius: 14 },
  quickGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  quickLink: {
    width: '48%',
    minHeight: 44,
    borderRadius: 13,
    paddingHorizontal: 10,
    paddingVertical: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
  },
  quickLabel: { flex: 1, fontSize: 10, fontWeight: '700', lineHeight: 13 },
  horizontalCards: { gap: 9, paddingRight: 8 },
  planCard: {
    width: 165,
    minHeight: 146,
    borderRadius: 15,
    padding: 11,
    borderWidth: StyleSheet.hairlineWidth,
    gap: 5,
    shadowOpacity: 0.05,
    shadowRadius: 7,
    shadowOffset: { width: 0, height: 3 },
    elevation: 2,
  },
  planIcon: { width: 36, height: 36, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  planTitle: { fontSize: 12, fontWeight: '800' },
  planDescription: { fontSize: 10, lineHeight: 14 },
  planLink: { fontSize: 10, fontWeight: '800', marginTop: 1 },
  trustCard: { padding: 13, gap: 12 },
  trustHeading: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  trustTitle: { flex: 1, fontSize: 13, fontWeight: '800' },
  trustStats: { flexDirection: 'row', justifyContent: 'space-between', gap: 7 },
  trustStat: { flex: 1, alignItems: 'center', gap: 5 },
  trustStatLabel: { fontSize: 9, lineHeight: 12, textAlign: 'center' },
  testimonial: { gap: 7, padding: 14 },
  stars: { flexDirection: 'row', gap: 2 },
  quote: { fontSize: 13, lineHeight: 19, fontWeight: '500' },
  quoteBy: { fontSize: 10, fontWeight: '600' },
  storyCard: {
    width: 155,
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
    padding: 8,
    gap: 5,
    overflow: 'hidden',
  },
  storyImage: { width: '100%', height: 84, borderRadius: 9, resizeMode: 'cover' },
  storyCategory: { fontSize: 8, fontWeight: '800', letterSpacing: 0.6 },
  storyTitle: { minHeight: 34, fontSize: 11, lineHeight: 15, fontWeight: '700' },
  storyLink: { fontSize: 9, fontWeight: '800' },
  webinarCard: { height: 122, borderRadius: 15, overflow: 'hidden', justifyContent: 'flex-end' },
  webinarImage: { borderRadius: 15 },
  playButton: {
    position: 'absolute',
    right: 12,
    top: 12,
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: 'center',
    justifyContent: 'center',
  },
  webinarTextBlock: { padding: 10 },
  webinarEyebrow: { fontSize: 8, fontWeight: '800', letterSpacing: 0.8 },
  webinarTitle: { fontSize: 13, lineHeight: 17, fontWeight: '800' },
  demoNote: { fontSize: 9, lineHeight: 14, textAlign: 'center', paddingHorizontal: 10 },
  drawerOverlay: { flex: 1, flexDirection: 'row' },
  drawer: { width: '84%', maxWidth: 355, height: '100%', paddingHorizontal: 12, gap: 10 },
  drawerProfile: { minHeight: 72, borderRadius: 17, borderWidth: 1, padding: 10, alignItems: 'center', flexDirection: 'row', gap: 10 },
  drawerProfileCopy: { flex: 1, gap: 3 },
  drawerName: { fontSize: 14, fontWeight: '800' },
  drawerEmail: { fontSize: 10 },
  drawerScroll: { flex: 1 },
  drawerScrollContent: { gap: 10, paddingBottom: 4 },
  drawerGroup: { borderRadius: 16, paddingHorizontal: 12, paddingTop: 11, paddingBottom: 4, shadowOpacity: 0.04, shadowRadius: 8, shadowOffset: { width: 0, height: 3 } },
  drawerGroupTitle: { fontSize: 13, fontWeight: '800', marginBottom: 2 },
  drawerItem: { minHeight: 39, flexDirection: 'row', alignItems: 'center', gap: 10 },
  drawerItemText: { flex: 1, fontSize: 13, fontWeight: '600' },
  drawerActions: { gap: 7 },
  version: { textAlign: 'center', fontSize: 10, letterSpacing: 1.1, paddingTop: 2 },
  pressed: { opacity: 0.76, transform: [{ scale: 0.99 }] },
});
