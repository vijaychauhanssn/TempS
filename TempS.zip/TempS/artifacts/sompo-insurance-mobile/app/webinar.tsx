import React from 'react';
import { Alert, Image, Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppHeader, AppPage, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

const eventDetails = [
  { label: 'Start', value: '05 Nov 2026 · 06:00 PM', icon: 'calendar-outline' as const },
  { label: 'End', value: '05 Nov 2026 · 07:00 PM', icon: 'time-outline' as const },
  { label: 'Host Name', value: 'Dr. Meera Kapoor', icon: 'person-outline' as const },
  { label: 'Meeting ID', value: '248 4440 3432', icon: 'videocam-outline' as const },
  { label: 'Password', value: 'wellness2026', icon: 'key-outline' as const },
];

export default function WebinarScreen() {
  const colors = useColors();
  const join = () => {
    Alert.alert(
      'Webinar link unavailable',
      'This sample event is for preview only. The live webinar service is not connected.',
    );
  };

  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="Health Webinar" onBack={() => router.back()} />
      <Image
        source={require('../assets/images/webinar-banner.png')}
        style={styles.banner}
        resizeMode="cover"
        accessibilityLabel="Lifestyle habits for stress resilience webinar"
      />
      <View style={styles.eventMeta}>
        <MetaChip icon="calendar-outline" label="05 Nov 2026" />
        <MetaChip icon="time-outline" label="06:00 PM – 07:00 PM" />
        <MetaChip icon="globe-outline" label="Join Online" />
        <MetaChip icon="people-outline" label="Open to all" />
      </View>
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Start</Text>
      <SurfaceCard style={styles.detailsCard}>
        {eventDetails.map((item) => (
          <View key={item.label} style={[styles.detailRow, { borderBottomColor: colors.border }]}>
            <Text style={[styles.detailLabel, { color: colors.foreground }]}>{item.label}</Text>
            <Text style={[styles.detailValue, { color: colors.mutedForeground }]}>{item.value}</Text>
          </View>
        ))}
      </SurfaceCard>

      <View style={[styles.howTo, { backgroundColor: colors.primaryWash }]}>
        <View style={styles.howToCopy}>
          <Text style={[styles.howToTitle, { color: colors.foreground }]}>How to attend?</Text>
          <Text style={[styles.howToBody, { color: colors.mutedForeground }]}>
            Join from your phone or computer a few minutes before the session.
          </Text>
          <View style={styles.storeLinks}>
            <Pressable onPress={() => void Linking.openURL('https://zoom.us/download').catch(() => undefined)} style={[styles.storeButton, { backgroundColor: colors.foreground }]}>
              <Ionicons name="videocam-outline" size={15} color={colors.white} />
              <Text style={[styles.storeText, { color: colors.white }]}>Meeting app</Text>
            </Pressable>
            <Pressable onPress={join} style={[styles.storeButton, { backgroundColor: colors.primary }]}>
              <Ionicons name="open-outline" size={15} color={colors.white} />
              <Text style={[styles.storeText, { color: colors.white }]}>Event details</Text>
            </Pressable>
          </View>
        </View>
      </View>

      <View style={styles.about}>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>About this Webinar:</Text>
        <Text style={[styles.aboutText, { color: colors.mutedForeground }]}>
          Learn practical ways to build stress resilience through everyday routines, sleep, movement and mindfulness. The session shares general wellness guidance from a health professional.
        </Text>
        <Pressable onPress={() => Alert.alert('About this session', 'This is an illustrative event description. No webinar stream is connected.')}>
          <Text style={[styles.readMore, { color: colors.primary }]}>Read more ›</Text>
        </Pressable>
      </View>
      <PrimaryButton label="Join Webinar" icon="videocam-outline" onPress={join} />
      <Text style={[styles.note, { color: colors.mutedForeground }]}>
        Event details are sample content. Joining or registering will not create an account.
      </Text>
    </AppPage>
  );
}

function MetaChip({ icon, label }: { icon: keyof typeof Ionicons.glyphMap; label: string }) {
  const colors = useColors();
  return (
    <View style={[styles.metaChip, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Ionicons name={icon} size={14} color={colors.primary} />
      <Text style={[styles.metaText, { color: colors.foreground }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 13, gap: 10 },
  banner: { width: '100%', height: 143, borderRadius: 13 },
  eventMeta: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 6 },
  metaChip: { width: '48%', minHeight: 36, borderWidth: 1, borderRadius: 10, paddingHorizontal: 7, flexDirection: 'row', alignItems: 'center', gap: 5 },
  metaText: { flex: 1, fontSize: 9, fontWeight: '700' },
  sectionTitle: { fontSize: 13, fontWeight: '800' },
  detailsCard: { padding: 10, gap: 0 },
  detailRow: { minHeight: 29, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8, borderBottomWidth: StyleSheet.hairlineWidth },
  detailLabel: { fontSize: 9, fontWeight: '700' },
  detailValue: { flex: 1, fontSize: 9, textAlign: 'right' },
  howTo: { minHeight: 94, borderRadius: 13, padding: 11, justifyContent: 'center' },
  howToCopy: { gap: 5 },
  howToTitle: { fontSize: 11, fontWeight: '800' },
  howToBody: { fontSize: 9, lineHeight: 13 },
  storeLinks: { flexDirection: 'row', gap: 7, marginTop: 2 },
  storeButton: { minHeight: 29, borderRadius: 8, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', gap: 5 },
  storeText: { fontSize: 9, fontWeight: '700' },
  about: { gap: 6 },
  aboutText: { fontSize: 10, lineHeight: 15 },
  readMore: { fontSize: 10, fontWeight: '800', textAlign: 'right' },
  note: { fontSize: 9, lineHeight: 14, textAlign: 'center' },
});
