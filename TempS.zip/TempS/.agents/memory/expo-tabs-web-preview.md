---
name: Expo tabs in web previews
description: A Replit Expo web-preview quirk when choosing between native liquid-glass tabs and the standard tab navigator.
---

Use the standard Expo Router tab navigator on web, and choose native liquid-glass tabs only on supported native platforms. In this project environment, relying only on `isLiquidGlassAvailable()` caused tab routes to render blank in the web preview without a useful browser error.

**Why:** The home route appeared blank even though the app shell rendered and logs had no runtime exception. Explicitly checking the platform restored the web tab content.

**How to apply:** When changing Expo tab navigation, keep the web fallback explicit and verify a nested tab route in the browser preview.
