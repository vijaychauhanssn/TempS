import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { AppHeader, AppPage, OutlineButton, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

export default function InsuranceDetailScreen() {
  const colors = useColors();
  const { type } = useLocalSearchParams<{ type?: string }>();
  const title = type || 'Insurance';
  const isHealth = title.toLowerCase().includes('health');
  const icon = isHealth ? 'heart-outline' : title.toLowerCase().includes('travel') ? 'airplane-outline' : 'shield-checkmark-outline';

  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="Explore Insurance" onBack={() => router.back()} />
      <View style={[styles.hero, { backgroundColor: colors.primaryPale }]}>
        <View style={[styles.heroIcon, { backgroundColor: colors.white }]}>
          <Ionicons name={icon} size={30} color={colors.primary} />
        </View>
        <Text style={[styles.title, { color: colors.foreground }]}>{title}</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Explore the cover options and resources available for this category.
        </Text>
      </View>
      <SurfaceCard style={styles.detailCard}>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          What you can do
        </Text>
        {[
          'Review the type of cover that may suit your needs.',
          'Keep related documents and details together.',
          'Contact support for product-specific information.',
        ].map((line) => (
          <View key={line} style={styles.bulletRow}>
            <Ionicons name="checkmark-circle" size={18} color={colors.primary} />
            <Text style={[styles.bulletText, { color: colors.mutedForeground }]}>
              {line}
            </Text>
          </View>
        ))}
        <PrimaryButton
          label="Contact Us"
          icon="arrow-forward"
          onPress={() => router.push('/contact')}
        />
        <OutlineButton
          label="View resources"
          icon="book-outline"
          onPress={() => router.push('/resources')}
        />
      </SurfaceCard>
      <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
        Product details, eligibility and pricing are not available in this demo.
      </Text>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 16, gap: 16 },
  hero: { alignItems: 'center', gap: 9, padding: 23, borderRadius: 22 },
  heroIcon: { width: 62, height: 62, borderRadius: 23, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 22, fontWeight: '800', textAlign: 'center' },
  subtitle: { fontSize: 12, lineHeight: 17, textAlign: 'center' },
  detailCard: { gap: 14 },
  sectionTitle: { fontSize: 16, fontWeight: '800' },
  bulletRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 9 },
  bulletText: { flex: 1, fontSize: 12, lineHeight: 18 },
  disclaimer: { textAlign: 'center', fontSize: 10, lineHeight: 15, paddingHorizontal: 9 },
});
