import React from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useColors } from '@/hooks/useColors';
import { AppPage, BrandLogo, OutlineButton, PrimaryButton } from '@/components/AppUI';

export default function WelcomeScreen() {
  const colors = useColors();
  return (
    <LinearGradient
      colors={[colors.screen, colors.primaryPale, colors.primaryWash]}
      style={styles.flex}
    >
      <AppPage
        backgroundColor="transparent"
        contentStyle={styles.pageContent}
      >
        <BrandLogo width={330} />
        <View style={styles.welcomeLine}>
          <Text style={[styles.welcomeText, { color: colors.foreground }]}>
            Welcome to{' '}
          </Text>
          <Text style={[styles.brandText, { color: colors.primary }]}>
            Universal Sompo
          </Text>
        </View>
        <View
          style={[
            styles.authPanel,
            {
              backgroundColor: colors.white,
              borderColor: colors.border,
              shadowColor: colors.shadow,
            },
          ]}
        >
          <PrimaryButton
            label="Login"
            icon="chevron-forward"
            onPress={() => router.push('/login')}
            testID="welcome-login"
          />
          <OutlineButton
            label="Register"
            onPress={() => router.push('/register')}
            testID="welcome-register"
          />
          <View style={styles.orRow}>
            <View style={[styles.orLine, { backgroundColor: colors.primaryPale }]} />
            <Text style={[styles.orText, { color: colors.mutedForeground }]}>OR</Text>
            <View style={[styles.orLine, { backgroundColor: colors.primaryPale }]} />
          </View>
          <Pressable
            onPress={() =>
              Alert.alert(
                'Google sign-in unavailable',
                'This demo does not have a connected authentication provider. Use Login or Register to continue.',
              )
            }
            accessibilityRole="button"
            style={({ pressed }) => [styles.googleButton, pressed && styles.pressed]}
          >
            <Ionicons name="logo-google" size={21} color={colors.primary} />
            <Text style={[styles.googleText, { color: colors.foreground }]}>
              Continue with Google
            </Text>
          </Pressable>
          <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
            Demo experience · your details stay on this device
          </Text>
        </View>
      </AppPage>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  pageContent: {
    flexGrow: 1,
    justifyContent: 'space-between',
    paddingTop: 18,
    paddingBottom: 0,
    paddingHorizontal: 0,
  },
  welcomeLine: {
    paddingHorizontal: 8,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    alignItems: 'center',
  },
  welcomeText: { fontSize: 21, fontWeight: '600' },
  brandText: { fontSize: 21, fontWeight: '800' },
  authPanel: {
    paddingHorizontal: 24,
    paddingTop: 34,
    paddingBottom: 30,
    borderTopLeftRadius: 34,
    borderTopRightRadius: 34,
    borderWidth: StyleSheet.hairlineWidth,
    gap: 16,
    shadowOpacity: 0.08,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: -5 },
  },
  orRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 2 },
  orLine: { flex: 1, height: 2, borderRadius: 1 },
  orText: { fontSize: 12, fontWeight: '700' },
  googleButton: {
    alignSelf: 'center',
    paddingVertical: 4,
    paddingHorizontal: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  googleText: { fontSize: 14, fontWeight: '600' },
  disclaimer: { textAlign: 'center', fontSize: 11, marginTop: 2 },
  pressed: { opacity: 0.72 },
});
