# Setup and API configuration

## Run locally in Replit

The Expo workflow is configured for this artifact and starts the app with:

```sh
pnpm --filter @workspace/sompo-insurance-mobile run dev
```

Type-check the app with:

```sh
pnpm --filter @workspace/sompo-insurance-mobile run typecheck
```

## Demo mode

The app defaults to device-local demo mode. Existing policy and profile flows use the supplied sample records; the home carousel uses bundled artwork and sample destinations. The location pickers and provider directory are sample lists, not a complete postal master or a live network-provider search.

The following optional `EXPO_PUBLIC_HOME_DEMO_STATE` values help exercise the carousel states:

- unset: show the bundled banner list
- `loading`: hold the initial loading state briefly
- `error`: show the retry state
- `empty`: show the empty state

## API mode

The current API artifact only exposes `GET /api/healthz`; it does not provide insurer product, claims, renewal, directory, or home-banner routes. Do not set live mode until the approved service contract and deployment are available.

The existing API client reads:

- `EXPO_PUBLIC_API_BASE_URL` — API server origin
- `EXPO_PUBLIC_HOME_API_PATH` — an approved home-content path beginning with `/`

When a home path is configured, the carousel loads its response from that API. Image URLs must use HTTPS. Banner destinations are resolved through the app’s explicit route allowlist; unknown values do not open arbitrary routes.

Authentication remains device-demo mode unless the app’s approved authentication service is configured. Never place API keys, credentials, or private tokens in `EXPO_PUBLIC_*` variables or source code.

## Functional boundaries

- A selected document image is kept only as a local attachment label; there is no upload endpoint.
- Claim and renewal confirmation screens create demo references only; they do not submit a request.
- The sample location and hospital lists do not establish real eligibility, availability, distance, or provider affiliation.
- The emergency number action opens the device dialer; it does not dispatch an ambulance.
