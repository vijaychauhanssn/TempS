import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { AppHeader, AppPage, LabeledInput, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

const SAMPLE_REGISTRATION = 'UP14MH1888';

export default function PollutionCertificateScreen() {
  const colors = useColors();
  const { vehicleNumber: initialNumber = '' } = useLocalSearchParams<{ vehicleNumber?: string }>();
  const [vehicleNumber, setVehicleNumber] = useState(initialNumber.toUpperCase());
  const [checkedNumber, setCheckedNumber] = useState('');
  const [error, setError] = useState('');

  const checkCertificate = () => {
    const normalized = vehicleNumber.toUpperCase().replace(/[\s-]/g, '');
    if (!/^[A-Z]{2}\d{1,2}[A-Z]{0,3}\d{1,4}$/.test(normalized)) {
      setError('Enter a valid vehicle registration number.');
      return;
    }
    setError('');
    setCheckedNumber(normalized);
  };

  const hasSampleRecord = checkedNumber === SAMPLE_REGISTRATION;

  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="Pollution Certificate" onBack={() => router.back()} />
      <View style={[styles.hero, { backgroundColor: colors.primaryWash }]}>
        <View style={[styles.heroIcon, { backgroundColor: colors.white }]}>
          <Ionicons name="leaf-outline" size={26} color={colors.success} />
        </View>
        <View style={styles.heroCopy}>
          <Text style={[styles.title, { color: colors.foreground }]}>Check PUC Certificate</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Check your vehicle’s certificate details.</Text>
        </View>
      </View>
      <LabeledInput
        label="Vehicle Number"
        value={vehicleNumber}
        onChangeText={(value) => setVehicleNumber(value.toUpperCase())}
        placeholder="Enter vehicle number"
        autoCapitalize="characters"
      />
      {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
      <PrimaryButton label="Check Status" icon="search-outline" onPress={checkCertificate} />

      {checkedNumber ? (
        hasSampleRecord ? (
          <SurfaceCard style={styles.resultCard}>
            <View style={[styles.statusIcon, { backgroundColor: colors.primaryWash }]}>
              <Ionicons name="checkmark-circle" size={27} color={colors.success} />
            </View>
            <Text style={[styles.resultTitle, { color: colors.foreground }]}>Certificate is valid</Text>
            <Text style={[styles.vehicle, { color: colors.mutedForeground }]}>{checkedNumber}</Text>
            <View style={[styles.detailRow, { borderTopColor: colors.border }]}>
              <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>Valid through</Text>
              <Text style={[styles.detailValue, { color: colors.foreground }]}>26 Nov 2026</Text>
            </View>
            <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>Sample certificate record only.</Text>
          </SurfaceCard>
        ) : (
          <SurfaceCard style={styles.emptyCard}>
            <Ionicons name="document-text-outline" size={26} color={colors.mutedForeground} />
            <Text style={[styles.resultTitle, { color: colors.foreground }]}>No local certificate record</Text>
            <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
              Live PUC records are not available in this demo. Find a nearby testing centre instead.
            </Text>
          </SurfaceCard>
        )
      ) : null}

      <Pressable
        onPress={() => router.push({ pathname: '/find-hospitals', params: { category: 'Pollution Centers' } })}
        style={[styles.nearby, { borderColor: colors.border }]}
      >
        <Ionicons name="location-outline" size={19} color={colors.primary} />
        <Text style={[styles.nearbyText, { color: colors.foreground }]}>Find a nearby PUC centre</Text>
        <Ionicons name="chevron-forward" size={15} color={colors.mutedForeground} />
      </Pressable>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 14, gap: 13 },
  hero: { minHeight: 83, borderRadius: 15, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 10 },
  heroIcon: { width: 44, height: 44, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  heroCopy: { flex: 1, gap: 4 },
  title: { fontSize: 15, fontWeight: '800' },
  subtitle: { fontSize: 10, lineHeight: 14 },
  error: { fontSize: 10 },
  resultCard: { alignItems: 'center', padding: 15, gap: 8 },
  statusIcon: { width: 48, height: 48, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  resultTitle: { fontSize: 13, fontWeight: '800', textAlign: 'center' },
  vehicle: { fontSize: 10, fontWeight: '700' },
  detailRow: { width: '100%', borderTopWidth: StyleSheet.hairlineWidth, marginTop: 3, paddingTop: 9, flexDirection: 'row', justifyContent: 'space-between' },
  detailLabel: { fontSize: 10 },
  detailValue: { fontSize: 10, fontWeight: '800' },
  disclaimer: { fontSize: 9, lineHeight: 14, textAlign: 'center' },
  emptyCard: { alignItems: 'center', gap: 8, padding: 17 },
  nearby: { minHeight: 48, borderWidth: 1, borderRadius: 13, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', gap: 8 },
  nearbyText: { flex: 1, fontSize: 10, fontWeight: '700' },
});
