import React, { useState } from 'react';
import {
  Image,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  AppHeader,
  LabeledInput,
  PrimaryButton,
  SurfaceCard,
} from '@/components/AppUI';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';
import { saveDemoHealthClaim } from '@/src/services/claimService';

const healthPolicies = ['USGI/HLT/2025/0021', 'USGI/HLT/2026/0007'];
const motorPolicies = ['USGI/MTR/2025/0042', 'USGI/MTR/2026/0008'];
const states = ['Delhi', 'Karnataka', 'Maharashtra', 'Uttar Pradesh', 'West Bengal'];
const citiesByState: Record<string, string[]> = {
  Delhi: ['New Delhi', 'Dwarka'],
  Karnataka: ['Bengaluru', 'Mysuru'],
  Maharashtra: ['Mumbai', 'Pune'],
  'Uttar Pradesh': ['Ghaziabad', 'Noida'],
  'West Bengal': ['Kolkata', 'Howrah'],
};
const hospitals = ['Supreme Healthcare', 'City Care Hospital', 'Metro General Hospital'];
const healthClaimTypes = ['Cashless', 'Reimbursement'];
const motorClaimTypes = ['Accident', 'Theft', 'Fire', 'Natural Disaster'];
const treatmentTypes = ['Hospitalization', 'Day Care', 'Emergency'];
const citiesFallback = ['Other'];

type ClaimDocument = {
  uri: string;
  name: string;
};

function isValidDate(value: string): boolean {
  const match = value.trim().match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (!match) return false;
  const day = Number(match[1]);
  const month = Number(match[2]) - 1;
  const year = Number(match[3]);
  const date = new Date(year, month, day);
  return date.getFullYear() === year && date.getMonth() === month && date.getDate() === day;
}

function ClaimSelectField({
  label,
  value,
  options,
  onChange,
  placeholder = 'Select',
  disabled = false,
  testID,
}: {
  label: string;
  value: string;
  options: readonly string[];
  onChange: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
  testID: string;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [visible, setVisible] = useState(false);

  const close = () => setVisible(false);

  return (
    <>
      <View style={styles.fieldGroup}>
        <Text style={[styles.fieldLabel, { color: colors.foreground }]}>{label} *</Text>
        <Pressable
          testID={testID}
          accessibilityRole="button"
          accessibilityLabel={`${label}: ${value || placeholder}`}
          accessibilityState={{ disabled, expanded: visible }}
          disabled={disabled}
          onPress={() => setVisible(true)}
          style={({ pressed }) => [
            styles.selectButton,
            {
              backgroundColor: colors.card,
              borderColor: colors.borderStrong,
              opacity: disabled ? 0.55 : 1,
            },
            pressed && !disabled && styles.pressed,
          ]}
        >
          <Text
            numberOfLines={1}
            style={[styles.selectText, { color: value ? colors.foreground : colors.placeholder }]}
          >
            {value || placeholder}
          </Text>
          <Ionicons name="chevron-down" size={17} color={colors.foreground} />
        </Pressable>
      </View>
      <Modal
        transparent
        visible={visible}
        animationType="slide"
        onRequestClose={close}
      >
        <View style={[styles.modalBackdrop, { backgroundColor: colors.scrim }]}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={`Close ${label} options`}
            onPress={close}
            style={StyleSheet.absoluteFill}
          />
          <View
            style={[
              styles.optionSheet,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
                paddingBottom: Math.max(insets.bottom, Platform.OS === 'web' ? 34 : 16),
              },
            ]}
          >
            <View style={styles.sheetHeader}>
              <Text style={[styles.sheetTitle, { color: colors.foreground }]}>{label}</Text>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`Close ${label} options`}
                onPress={close}
                hitSlop={10}
              >
                <Ionicons name="close" size={22} color={colors.mutedForeground} />
              </Pressable>
            </View>
            <ScrollView
              style={styles.optionList}
              keyboardShouldPersistTaps="handled"
              showsVerticalScrollIndicator={false}
            >
              {options.map((option, index) => (
                <Pressable
                  key={option}
                  testID={`${testID}-option-${index}`}
                  accessibilityRole="button"
                  accessibilityState={{ selected: option === value }}
                  onPress={() => {
                    onChange(option);
                    close();
                  }}
                  style={[styles.optionRow, { borderBottomColor: colors.border }]}
                >
                  <Text style={[styles.optionText, { color: colors.foreground }]}>{option}</Text>
                  {option === value ? (
                    <Ionicons name="checkmark" size={18} color={colors.primary} />
                  ) : null}
                </Pressable>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </>
  );
}

export default function ClaimIntimationScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { profile } = useAppState();
  const { claimType = 'Health' } = useLocalSearchParams<{ claimType?: string }>();
  const isMotor = claimType.toLowerCase().includes('motor');
  const claimLabel = isMotor ? 'Motor' : 'Health';
  const policyOptions = isMotor ? motorPolicies : healthPolicies;
  const claimTypeOptions = isMotor ? motorClaimTypes : healthClaimTypes;
  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;
  const [step, setStep] = useState(1);
  const [policyNumber, setPolicyNumber] = useState('');
  const [insuredName, setInsuredName] = useState(profile.fullName);
  const [registrationNumber, setRegistrationNumber] = useState('');
  const [engineNumber, setEngineNumber] = useState('');
  const [chassisNumber, setChassisNumber] = useState('');
  const [stateName, setStateName] = useState('');
  const [city, setCity] = useState('');
  const [hospital, setHospital] = useState('');
  const [pincode, setPincode] = useState('');
  const [selectedClaimType, setSelectedClaimType] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [diagnosis, setDiagnosis] = useState('');
  const [treatmentType, setTreatmentType] = useState('');
  const [incidentDescription, setIncidentDescription] = useState('');
  const [mobile, setMobile] = useState(profile.mobile);
  const [email, setEmail] = useState(profile.email);
  const [estimatedCost, setEstimatedCost] = useState('');
  const [documents, setDocuments] = useState<ClaimDocument[]>([]);
  const [error, setError] = useState('');
  const [reference, setReference] = useState('');
  const [permissionBlocked, setPermissionBlocked] = useState(false);
  const [mediaPermission, requestMediaPermission] = ImagePicker.useMediaLibraryPermissions();
  const cityOptions = stateName ? citiesByState[stateName] ?? citiesFallback : [];

  const continueToDetails = () => {
    setError('');
    if (!policyOptions.includes(policyNumber)) {
      setError('Select a policy number from the demo list.');
      return;
    }
    setStep(2);
  };

  const selectDocuments = async () => {
    try {
      let permission = mediaPermission;
      if (!permission?.granted) permission = await requestMediaPermission();
      if (!permission.granted) {
        setPermissionBlocked(!permission.canAskAgain);
        setError('Allow photo access to attach document images to this demo form.');
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsMultipleSelection: true,
        selectionLimit: 5,
        quality: 0.85,
      });
      if (result.canceled) return;
      setDocuments((current) => [
        ...current,
        ...result.assets.map((asset, index) => ({
          uri: asset.uri,
          name: asset.fileName || `Claim document ${current.length + index + 1}`,
        })),
      ].slice(0, 5));
      setError('');
    } catch {
      setError('Could not open the photo library. Please try again.');
    }
  };

  const openSettings = async () => {
    try {
      await Linking.openSettings();
    } catch {
      setError('Open your device settings to allow photo access.');
    }
  };

  const submitClaim = async () => {
    const hasValidContact =
      mobile.replace(/\D/g, '').length >= 10 && /^\S+@\S+\.\S+$/.test(email.trim());
    const hasValidCost = Number(estimatedCost.replace(/[,\s]/g, '')) > 0;
    const commonDetailsValid =
      Boolean(insuredName.trim())
      && Boolean(stateName)
      && Boolean(city)
      && Boolean(pincode.trim())
      && Boolean(selectedClaimType)
      && isValidDate(eventDate)
      && hasValidContact
      && hasValidCost;
    const claimDetailsValid = isMotor
      ? Boolean(registrationNumber.trim() && engineNumber.trim() && chassisNumber.trim() && incidentDescription.trim())
      : Boolean(hospital && diagnosis.trim() && treatmentType);

    if (!commonDetailsValid || !claimDetailsValid) {
      setError('Complete the required claim, contact, and amount details before continuing.');
      return;
    }

    setError('');
    try {
      if (isMotor) {
        setReference(`DEMO-${Date.now().toString().slice(-6)}`);
      } else {
        const saved = await saveDemoHealthClaim({
          member: insuredName.trim(),
          policyNumber,
          hospital,
          incidentDate: eventDate,
        });
        setReference(saved.reference);
      }
    } catch {
      setError('Could not save this demo claim on the device. Please try again.');
    }
  };

  const callSupport = async () => {
    try {
      await Linking.openURL('tel:1800224030');
    } catch {
      setError('Call Universal Sompo support at 1800 22 4030.');
    }
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.page, { backgroundColor: colors.screen }]}
      contentContainerStyle={[
        styles.content,
        { paddingTop: topInset + 8, paddingBottom: bottomInset + 24 },
      ]}
      bottomOffset={70}
      keyboardShouldPersistTaps="handled"
    >
      <AppHeader
        title={`${claimLabel} Claim Intimation`}
        onBack={() => (step === 2 ? setStep(1) : router.back())}
      />

      {reference ? (
        <SurfaceCard style={styles.successCard}>
          <View style={[styles.successIcon, { backgroundColor: colors.primaryWash }]}>
            <Ionicons name="checkmark" size={28} color={colors.success} />
          </View>
          <Text style={[styles.successTitle, { color: colors.foreground }]}>Claim intimation saved</Text>
          <Text style={[styles.body, { color: colors.mutedForeground }]}>Demo reference: {reference}</Text>
          <Text style={[styles.note, { color: colors.mutedForeground }]}>
            This form was saved only for this demo and was not sent to Universal Sompo.
          </Text>
          <PrimaryButton label="Back to claims" onPress={() => router.replace('/claims')} />
        </SurfaceCard>
      ) : step === 1 ? (
        <>
          <Image
            source={isMotor
              ? require('../assets/images/motor-hero.png')
              : require('../assets/images/health-family.png')}
            resizeMode="contain"
            style={styles.heroImage}
            accessibilityLabel={`${claimLabel} claim illustration`}
          />
          <Text style={[styles.heroTitle, { color: colors.foreground }]}>
            Let&apos;s get your claim intimation started
          </Text>
          <Text style={[styles.body, { color: colors.mutedForeground }]}>
            Choose the policy you want to use. The policy numbers are sample data.
          </Text>
          <ClaimSelectField
            label="Policy Number"
            value={policyNumber}
            options={policyOptions}
            onChange={(value) => {
              setPolicyNumber(value);
              setError('');
            }}
            placeholder="Select policy number"
            testID="claim-policy-dropdown"
          />
          {error ? <Text accessibilityRole="alert" style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
          <View style={styles.footer}>
            <PrimaryButton label="Submit" icon="chevron-forward" onPress={continueToDetails} />
            <Text style={[styles.orLabel, { color: colors.mutedForeground }]}>or</Text>
            <Pressable onPress={() => void callSupport()} accessibilityRole="button">
              <Text style={[styles.supportLink, { color: colors.primary }]}>Call 1800 22 4030</Text>
            </Pressable>
          </View>
        </>
      ) : (
        <>
          <SurfaceCard style={[styles.policySummary, { backgroundColor: colors.card }]}>
            <View style={[styles.summaryIcon, { backgroundColor: colors.primaryWash }]}>
              <Ionicons name={isMotor ? 'car-sport' : 'medical'} size={20} color={colors.primary} />
            </View>
            <View style={styles.summaryCopy}>
              <Text style={[styles.summaryTitle, { color: colors.primary }]}>
                {isMotor ? 'Motor Policy' : 'Supreme Healthcare'}
              </Text>
              <Text style={[styles.summaryMeta, { color: colors.foreground }]}>Policy No. {policyNumber}</Text>
              <Text style={[styles.summaryMeta, { color: colors.mutedForeground }]}>Policy expiry shown for demo</Text>
            </View>
          </SurfaceCard>

          <Text style={[styles.sectionTitle, { color: colors.primary }]}>
            {isMotor ? 'Vehicle & Incident Details' : 'Hospitalization Details'}
          </Text>
          <LabeledInput
            label="Insured Name *"
            value={insuredName}
            onChangeText={setInsuredName}
            placeholder="Enter insured name"
          />

          {isMotor ? (
            <>
              <LabeledInput label="Registration Number *" value={registrationNumber} onChangeText={setRegistrationNumber} placeholder="Enter vehicle registration" autoCapitalize="characters" />
              <LabeledInput label="Engine Number *" value={engineNumber} onChangeText={setEngineNumber} placeholder="Enter engine number" autoCapitalize="characters" />
              <LabeledInput label="Chassis Number *" value={chassisNumber} onChangeText={setChassisNumber} placeholder="Enter chassis number" autoCapitalize="characters" />
            </>
          ) : null}

          <View style={styles.twoColumns}>
            <View style={styles.column}>
              <ClaimSelectField
                label="State"
                value={stateName}
                options={states}
                onChange={(value) => {
                  setStateName(value);
                  setCity('');
                }}
                placeholder="Select state"
                testID="claim-state-dropdown"
              />
            </View>
            <View style={styles.column}>
              <ClaimSelectField
                label="City"
                value={city}
                options={cityOptions}
                onChange={setCity}
                placeholder={stateName ? 'Select city' : 'Select state first'}
                disabled={!stateName}
                testID="claim-city-dropdown"
              />
            </View>
          </View>
          {!isMotor ? (
            <ClaimSelectField
              label="Hospital Name"
              value={hospital}
              options={hospitals}
              onChange={setHospital}
              placeholder="Select hospital"
              testID="claim-hospital-dropdown"
            />
          ) : null}
          <LabeledInput
            label="Pincode *"
            value={pincode}
            onChangeText={(value) => setPincode(value.replace(/\D/g, '').slice(0, 6))}
            placeholder="Enter pincode"
            keyboardType="number-pad"
            maxLength={6}
          />
          <ClaimSelectField
            label="Claim Type"
            value={selectedClaimType}
            options={claimTypeOptions}
            onChange={setSelectedClaimType}
            placeholder="Select claim type"
            testID="claim-type-dropdown"
          />
          <LabeledInput
            label={isMotor ? 'Incident Date *' : 'Date of Hospitalization *'}
            value={eventDate}
            onChangeText={(value) => setEventDate(value.replace(/[^\d/]/g, '').slice(0, 10))}
            placeholder="DD/MM/YYYY"
            keyboardType="numbers-and-punctuation"
            maxLength={10}
          />
          {isMotor ? (
            <LabeledInput
              label="Incident Details *"
              value={incidentDescription}
              onChangeText={setIncidentDescription}
              placeholder="Describe the accident or incident"
              multiline
              style={styles.multiline}
            />
          ) : (
            <>
              <LabeledInput
                label="Initial Diagnosis *"
                value={diagnosis}
                onChangeText={setDiagnosis}
                placeholder="Enter initial diagnosis"
              />
              <ClaimSelectField
                label="Treatment Type"
                value={treatmentType}
                options={treatmentTypes}
                onChange={setTreatmentType}
                placeholder="Select treatment type"
                testID="claim-treatment-dropdown"
              />
            </>
          )}

          <Text style={[styles.sectionTitle, { color: colors.primary }]}>Contact Information</Text>
          <LabeledInput
            label="Mobile Number *"
            value={mobile}
            onChangeText={setMobile}
            placeholder="Enter mobile number"
            keyboardType="phone-pad"
            maxLength={13}
          />
          <LabeledInput
            label="Email Address *"
            value={email}
            onChangeText={setEmail}
            placeholder="Enter email address"
            keyboardType="email-address"
            autoCapitalize="none"
          />

          <Text style={[styles.sectionTitle, { color: colors.primary }]}>Claim Amount Details</Text>
          <LabeledInput
            label={isMotor ? 'Estimated Repair Cost (₹) *' : 'Estimated Treatment Cost (₹) *'}
            value={estimatedCost}
            onChangeText={(value) => setEstimatedCost(value.replace(/[^\d.,]/g, ''))}
            placeholder="Enter estimated cost"
            keyboardType="decimal-pad"
          />

          <Text style={[styles.sectionTitle, { color: colors.primary }]}>Upload Documents</Text>
          <Text style={[styles.note, { color: colors.mutedForeground }]}>
            Attach photos of relevant documents. Files stay on this device and are not uploaded to the insurer.
          </Text>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Choose document photos"
            testID="claim-add-documents"
            onPress={() => void selectDocuments()}
            style={({ pressed }) => [
              styles.uploadButton,
              { borderColor: colors.border, backgroundColor: colors.card },
              pressed && styles.pressed,
            ]}
          >
            <Ionicons name="cloud-upload-outline" size={19} color={colors.primary} />
            <Text style={[styles.uploadText, { color: colors.primary }]}>
              {documents.length ? 'Add more photos' : 'Choose document photos'}
            </Text>
          </Pressable>
          {documents.map((document, index) => (
            <View key={`${document.uri}-${index}`} style={[styles.documentRow, { borderColor: colors.border }]}>
              <Ionicons name="document-text-outline" size={17} color={colors.primary} />
              <Text numberOfLines={1} style={[styles.documentName, { color: colors.foreground }]}>{document.name}</Text>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`Remove ${document.name}`}
                onPress={() => setDocuments((current) => current.filter((_, itemIndex) => itemIndex !== index))}
                hitSlop={8}
              >
                <Ionicons name="close-circle-outline" size={19} color={colors.mutedForeground} />
              </Pressable>
            </View>
          ))}
          {permissionBlocked && Platform.OS !== 'web' ? (
            <Pressable accessibilityRole="button" onPress={() => void openSettings()}>
              <Text style={[styles.supportLink, { color: colors.primary }]}>Open device settings</Text>
            </Pressable>
          ) : null}

          {error ? <Text accessibilityRole="alert" style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
          <Text style={[styles.note, { color: colors.mutedForeground }]}>
            Demo form only. Completing it does not submit a claim to Universal Sompo.
          </Text>
          <View style={styles.footer}>
            <PrimaryButton label="Continue" icon="chevron-forward" onPress={() => void submitClaim()} />
          </View>
        </>
      )}
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 14, gap: 11 },
  heroImage: { width: '100%', height: 152, borderRadius: 15 },
  heroTitle: { fontSize: 18, lineHeight: 24, fontWeight: '800', textAlign: 'center' },
  body: { fontSize: 11, lineHeight: 16, textAlign: 'center' },
  fieldGroup: { gap: 5 },
  fieldLabel: { fontSize: 11, lineHeight: 15, fontWeight: '700' },
  selectButton: { minHeight: 43, borderWidth: 1, borderRadius: 8, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  selectText: { flex: 1, fontSize: 11 },
  modalBackdrop: { flex: 1, justifyContent: 'flex-end' },
  optionSheet: { maxHeight: '75%', borderTopLeftRadius: 18, borderTopRightRadius: 18, borderWidth: 1, paddingHorizontal: 18, paddingTop: 15, gap: 8 },
  sheetHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 32 },
  sheetTitle: { flex: 1, fontSize: 16, fontWeight: '800' },
  optionList: { flexGrow: 0 },
  optionRow: { minHeight: 48, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  optionText: { fontSize: 13, fontWeight: '600' },
  policySummary: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12 },
  summaryIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  summaryCopy: { flex: 1, gap: 3 },
  summaryTitle: { fontSize: 12, fontWeight: '800' },
  summaryMeta: { fontSize: 9 },
  sectionTitle: { fontSize: 14, fontWeight: '800', marginTop: 4 },
  twoColumns: { flexDirection: 'row', gap: 9 },
  column: { flex: 1 },
  multiline: { minHeight: 82, textAlignVertical: 'top', paddingTop: 12 },
  uploadButton: { minHeight: 48, borderWidth: 1, borderStyle: 'dashed', borderRadius: 10, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8 },
  uploadText: { fontSize: 11, fontWeight: '700' },
  documentRow: { minHeight: 38, borderWidth: 1, borderRadius: 9, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', gap: 8 },
  documentName: { flex: 1, fontSize: 10 },
  note: { fontSize: 9, lineHeight: 14, textAlign: 'center' },
  error: { fontSize: 10, lineHeight: 15, fontWeight: '600' },
  footer: { marginTop: 'auto', paddingTop: 6, alignItems: 'center', gap: 7 },
  orLabel: { fontSize: 10, fontWeight: '600' },
  supportLink: { fontSize: 10, fontWeight: '700', textAlign: 'center' },
  successCard: { flexGrow: 1, alignItems: 'center', justifyContent: 'center', gap: 12, padding: 20 },
  successIcon: { width: 56, height: 56, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  successTitle: { fontSize: 18, fontWeight: '800' },
  pressed: { opacity: 0.78 },
});
