import React, { useState } from 'react';
import {
  Alert,
  Image,
  Linking,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  AppPage,
  Avatar,
  Hairline,
  IconButton,
  OutlineButton,
  PrimaryButton,
  SectionHeading,
  SurfaceCard,
} from '@/components/AppUI';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

const buyItems = [
  { label: '4 Wheeler', icon: 'car-sport-outline' as const, type: 'Car Insurance' },
  { label: '2 Wheeler', icon: 'bicycle-outline' as const, type: 'Two-wheeler Insurance' },
  { label: 'Health', icon: 'medkit-outline' as const, type: 'Health Insurance' },
];

const moreItems = [
  { label: 'Health & wellness', icon: 'heart-outline' as const, type: 'Health & Wellness' },
  { label: 'Policy certificate', icon: 'document-text-outline' as const, type: 'Policy Certificate' },
  { label: 'Check claim status', icon: 'search-outline' as const, type: 'Claim Status' },
  { label: 'My vehicle', icon: 'car-outline' as const, type: 'My Vehicle' },
  { label: 'Personal accident', icon: 'shield-checkmark-outline' as const, type: 'Personal Accident' },
  { label: 'Travel', icon: 'airplane-outline' as const, type: 'Travel Insurance' },
];

const quickLinks = [
  { label: 'Renew policy', icon: 'refresh-outline' as const, tone: 'pink' },
  { label: 'Health cover', icon: 'heart-outline' as const, tone: 'rose' },
  { label: 'Find a hospital', icon: 'location-outline' as const, tone: 'blue' },
  { label: 'Download policy', icon: 'download-outline' as const, tone: 'gold' },
] as const;

function HomeCategory({
  label,
  icon,
  onPress,
  compact = false,
}: {
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  onPress: () => void;
  compact?: boolean;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={({ pressed }) => [
        styles.categoryItem,
        compact && styles.compactCategory,
        pressed && styles.pressed,
      ]}
    >
      <View
        style={[
          styles.categoryIcon,
          { backgroundColor: colors.primaryWash, borderColor: colors.primaryPale },
          compact && styles.compactCategoryIcon,
        ]}
      >
        <Ionicons name={icon} size={compact ? 20 : 24} color={colors.primary} />
      </View>
      <Text style={[styles.categoryLabel, { color: colors.foreground }]}>
        {label}
      </Text>
    </Pressable>
  );
}

function HomeDrawer({
  visible,
  onClose,
}: {
  visible: boolean;
  onClose: () => void;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { profile, logout, deleteLocalAccount } = useAppState();

  const go = (path: '/profile' | '/calculator' | '/resources' | '/faq' | '/contact') => {
    onClose();
    router.push(path);
  };

  const dial = async () => {
    try {
      await Linking.openURL('tel:1800224030');
    } catch {
      Alert.alert('Emergency support', 'Call 1800-22-4030 for assistance.');
    }
  };

  const removeAccount = () => {
    Alert.alert(
      'Delete demo account?',
      'This removes the profile and demo sign-in saved on this device.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete account',
          style: 'destructive',
          onPress: () => {
            void deleteLocalAccount();
            onClose();
            router.replace('/welcome');
          },
        },
      ],
    );
  };

  const group = (
    title: string,
    items: {
      label: string;
      icon: keyof typeof Ionicons.glyphMap;
      onPress: () => void;
    }[],
  ) => (
    <View style={[styles.drawerGroup, { backgroundColor: colors.white }]}>
      <Text style={[styles.drawerGroupTitle, { color: colors.foreground }]}>
        {title}
      </Text>
      {items.map((item, index) => (
        <React.Fragment key={item.label}>
          {index > 0 ? <Hairline /> : null}
          <Pressable
            onPress={item.onPress}
            accessibilityRole="button"
            style={({ pressed }) => [
              styles.drawerItem,
              pressed && styles.pressed,
            ]}
          >
            <Ionicons name={item.icon} size={19} color={colors.mutedForeground} />
            <Text style={[styles.drawerItemText, { color: colors.foreground }]}>
              {item.label}
            </Text>
            <Ionicons
              name="chevron-forward"
              size={15}
              color={colors.mutedForeground}
            />
          </Pressable>
        </React.Fragment>
      ))}
    </View>
  );

  return (
    <Modal
      transparent
      animationType="fade"
      visible={visible}
      onRequestClose={onClose}
      statusBarTranslucent
    >
      <View style={styles.drawerOverlay}>
        <Pressable
          onPress={onClose}
          accessibilityLabel="Close menu"
          style={[StyleSheet.absoluteFill, { backgroundColor: colors.scrim }]}
        />
        <View
          style={[
            styles.drawer,
            {
              paddingTop: insets.top + 10,
              paddingBottom: Math.max(insets.bottom, 12),
              backgroundColor: colors.screen,
              borderTopRightRadius: 28,
              borderBottomRightRadius: 28,
            },
          ]}
        >
          <View
            style={[
              styles.drawerProfile,
              { backgroundColor: colors.white, borderColor: colors.border },
            ]}
          >
            <Avatar name={profile.fullName} size={54} />
            <View style={styles.drawerProfileCopy}>
              <Text
                numberOfLines={1}
                style={[styles.drawerName, { color: colors.foreground }]}
              >
                {profile.fullName}
              </Text>
              <Text
                numberOfLines={1}
                style={[styles.drawerEmail, { color: colors.mutedForeground }]}
              >
                {profile.email}
              </Text>
            </View>
            <Pressable
              onPress={() => go('/profile')}
              accessibilityRole="button"
              accessibilityLabel="Edit profile"
            >
              <Ionicons name="create-outline" size={21} color={colors.primary} />
            </Pressable>
          </View>

          <ScrollView
            style={styles.drawerScroll}
            contentContainerStyle={styles.drawerScrollContent}
            showsVerticalScrollIndicator={false}
          >
            {group('Account', [
              { label: 'My Profile', icon: 'person-circle-outline', onPress: () => go('/profile') },
            ])}
            {group('App Features', [
              { label: 'Offline Calculator', icon: 'calculator-outline', onPress: () => go('/calculator') },
              { label: 'Resources', icon: 'book-outline', onPress: () => go('/resources') },
              {
                label: 'Privacy Policy',
                icon: 'lock-closed-outline',
                onPress: () => Alert.alert('Privacy Policy', 'This demo stores profile details only on this device. No insurer service is connected.'),
              },
              {
                label: 'Terms & Conditions',
                icon: 'document-text-outline',
                onPress: () => Alert.alert('Terms & Conditions', 'This is a visual demo. Insurance information and calculations are illustrative only.'),
              },
            ])}
            {group('Support', [
              { label: 'Contact Us', icon: 'call-outline', onPress: () => go('/contact') },
              {
                label: 'Rate Us',
                icon: 'star-outline',
                onPress: () => Alert.alert('Thank you', 'App ratings are not connected in this demo.'),
              },
              { label: 'FAQ', icon: 'help-circle-outline', onPress: () => go('/faq') },
              { label: 'Emergency', icon: 'medkit-outline', onPress: () => void dial() },
            ])}
          </ScrollView>

          <View style={styles.drawerActions}>
            <PrimaryButton
              label="Logout"
              icon="chevron-forward"
              onPress={() => {
                void logout();
                onClose();
                router.replace('/welcome');
              }}
            />
            <OutlineButton
              label="Delete Account"
              icon="trash-outline"
              onPress={removeAccount}
            />
            <Text style={[styles.version, { color: colors.mutedForeground }]}>
              Version · 2.86
            </Text>
          </View>
        </View>
      </View>
    </Modal>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const { profile } = useAppState();
  const [drawerVisible, setDrawerVisible] = useState(false);

  return (
    <>
      <AppPage contentStyle={styles.homeContent}>
        <View style={styles.homeHeader}>
          <Pressable
            onPress={() => setDrawerVisible(true)}
            accessibilityRole="button"
            accessibilityLabel="Open menu"
            style={styles.menuButton}
          >
            <Ionicons name="menu" size={27} color={colors.foreground} />
          </Pressable>
          <Avatar name={profile.fullName} size={42} />
          <View style={styles.greeting}>
            <Text style={[styles.greetingSmall, { color: colors.mutedForeground }]}>
              Hi,
            </Text>
            <Text
              numberOfLines={1}
              style={[styles.greetingName, { color: colors.foreground }]}
            >
              {profile.fullName}
            </Text>
          </View>
          <IconButton
            name="notifications-outline"
            label="Notifications"
            badge
            onPress={() => router.push('/notifications')}
          />
        </View>

        <LinearGradient
          colors={[colors.primary, colors.primaryDeep]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.policyHero}
        >
          <View style={styles.policyHeroCopy}>
            <Text style={[styles.heroEyebrow, { color: colors.primaryLightText }]}>
              YOUR COVER, ALL IN ONE PLACE
            </Text>
            <Text style={[styles.heroTitle, { color: colors.white }]}>My Policy</Text>
            <Text style={[styles.heroBody, { color: colors.primaryMutedText }]}>
              Keep your protection close.
            </Text>
            <View style={styles.heroActions}>
              <Pressable
                onPress={() => router.push('/policies')}
                style={({ pressed }) => [
                  styles.heroButton,
                  { backgroundColor: colors.white },
                  pressed && styles.pressed,
                ]}
              >
                <Text style={[styles.heroButtonText, { color: colors.primary }]}>
                  View policies
                </Text>
                <Ionicons name="arrow-forward" size={15} color={colors.primary} />
              </Pressable>
              <Text style={[styles.policyCount, { color: colors.white }]}>
                0 policies
              </Text>
            </View>
          </View>
          <Image
            source={require('../../assets/images/onboarding-safety.png')}
            resizeMode="contain"
            style={styles.heroArt}
            accessibilityLabel="Insurance protection illustration"
          />
          <View style={[styles.heroDecor, { backgroundColor: colors.primarySoft }]} />
        </LinearGradient>

        <View style={styles.section}>
          <SectionHeading title="Buy Insurance" actionLabel="See all" onAction={() => router.push('/policies')} />
          <View style={styles.buyGrid}>
            {buyItems.map((item) => (
              <HomeCategory
                key={item.label}
                label={item.label}
                icon={item.icon}
                onPress={() => router.push({ pathname: '/insurance', params: { type: item.type } })}
              />
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <SectionHeading
            title="More than just insurance"
            actionLabel="Explore"
            onAction={() => router.push('/policies')}
          />
          <SurfaceCard style={styles.moreGrid}>
            {moreItems.map((item) => (
              <HomeCategory
                key={item.label}
                label={item.label}
                icon={item.icon}
                compact
                onPress={() => router.push({ pathname: '/insurance', params: { type: item.type } })}
              />
            ))}
          </SurfaceCard>
        </View>

        <View style={styles.section}>
          <SectionHeading title="Quick Links" />
          <View style={styles.quickGrid}>
            {quickLinks.map((item) => (
              <Pressable
                key={item.label}
                onPress={() => router.push('/policies')}
                style={({ pressed }) => [
                  styles.quickLink,
                  { backgroundColor: colors[item.tone] },
                  pressed && styles.pressed,
                ]}
              >
                <Ionicons name={item.icon} size={20} color={colors.primaryDeep} />
                <Text style={[styles.quickLabel, { color: colors.foreground }]}>
                  {item.label}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <SectionHeading
            title="Insurance plans for you"
            actionLabel="View all"
            onAction={() => router.push('/policies')}
          />
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.horizontalCards}
          >
            <PlanPreview
              title="Health Insurance"
              description="Care for the moments that matter."
              icon="heart"
              color={colors.health}
              onPress={() => router.push({ pathname: '/insurance', params: { type: 'Health Insurance' } })}
            />
            <PlanPreview
              title="Motor Insurance"
              description="Protection for every journey."
              icon="car-sport"
              color={colors.vehicle}
              onPress={() => router.push({ pathname: '/insurance', params: { type: 'Motor Insurance' } })}
            />
          </ScrollView>
        </View>

        <View style={styles.section}>
          <SectionHeading
            title="Trusted by customers"
            actionLabel="Read more"
            onAction={() => router.push('/faq')}
          />
          <SurfaceCard style={styles.testimonial}>
            <View style={styles.stars}>
              {Array.from({ length: 5 }, (_, index) => (
                <Ionicons key={index} name="star" size={15} color={colors.gold} />
              ))}
            </View>
            <Text style={[styles.quote, { color: colors.foreground }]}>
              “Easy to find the information I need and manage my cover in one place.”
            </Text>
            <Text style={[styles.quoteBy, { color: colors.mutedForeground }]}>
              Universal Sompo app user
            </Text>
          </SurfaceCard>
        </View>
        <Text style={[styles.demoNote, { color: colors.mutedForeground }]}>
          Illustrative demo · policy and product information is not connected to live insurer services.
        </Text>
      </AppPage>
      <HomeDrawer visible={drawerVisible} onClose={() => setDrawerVisible(false)} />
    </>
  );
}

function PlanPreview({
  title,
  description,
  icon,
  color,
  onPress,
}: {
  title: string;
  description: string;
  icon: keyof typeof Ionicons.glyphMap;
  color: string;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.planCard,
        { backgroundColor: colors.card, borderColor: colors.border, shadowColor: colors.shadow },
        pressed && styles.pressed,
      ]}
    >
      <View style={[styles.planIcon, { backgroundColor: color }]}>
        <Ionicons name={icon} size={24} color={colors.primaryDeep} />
      </View>
      <Text style={[styles.planTitle, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.planDescription, { color: colors.mutedForeground }]}>
        {description}
      </Text>
      <Text style={[styles.planLink, { color: colors.primary }]}>Explore plan →</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  homeContent: { paddingHorizontal: 16, gap: 17, paddingBottom: 18 },
  homeHeader: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  menuButton: { width: 34, alignItems: 'flex-start', justifyContent: 'center' },
  greeting: { flex: 1, gap: 1 },
  greetingSmall: { fontSize: 11, fontWeight: '600' },
  greetingName: { fontSize: 15, fontWeight: '800' },
  policyHero: {
    minHeight: 165,
    borderRadius: 22,
    padding: 17,
    overflow: 'hidden',
    justifyContent: 'center',
  },
  policyHeroCopy: { zIndex: 2, width: '72%', gap: 5 },
  heroEyebrow: {
    fontSize: 9,
    letterSpacing: 1.1,
    fontWeight: '800',
  },
  heroTitle: { fontSize: 24, fontWeight: '800' },
  heroBody: { fontSize: 12, fontWeight: '500' },
  heroActions: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 5 },
  heroButton: {
    borderRadius: 17,
    paddingVertical: 8,
    paddingHorizontal: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  heroButtonText: { fontSize: 11, fontWeight: '800' },
  policyCount: { fontSize: 10, fontWeight: '700' },
  heroArt: {
    position: 'absolute',
    right: -10,
    bottom: 5,
    width: 148,
    height: 118,
    opacity: 0.84,
    zIndex: 1,
  },
  heroDecor: {
    position: 'absolute',
    width: 150,
    height: 150,
    borderRadius: 80,
    right: -42,
    top: -62,
    opacity: 0.28,
  },
  section: { gap: 9 },
  buyGrid: { flexDirection: 'row', justifyContent: 'space-between', gap: 10 },
  categoryItem: {
    flex: 1,
    minHeight: 90,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    padding: 8,
  },
  categoryIcon: {
    width: 51,
    height: 51,
    borderRadius: 19,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoryLabel: { fontSize: 11, textAlign: 'center', fontWeight: '700', lineHeight: 15 },
  moreGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    paddingVertical: 12,
    paddingHorizontal: 8,
    gap: 3,
  },
  compactCategory: { flexBasis: '30%', minHeight: 82 },
  compactCategoryIcon: { width: 43, height: 43, borderRadius: 15 },
  quickGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 9 },
  quickLink: {
    width: '48%',
    minHeight: 68,
    borderRadius: 15,
    paddingHorizontal: 12,
    paddingVertical: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
  },
  quickLabel: { flex: 1, fontSize: 11, fontWeight: '700', lineHeight: 14 },
  horizontalCards: { gap: 11, paddingRight: 8 },
  planCard: {
    width: 198,
    minHeight: 154,
    borderRadius: 18,
    padding: 14,
    borderWidth: StyleSheet.hairlineWidth,
    gap: 5,
    shadowOpacity: 0.06,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
    elevation: 2,
  },
  planIcon: {
    width: 40,
    height: 40,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 2,
  },
  planTitle: { fontSize: 14, fontWeight: '800' },
  planDescription: { fontSize: 11, lineHeight: 15 },
  planLink: { fontSize: 11, fontWeight: '800', marginTop: 3 },
  testimonial: { gap: 8 },
  stars: { flexDirection: 'row', gap: 2 },
  quote: { fontSize: 14, lineHeight: 21, fontWeight: '500' },
  quoteBy: { fontSize: 11, fontWeight: '600' },
  demoNote: { fontSize: 10, lineHeight: 15, textAlign: 'center', paddingHorizontal: 12 },
  drawerOverlay: { flex: 1, flexDirection: 'row' },
  drawer: {
    width: '84%',
    maxWidth: 355,
    height: '100%',
    paddingHorizontal: 12,
    gap: 10,
  },
  drawerProfile: {
    minHeight: 72,
    borderRadius: 17,
    borderWidth: 1,
    padding: 10,
    alignItems: 'center',
    flexDirection: 'row',
    gap: 10,
  },
  drawerProfileCopy: { flex: 1, gap: 3 },
  drawerName: { fontSize: 14, fontWeight: '800' },
  drawerEmail: { fontSize: 10 },
  drawerScroll: { flex: 1 },
  drawerScrollContent: { gap: 10, paddingBottom: 4 },
  drawerGroup: {
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingTop: 11,
    paddingBottom: 4,
    shadowOpacity: 0.04,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
  },
  drawerGroupTitle: { fontSize: 13, fontWeight: '800', marginBottom: 2 },
  drawerItem: {
    minHeight: 39,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  drawerItemText: { flex: 1, fontSize: 13, fontWeight: '600' },
  drawerActions: { gap: 7 },
  version: { textAlign: 'center', fontSize: 10, letterSpacing: 1.1, paddingTop: 2 },
  pressed: { opacity: 0.75 },
});
