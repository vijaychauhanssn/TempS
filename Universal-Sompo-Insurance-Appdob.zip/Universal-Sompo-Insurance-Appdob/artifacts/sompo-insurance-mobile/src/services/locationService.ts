export type CityLocation = {
  name: string;
  pincodes: string[];
};

export type StateLocation = {
  name: string;
  cities: CityLocation[];
};

/**
 * Sample locations for the offline demo flows. These are not a live provider
 * network or a complete postal master; connect the approved location API
 * before using them for underwriting, eligibility, or service availability.
 */
export const demoLocationCatalog: StateLocation[] = [
  {
    name: 'Bihar',
    cities: [
      { name: 'Gaya', pincodes: ['823001'] },
      { name: 'Patna', pincodes: ['800001', '800013', '800014', '800020'] },
    ],
  },
  {
    name: 'Delhi',
    cities: [
      { name: 'Delhi', pincodes: ['110001', '110075'] },
    ],
  },
  {
    name: 'Jharkhand',
    cities: [
      { name: 'Jamshedpur', pincodes: ['831001'] },
    ],
  },
  {
    name: 'Maharashtra',
    cities: [
      { name: 'Mumbai', pincodes: ['400001'] },
      { name: 'Pune', pincodes: ['411001'] },
    ],
  },
  {
    name: 'Uttar Pradesh',
    cities: [
      { name: 'Ghaziabad', pincodes: ['201001'] },
      { name: 'Noida', pincodes: ['201301'] },
    ],
  },
  {
    name: 'West Bengal',
    cities: [
      { name: 'Kolkata', pincodes: ['700001', '700020'] },
    ],
  },
];

export const demoStates = demoLocationCatalog.map((state) => state.name);

export function getDemoCities(stateName: string): string[] {
  return demoLocationCatalog.find((state) => state.name === stateName)?.cities.map((city) => city.name) ?? [];
}

export function getDemoPincodes(stateName: string, cityName: string): string[] {
  return demoLocationCatalog
    .find((state) => state.name === stateName)
    ?.cities.find((city) => city.name === cityName)
    ?.pincodes ?? [];
}

export function getLocationForPincode(pincode: string): { state: string; city: string } | undefined {
  for (const state of demoLocationCatalog) {
    for (const city of state.cities) {
      if (city.pincodes.includes(pincode)) return { state: state.name, city: city.name };
    }
  }
  return undefined;
}
