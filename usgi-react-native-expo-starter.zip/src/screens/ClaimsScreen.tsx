import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import BrandHeader from '../components/BrandHeader';
import { colors } from '../theme/colors';

const claims = [
  { id: 'CLM-2026-00124', type: 'Health insurance claim', date: '12 Oct 2026', status: 'In review', amount: '₹ 18,500', stage: 2 },
  { id: 'CLM-2026-00087', type: 'Motor insurance claim', date: '28 Sep 2026', status: 'Documents required', amount: '₹ 32,000', stage: 1 },
];
export default function ClaimsScreen() {
  const [filter, setFilter] = useState<'All' | 'In progress' | 'Closed'>('All');
  return (
    <View style={styles.screen}>
      <BrandHeader />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.heading}>My Claims</Text>
        <Text style={styles.sub}>Track the status of your submitted claims.</Text>
        <View style={styles.filters}>{(['All', 'In progress', 'Closed'] as const).map(f => <Pressable key={f} onPress={() => setFilter(f)} style={[styles.filter, filter === f && styles.filterActive]}><Text style={[styles.filterText, filter === f && styles.filterTextActive]}>{f}</Text></Pressable>)}</View>
        {(filter === 'Closed' ? [] : claims).map(claim => (
          <View key={claim.id} style={styles.card}>
            <View style={styles.cardTop}><View style={styles.claimIcon}><Ionicons name="document-text-outline" size={22} color={colors.primary}/></View><View style={{ flex: 1 }}><Text style={styles.claimType}>{claim.type}</Text><Text style={styles.claimId}>{claim.id}</Text></View><View style={styles.status}><Text style={styles.statusText}>{claim.status}</Text></View></View>
            <View style={styles.divider}/>
            <View style={styles.details}><View><Text style={styles.detailLabel}>Claim amount</Text><Text style={styles.amount}>{claim.amount}</Text></View><View><Text style={styles.detailLabel}>Submitted on</Text><Text style={styles.detailValue}>{claim.date}</Text></View></View>
            <Text style={styles.progressLabel}>Claim progress</Text>
            <View style={styles.progressRow}>{['Submitted', 'Under review', 'Decision'].map((step, i) => <View key={step} style={styles.progressItem}><View style={[styles.bubble, i < claim.stage && styles.bubbleActive]}><Ionicons name={i < claim.stage ? 'checkmark' : 'ellipse-outline'} size={12} color={i < claim.stage ? '#FFF' : colors.muted}/></View><Text style={styles.progressText}>{step}</Text></View>)}</View>
            <Text style={styles.viewDetails}>View claim details  ›</Text>
          </View>
        ))}
        {filter === 'Closed' && <Text style={styles.empty}>No closed claims to display in this demo.</Text>}
        <Text style={styles.disclaimer}>Demo content only. Connect your claims API before using real policyholder data.</Text>
      </ScrollView>
    </View>
  );
}
const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  content: { padding: 18, paddingBottom: 30 },
  heading: { fontSize: 24, fontWeight: '800', color: colors.text, marginTop: 8 },
  sub: { color: colors.muted, fontSize: 13, marginTop: 6, marginBottom: 18 },
  filters: { flexDirection: 'row', backgroundColor: '#ECE9EB', borderRadius: 13, padding: 4, marginBottom: 16 },
  filter: { flex: 1, alignItems: 'center', paddingVertical: 11, borderRadius: 10 },
  filterActive: { backgroundColor: '#FFF', elevation: 1 },
  filterText: { color: colors.muted, fontSize: 12, fontWeight: '600' },
  filterTextActive: { color: colors.primary },
  card: { backgroundColor: '#FFF', borderRadius: 16, padding: 15, marginBottom: 14, borderWidth: 1, borderColor: '#F0ECEE' },
  cardTop: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  claimIcon: { width: 42, height: 42, borderRadius: 13, backgroundColor: colors.roseLight, alignItems: 'center', justifyContent: 'center' },
  claimType: { color: colors.text, fontSize: 13, fontWeight: '700' },
  claimId: { color: colors.muted, fontSize: 10, marginTop: 4 },
  status: { backgroundColor: '#FFF2D9', borderRadius: 7, paddingHorizontal: 8, paddingVertical: 6, maxWidth: 100 },
  statusText: { fontSize: 9, color: colors.amber, fontWeight: '700', textAlign: 'center' },
  divider: { height: 1, backgroundColor: colors.border, marginVertical: 14 },
  details: { flexDirection: 'row', justifyContent: 'space-between' },
  detailLabel: { fontSize: 10, color: colors.muted },
  amount: { fontSize: 16, color: colors.text, fontWeight: '800', marginTop: 5 },
  detailValue: { fontSize: 12, color: colors.text, fontWeight: '600', marginTop: 5 },
  progressLabel: { fontSize: 12, color: colors.text, fontWeight: '700', marginTop: 18, marginBottom: 13 },
  progressRow: { flexDirection: 'row', justifyContent: 'space-between' },
  progressItem: { alignItems: 'center', flex: 1 },
  bubble: { width: 25, height: 25, borderRadius: 13, backgroundColor: '#F0EEF0', alignItems: 'center', justifyContent: 'center', marginBottom: 6 },
  bubbleActive: { backgroundColor: colors.primary },
  progressText: { fontSize: 9, color: colors.muted, textAlign: 'center' },
  viewDetails: { color: colors.primary, fontWeight: '700', fontSize: 12, marginTop: 18 },
  empty: { color: colors.muted, textAlign: 'center', marginVertical: 35 },
  disclaimer: { fontSize: 10, color: colors.muted, lineHeight: 16, marginTop: 5 },
});