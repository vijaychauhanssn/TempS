import React, { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { AppHeader, AppPage, LabeledInput, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

const VEHICLES_KEY = 'universal-sompo:vehicles';

export default function MyVehicleScreen() {
  const colors = useColors();
  const { vehicleNumber: initialVehicle = '' } = useLocalSearchParams<{ vehicleNumber?: string }>();
  const [vehicles, setVehicles] = useState<string[]>([]);
  const [vehicleNumber, setVehicleNumber] = useState(initialVehicle.toUpperCase());
  const [error, setError] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    let mounted = true;
    AsyncStorage.getItem(VEHICLES_KEY)
      .then((value) => {
        if (!mounted || !value) return;
        const parsed: unknown = JSON.parse(value);
        if (Array.isArray(parsed)) {
          setVehicles(parsed.filter((item): item is string => typeof item === 'string'));
        }
      })
      .catch(() => setError('Could not load saved vehicles.'))
      .finally(() => {
        if (mounted) setIsLoaded(true);
      });
    return () => {
      mounted = false;
    };
  }, []);

  const saveVehicles = async (next: string[]) => {
    await AsyncStorage.setItem(VEHICLES_KEY, JSON.stringify(next));
    setVehicles(next);
  };

  const addVehicle = async () => {
    const normalized = vehicleNumber.toUpperCase().replace(/[\s-]/g, '');
    if (!/^[A-Z]{2}\d{1,2}[A-Z]{0,3}\d{1,4}$/.test(normalized)) {
      setError('Enter a valid vehicle registration number, for example UP14MH1888.');
      return;
    }
    setError('');
    try {
      await saveVehicles([normalized, ...vehicles.filter((item) => item !== normalized)]);
      setVehicleNumber(normalized);
    } catch {
      setError('This vehicle could not be saved on this device.');
    }
  };

  const openTool = (tool: 'challan' | 'puc' | 'insurance', number: string) => {
    if (tool === 'challan') {
      router.push({ pathname: '/my-challan', params: { vehicleNumber: number } });
    } else if (tool === 'puc') {
      router.push({ pathname: '/pollution-certificate', params: { vehicleNumber: number } });
    } else {
      router.push({ pathname: '/motor-insurance', params: { vehicle: 'Four Wheeler', registration: number } });
    }
  };

  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="My Vehicle" onBack={() => router.back()} />
      <Image
        source={require('../assets/images/vehicle-companion-hero.png')}
        resizeMode="cover"
        style={styles.hero}
        accessibilityLabel="Car protected by a shield"
      />
      <View style={styles.intro}>
        <Text style={[styles.title, { color: colors.foreground }]}>Your All-In-One Vehicle Companion</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Manage insurance, challans, PUC status and more.
        </Text>
      </View>

      <SurfaceCard style={styles.addCard}>
        <Text style={[styles.addTitle, { color: colors.foreground }]}>Add Vehicle Number</Text>
        <LabeledInput
          label="Vehicle Number"
          value={vehicleNumber}
          onChangeText={(value) => setVehicleNumber(value.toUpperCase())}
          placeholder="Enter vehicle number"
          autoCapitalize="characters"
          accessibilityLabel="Enter vehicle number"
        />
        {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
        <PrimaryButton label="Proceed" icon="arrow-forward" onPress={() => void addVehicle()} />
      </SurfaceCard>

      <View style={styles.benefitHeader}>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Benefits</Text>
        <Text style={[styles.sectionNote, { color: colors.mutedForeground }]}>Select a tool to continue</Text>
      </View>
      <View style={styles.benefitGrid}>
        {([
          { label: 'Challan', detail: 'View traffic challans', icon: 'receipt-outline' as const, key: 'challan' as const },
          { label: 'PUC', detail: 'Check certificate status', icon: 'leaf-outline' as const, key: 'puc' as const },
          { label: 'Insurance', detail: 'View or renew cover', icon: 'shield-checkmark-outline' as const, key: 'insurance' as const },
        ]).map((item) => (
          <Pressable
            key={item.key}
            onPress={() => {
              const number = vehicles[0] ?? vehicleNumber.toUpperCase().replace(/[\s-]/g, '');
              if (!number) {
                setError('Add a vehicle number first, then choose a vehicle service.');
                return;
              }
              openTool(item.key, number);
            }}
            style={({ pressed }) => [styles.benefitPressable, pressed && styles.pressed]}
          >
            <SurfaceCard style={[styles.benefitCard, { borderColor: colors.border }]}>
              <View style={[styles.benefitIcon, { backgroundColor: colors.primaryWash }]}>
                <Ionicons name={item.icon} size={21} color={colors.primary} />
              </View>
              <Text style={[styles.benefitTitle, { color: colors.foreground }]}>{item.label}</Text>
              <Text style={[styles.benefitDetail, { color: colors.mutedForeground }]}>{item.detail}</Text>
              <Ionicons name="chevron-forward" size={14} color={colors.primary} />
            </SurfaceCard>
          </Pressable>
        ))}
      </View>

      {isLoaded && vehicles.length > 0 ? (
        <View style={styles.savedSection}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Saved Vehicles</Text>
          {vehicles.map((number) => (
            <SurfaceCard key={number} style={styles.savedVehicle}>
              <View style={[styles.savedVehicleIcon, { backgroundColor: colors.primaryWash }]}>
                <Ionicons name="car-sport-outline" size={20} color={colors.primary} />
              </View>
              <View style={styles.savedVehicleCopy}>
                <Text style={[styles.savedNumber, { color: colors.foreground }]}>{number}</Text>
                <Text style={[styles.savedLabel, { color: colors.mutedForeground }]}>Saved on this device</Text>
              </View>
              <Pressable
                onPress={() => {
                  void saveVehicles(vehicles.filter((item) => item !== number)).catch(() =>
                    setError('This vehicle could not be removed.'),
                  );
                }}
                accessibilityRole="button"
                accessibilityLabel={`Remove ${number}`}
                hitSlop={8}
              >
                <Ionicons name="trash-outline" size={18} color={colors.destructive} />
              </Pressable>
            </SurfaceCard>
          ))}
        </View>
      ) : null}

      <Text style={[styles.note, { color: colors.mutedForeground }]}>
        Vehicle records and service results are stored locally for this demo.
      </Text>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 14, gap: 12 },
  hero: { width: '100%', height: 166, borderRadius: 14 },
  intro: { alignItems: 'center', gap: 4, paddingHorizontal: 8 },
  title: { fontSize: 15, fontWeight: '800', textAlign: 'center' },
  subtitle: { fontSize: 10, lineHeight: 15, textAlign: 'center' },
  addCard: { gap: 9, padding: 12 },
  addTitle: { fontSize: 12, fontWeight: '800' },
  error: { fontSize: 10, lineHeight: 14 },
  benefitHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  sectionTitle: { fontSize: 14, fontWeight: '800' },
  sectionNote: { fontSize: 9 },
  benefitGrid: { flexDirection: 'row', gap: 7 },
  benefitPressable: { flex: 1, minWidth: 0 },
  benefitCard: { minHeight: 121, padding: 8, alignItems: 'center', gap: 4, borderRadius: 14 },
  benefitIcon: { width: 36, height: 36, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  benefitTitle: { fontSize: 10, fontWeight: '800' },
  benefitDetail: { minHeight: 25, fontSize: 8, lineHeight: 11, textAlign: 'center' },
  savedSection: { gap: 7 },
  savedVehicle: { minHeight: 58, padding: 9, flexDirection: 'row', alignItems: 'center', gap: 8 },
  savedVehicleIcon: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  savedVehicleCopy: { flex: 1, gap: 3 },
  savedNumber: { fontSize: 12, fontWeight: '800' },
  savedLabel: { fontSize: 9 },
  note: { fontSize: 9, lineHeight: 14, textAlign: 'center' },
  pressed: { opacity: 0.74 },
});
