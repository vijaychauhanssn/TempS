import React, { useState } from 'react';
import {
  Modal,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  AppHeader,
  LabeledInput,
  PrimaryButton,
  SurfaceCard,
} from '@/components/AppUI';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';
import { createDemoHealthReference, getAPlusReferenceQuote } from '@/src/services/healthService';

const steps = ['Pincode', 'Fill Form', 'Plan', 'Details'];

export default function APlusCalculatorScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { profile } = useAppState();
  const [step, setStep] = useState(1);
  const [pincode, setPincode] = useState('');
  const [name, setName] = useState(profile.fullName);
  const [email, setEmail] = useState(profile.email);
  const [mobile, setMobile] = useState(profile.mobile);
  const [sumInsured] = useState('₹10 Lakh');
  const [plan] = useState('Silver');
  const [tenure] = useState('1 Year');
  const [addonOwner, setAddonOwner] = useState<'Self' | 'Spouse' | null>(null);
  const [reference, setReference] = useState('');
  const [error, setError] = useState('');
  const topInset = insets.top;
  const bottomInset = insets.bottom;
  const quote = getAPlusReferenceQuote({ sumInsured, plan, tenure });

  const continueStep = () => {
    setError('');
    if (step === 1) {
      if (!/^\d{6}$/.test(pincode)) {
        setError('Enter a valid 6-digit pincode.');
        return;
      }
      setStep(2);
      return;
    }
    if (step === 2) {
      if (!name.trim() || !/^\S+@\S+\.\S+$/.test(email) || mobile.replace(/\D/g, '').length < 10) {
        setError('Enter your name, a valid email address, and a 10-digit contact number.');
        return;
      }
      setStep(3);
      return;
    }
    if (step === 3) {
      setStep(4);
      return;
    }
    setReference(createDemoHealthReference('APLUS'));
  };

  return (
    <>
      <KeyboardAwareScrollViewCompat
        style={[styles.page, { backgroundColor: colors.screen }]}
        contentContainerStyle={[
          styles.content,
          { paddingTop: Math.max(topInset, 12) + 6, paddingBottom: bottomInset + 24 },
        ]}
        bottomOffset={70}
        keyboardShouldPersistTaps="handled"
      >
        <AppHeader title="A Plus Calculator" onBack={() => router.back()} />
        <View style={styles.progress}>
          {steps.map((label, index) => {
            const number = index + 1;
            const complete = number <= step;
            return (
              <React.Fragment key={label}>
                <View style={styles.progressStep}>
                  <View style={[
                    styles.stepCircle,
                    { backgroundColor: complete ? colors.primary : colors.muted },
                  ]}>
                    <Text style={[styles.stepNumber, { color: complete ? colors.white : colors.mutedForeground }]}>
                      {number}
                    </Text>
                  </View>
                  <Text style={[styles.stepLabel, { color: complete ? colors.primary : colors.mutedForeground }]}>
                    {label}
                  </Text>
                </View>
                {index < steps.length - 1 ? (
                  <View style={[styles.stepLine, { backgroundColor: number < step ? colors.primary : colors.border }]} />
                ) : null}
              </React.Fragment>
            );
          })}
        </View>

        {!reference && step === 1 ? (
          <SurfaceCard style={styles.sectionCard}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>For Adult 1</Text>
            <Text style={[styles.copy, { color: colors.mutedForeground }]}>
              Enter your pincode to begin the A Plus calculator.
            </Text>
            <LabeledInput
              label="Pincode *"
              value={pincode}
              onChangeText={(value) => setPincode(value.replace(/\D/g, '').slice(0, 6))}
              placeholder="Enter 6-digit pincode"
              keyboardType="number-pad"
              maxLength={6}
              testID="aplus-pincode"
            />
          </SurfaceCard>
        ) : null}

        {!reference && step === 2 ? (
          <SurfaceCard style={styles.sectionCard}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Proposer Details</Text>
            <LabeledInput label="Proposer Name *" value={name} onChangeText={setName} placeholder="Your name" />
            <LabeledInput
              label="Email ID *"
              value={email}
              onChangeText={setEmail}
              placeholder="Enter your email"
              keyboardType="email-address"
              autoCapitalize="none"
            />
            <LabeledInput
              label="Contact Number *"
              value={mobile}
              onChangeText={setMobile}
              placeholder="Enter contact number"
              keyboardType="phone-pad"
              maxLength={13}
            />
          </SurfaceCard>
        ) : null}

        {!reference && step === 3 ? (
          <>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Select the plan details</Text>
            <SurfaceCard style={styles.sectionCard}>
              <ChoiceRow label="Select the sum insured *" value={sumInsured} />
              <View style={styles.twoColumns}>
                <View style={styles.column}>
                  <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Select your Tenure *</Text>
                  <ChoiceRow label="" value={tenure} compact />
                </View>
                <View style={styles.column}>
                  <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Select your Plan *</Text>
                  <ChoiceRow label="" value={plan} compact />
                </View>
              </View>
            </SurfaceCard>
            <SurfaceCard style={[styles.selectedPlan, { borderColor: colors.primaryPale }]}>
              <View style={[styles.planIcon, { backgroundColor: colors.primaryWash }]}>
                <Ionicons name="ribbon" size={19} color={colors.primary} />
              </View>
              <View style={styles.planCopy}>
                <Text style={[styles.planTitle, { color: colors.primary }]}>{plan}</Text>
                <Text style={[styles.planSubTitle, { color: colors.foreground }]}>Premium amount</Text>
              </View>
              <Text style={[styles.premiumAmount, { color: colors.primary }]}>
                {quote ? `₹${quote.annualPremium.toLocaleString('en-IN')}` : 'Unavailable'}
              </Text>
            </SurfaceCard>
            <View style={styles.addOnSection}>
              <AddOnRow label="Self Add-ons details" onPress={() => setAddonOwner('Self')} />
              <AddOnRow label="Spouse Add-ons details" onPress={() => setAddonOwner('Spouse')} />
            </View>
            <Text style={[styles.note, { color: colors.mutedForeground }]}>
              Only the ₹10 Lakh / Silver / 1 Year reference amount is shown from the supplied screen. Other rates and add-on prices are not provided.
            </Text>
          </>
        ) : null}

        {!reference && step === 4 ? (
          <>
            <SurfaceCard style={styles.sectionCard}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Proposer Details</Text>
              <SummaryRow label="Proposer Name" value={name} />
              <SummaryRow label="Email ID" value={email} />
              <SummaryRow label="Contact Number" value={mobile} />
            </SurfaceCard>
            <SurfaceCard style={styles.sectionCard}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Quote Details</Text>
              <SummaryRow label="Sum insured" value={sumInsured} />
              <SummaryRow label="Plan type" value={plan} />
              <SummaryRow label="Policy tenure" value={tenure} />
              {quote ? (
                <SummaryRow label="Reference premium" value={`₹${quote.annualPremium.toLocaleString('en-IN')} P.A.`} />
              ) : (
                <SummaryRow label="Reference premium" value="Not available for this selection" />
              )}
            </SurfaceCard>
            <View style={[styles.offlineNote, { backgroundColor: colors.primaryWash }]}>
              <Ionicons name="information-circle-outline" size={16} color={colors.primary} />
              <Text style={[styles.note, { color: colors.foreground }]}>
                This is an offline demo estimate, not an insurer quote. No policy or payment will be created.
              </Text>
            </View>
          </>
        ) : null}

        {reference ? (
          <SurfaceCard style={styles.successCard}>
            <View style={[styles.successIcon, { backgroundColor: colors.primaryWash }]}>
              <Ionicons name="checkmark" size={28} color={colors.success} />
            </View>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Details saved</Text>
            <Text style={[styles.note, { color: colors.mutedForeground }]}>
              Demo reference: {reference}. Your information has not been sent to Universal Sompo.
            </Text>
            <PrimaryButton label="Back to Home" icon="home-outline" onPress={() => router.replace('/(tabs)/home')} />
          </SurfaceCard>
        ) : null}

        {error ? <Text accessibilityRole="alert" style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
        {!reference ? (
          <View style={styles.footer}>
            <PrimaryButton
              label={step === 4 ? 'Send Details' : 'Continue'}
              icon={step === 4 ? 'send-outline' : 'chevron-forward'}
              onPress={continueStep}
            />
          </View>
        ) : null}
      </KeyboardAwareScrollViewCompat>

      <Modal
        visible={addonOwner !== null}
        transparent
        animationType="slide"
        onRequestClose={() => setAddonOwner(null)}
      >
        <View style={styles.modalBackdrop}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setAddonOwner(null)} accessibilityLabel="Close add-ons" />
          <View style={[styles.modalCard, { backgroundColor: colors.card }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
                {addonOwner} add-ons
              </Text>
              <Pressable onPress={() => setAddonOwner(null)} accessibilityRole="button" accessibilityLabel="Close add-ons">
                <Ionicons name="close" size={22} color={colors.destructive} />
              </Pressable>
            </View>
            <Text style={[styles.copy, { color: colors.mutedForeground }]}>
              Add-on options and prices were not included in the A Plus reference. No add-ons are selected in this offline demo.
            </Text>
            <PrimaryButton label="Close" onPress={() => setAddonOwner(null)} />
          </View>
        </View>
      </Modal>
    </>
  );
}

function ChoiceRow({ label, value, compact = false }: { label: string; value: string; compact?: boolean }) {
  const colors = useColors();
  return (
    <View style={styles.choiceGroup}>
      {label ? <Text style={[styles.fieldLabel, { color: colors.foreground }]}>{label}</Text> : null}
      <View style={[styles.choiceRow, { borderColor: colors.borderStrong, backgroundColor: colors.card }, compact && styles.choiceRowCompact]}>
        <Text style={[styles.choiceValue, { color: colors.mutedForeground }]}>{value}</Text>
        <Ionicons name="chevron-down" size={16} color={colors.foreground} />
      </View>
    </View>
  );
}

function AddOnRow({ label, onPress }: { label: string; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={({ pressed }) => [
        styles.addOnRow,
        { borderColor: colors.border, backgroundColor: colors.card },
        pressed && styles.pressed,
      ]}
    >
      <View style={styles.addOnCopy}>
        <Text style={[styles.addOnTitle, { color: colors.foreground }]}>{label}</Text>
        <Text style={[styles.note, { color: colors.mutedForeground }]}>0 Add-ons selected</Text>
      </View>
      <Text style={[styles.addOnAction, { color: colors.primary, borderColor: colors.primary }]}>Select Add-ons</Text>
    </Pressable>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  const colors = useColors();
  return (
    <View style={[styles.summaryRow, { borderBottomColor: colors.border }]}>
      <Text style={[styles.summaryLabel, { color: colors.foreground }]}>{label}</Text>
      <Text style={[styles.summaryValue, { color: colors.mutedForeground }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 13, gap: 12 },
  progress: { flexDirection: 'row', alignItems: 'flex-start', paddingHorizontal: 7, marginBottom: 3 },
  progressStep: { width: 48, alignItems: 'center', gap: 4 },
  stepCircle: { width: 21, height: 21, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  stepNumber: { fontSize: 10, fontWeight: '800' },
  stepLabel: { fontSize: 7, fontWeight: '700', textAlign: 'center' },
  stepLine: { flex: 1, height: 2, marginTop: 9 },
  sectionCard: { gap: 10, padding: 12 },
  sectionTitle: { fontSize: 14, fontWeight: '800' },
  copy: { fontSize: 10, lineHeight: 15 },
  fieldLabel: { fontSize: 10, lineHeight: 14, fontWeight: '700' },
  twoColumns: { flexDirection: 'row', gap: 9 },
  column: { flex: 1, gap: 6 },
  choiceGroup: { gap: 5 },
  choiceRow: { minHeight: 39, borderWidth: 1, borderRadius: 9, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  choiceRowCompact: { minHeight: 36 },
  choiceValue: { fontSize: 9 },
  selectedPlan: { borderWidth: 1, borderRadius: 12, padding: 10, flexDirection: 'row', alignItems: 'center', gap: 8 },
  planIcon: { width: 28, height: 28, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  planCopy: { flex: 1, gap: 2 },
  planTitle: { fontSize: 11, fontWeight: '800' },
  planSubTitle: { fontSize: 9, fontWeight: '700' },
  premiumAmount: { fontSize: 12, fontWeight: '800' },
  addOnSection: { gap: 8 },
  addOnRow: { minHeight: 52, borderWidth: 1, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 7, flexDirection: 'row', alignItems: 'center', gap: 8 },
  addOnCopy: { flex: 1, gap: 3 },
  addOnTitle: { fontSize: 10, fontWeight: '700' },
  addOnAction: { fontSize: 8, fontWeight: '700', borderWidth: 1, borderRadius: 13, paddingHorizontal: 8, paddingVertical: 5 },
  summaryRow: { minHeight: 31, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  summaryLabel: { fontSize: 10, fontWeight: '600' },
  summaryValue: { flexShrink: 1, fontSize: 10, textAlign: 'right' },
  offlineNote: { padding: 10, borderRadius: 10, flexDirection: 'row', alignItems: 'flex-start', gap: 6 },
  note: { flex: 1, fontSize: 9, lineHeight: 14 },
  error: { fontSize: 10, fontWeight: '600' },
  footer: { marginTop: 'auto', paddingTop: 6 },
  successCard: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12, padding: 18 },
  successIcon: { width: 55, height: 55, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  modalBackdrop: { flex: 1, backgroundColor: 'rgba(31, 18, 23, 0.52)', justifyContent: 'flex-end' },
  modalCard: { borderTopLeftRadius: 18, borderTopRightRadius: 18, padding: 18, paddingBottom: 26, gap: 14 },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  pressed: { opacity: 0.78 },
});
