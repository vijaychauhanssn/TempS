import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppPage, SectionHeading, SurfaceCard } from '@/components/AppUI';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

const wellnessLinks = [
  { title: 'Health profile', detail: 'Keep important health details in one place.', icon: 'person-circle-outline' as const, route: '/profile' as const },
  { title: 'Offline calculator', detail: 'Check a simple wellness estimate.', icon: 'calculator-outline' as const, route: '/calculator' as const },
  { title: 'Health resources', detail: 'Browse helpful guides and videos.', icon: 'book-outline' as const, route: '/resources' as const },
  { title: 'KBL Health Services', detail: 'Health checkups and tele consultation.', icon: 'medkit-outline' as const, route: '/kbl' as const },
];

export default function WellnessScreen() {
  const colors = useColors();
  const { profile } = useAppState();

  return (
    <AppPage contentStyle={styles.content}>
      <View style={[styles.hero, { backgroundColor: colors.primaryPale }]}>
        <View style={styles.heroCopy}>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>WELLNESS</Text>
          <Text style={[styles.heroTitle, { color: colors.foreground }]}>
            A little care goes a long way.
          </Text>
          <Text style={[styles.heroBody, { color: colors.mutedForeground }]}>
            Your health information, ready when you need it.
          </Text>
        </View>
        <View style={[styles.heart, { backgroundColor: colors.white }]}>
          <Ionicons name="heart" size={29} color={colors.primary} />
        </View>
      </View>

      <SectionHeading title="Your health snapshot" />
      <SurfaceCard style={styles.snapshot}>
        <View style={styles.snapshotItem}>
          <Text style={[styles.snapshotLabel, { color: colors.mutedForeground }]}>
            Blood group
          </Text>
          <Text style={[styles.snapshotValue, { color: colors.foreground }]}>
            {profile.bloodGroup}
          </Text>
        </View>
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        <View style={styles.snapshotItem}>
          <Text style={[styles.snapshotLabel, { color: colors.mutedForeground }]}>
            Activity
          </Text>
          <Text style={[styles.snapshotValue, { color: colors.foreground }]}>
            {profile.dailyActivity}
          </Text>
        </View>
      </SurfaceCard>

      <SectionHeading title="Your wellness tools" />
      <View style={styles.list}>
        {wellnessLinks.map((item, index) => (
          <Pressable
            key={item.title}
            onPress={() => router.push(item.route)}
            style={({ pressed }) => [pressed && styles.pressed]}
          >
            <SurfaceCard style={styles.linkCard}>
              <View style={[styles.linkIcon, { backgroundColor: colors.primaryWash }]}>
                <Ionicons name={item.icon} size={22} color={colors.primary} />
              </View>
              <View style={styles.linkText}>
                <Text style={[styles.linkTitle, { color: colors.foreground }]}>
                  {item.title}
                </Text>
                <Text style={[styles.linkDetail, { color: colors.mutedForeground }]}>
                  {item.detail}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={17} color={colors.mutedForeground} />
            </SurfaceCard>
          </Pressable>
        ))}
      </View>
      <Text style={[styles.note, { color: colors.mutedForeground }]}>
        Health notes are stored on this device for demo purposes only.
      </Text>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 16, gap: 16 },
  hero: {
    minHeight: 154,
    borderRadius: 23,
    padding: 18,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  heroCopy: { flex: 1, gap: 6 },
  eyebrow: { fontSize: 10, fontWeight: '800', letterSpacing: 1.1 },
  heroTitle: { fontSize: 20, lineHeight: 25, fontWeight: '800' },
  heroBody: { fontSize: 12, lineHeight: 17 },
  heart: { width: 58, height: 58, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  snapshot: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around' },
  snapshotItem: { flex: 1, alignItems: 'center', gap: 5 },
  snapshotLabel: { fontSize: 11 },
  snapshotValue: { fontSize: 15, fontWeight: '800' },
  divider: { width: StyleSheet.hairlineWidth, height: 42 },
  list: { gap: 9 },
  linkCard: { padding: 12, flexDirection: 'row', alignItems: 'center', gap: 11 },
  linkIcon: { width: 43, height: 43, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  linkText: { flex: 1, gap: 4 },
  linkTitle: { fontSize: 13, fontWeight: '700' },
  linkDetail: { fontSize: 11, lineHeight: 15 },
  note: { fontSize: 10, lineHeight: 15, textAlign: 'center', marginTop: 3 },
  pressed: { opacity: 0.76 },
});
