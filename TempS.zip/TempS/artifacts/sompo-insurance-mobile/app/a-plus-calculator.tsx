import React, { useState } from 'react';
import {
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  AppHeader,
  LabeledInput,
  PrimaryButton,
  SurfaceCard,
} from '@/components/AppUI';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';
import { createDemoHealthReference, getAPlusReferenceQuote } from '@/src/services/healthService';

const steps = ['Pincode', 'Fill Form', 'Plan', 'Details'];
const demoPincodes = [
  '110001',
  '110075',
  '201001',
  '201301',
  '400001',
  '411001',
  '700001',
  '700020',
  '800001',
  '800013',
  '800014',
  '800020',
  '823001',
  '831001',
];
const sumInsuredOptions = [
  '₹5 Lakh',
  '₹10 Lakh',
  '₹15 Lakh',
  '₹20 Lakh',
  '₹25 Lakh',
  '₹50 Lakh',
  '₹1 Crore',
];
const tenureOptions = ['1 Year', '2 Years', '3 Years'];
const planOptions = ['Silver', 'Gold', 'Platinum'];

export default function APlusCalculatorScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { profile } = useAppState();
  const [step, setStep] = useState(1);
  const [pincode, setPincode] = useState('');
  const [name, setName] = useState(profile.fullName);
  const [email, setEmail] = useState(profile.email);
  const [mobile, setMobile] = useState(profile.mobile);
  const [sumInsured, setSumInsured] = useState('₹10 Lakh');
  const [plan, setPlan] = useState('Silver');
  const [tenure, setTenure] = useState('1 Year');
  const [addonOwner, setAddonOwner] = useState<'Self' | 'Spouse' | null>(null);
  const [reference, setReference] = useState('');
  const [error, setError] = useState('');
  const topInset = insets.top;
  const bottomInset = insets.bottom;
  const quote = getAPlusReferenceQuote({ sumInsured, plan, tenure });

  const continueStep = () => {
    setError('');
    if (step === 1) {
      if (!demoPincodes.includes(pincode)) {
        setError('Select a pincode from the demo list.');
        return;
      }
      setStep(2);
      return;
    }
    if (step === 2) {
      if (!name.trim() || !/^\S+@\S+\.\S+$/.test(email) || mobile.replace(/\D/g, '').length < 10) {
        setError('Enter your name, a valid email address, and a 10-digit contact number.');
        return;
      }
      setStep(3);
      return;
    }
    if (step === 3) {
      setStep(4);
      return;
    }
    setReference(createDemoHealthReference('APLUS'));
  };

  return (
    <>
      <KeyboardAwareScrollViewCompat
        style={[styles.page, { backgroundColor: colors.screen }]}
        contentContainerStyle={[
          styles.content,
          { paddingTop: Math.max(topInset, 12) + 6, paddingBottom: bottomInset + 24 },
        ]}
        bottomOffset={70}
        keyboardShouldPersistTaps="handled"
      >
        <AppHeader title="A Plus Calculator" onBack={() => router.back()} />
        <View style={styles.progress}>
          {steps.map((label, index) => {
            const number = index + 1;
            const complete = number <= step;
            return (
              <React.Fragment key={label}>
                <View style={styles.progressStep}>
                  <View style={[
                    styles.stepCircle,
                    { backgroundColor: complete ? colors.primary : colors.muted },
                  ]}>
                    <Text style={[styles.stepNumber, { color: complete ? colors.white : colors.mutedForeground }]}>
                      {number}
                    </Text>
                  </View>
                  <Text style={[styles.stepLabel, { color: complete ? colors.primary : colors.mutedForeground }]}>
                    {label}
                  </Text>
                </View>
                {index < steps.length - 1 ? (
                  <View style={[styles.stepLine, { backgroundColor: number < step ? colors.primary : colors.border }]} />
                ) : null}
              </React.Fragment>
            );
          })}
        </View>

        {!reference && step === 1 ? (
          <SurfaceCard style={styles.sectionCard}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>For Adult 1</Text>
            <Text style={[styles.copy, { color: colors.mutedForeground }]}>
              Enter your pincode to begin the A Plus calculator.
            </Text>
            <DropdownField
              label="Pincode *"
              value={pincode}
              onChange={(value) => {
                setPincode(value);
                setError('');
              }}
              placeholder="Select pincode"
              options={demoPincodes}
              testID="aplus-pincode-dropdown"
            />
            <Text style={[styles.note, { color: colors.mutedForeground }]}>
              Demo pincodes only; selecting one does not verify location availability.
            </Text>
          </SurfaceCard>
        ) : null}

        {!reference && step === 2 ? (
          <SurfaceCard style={styles.sectionCard}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Proposer Details</Text>
            <LabeledInput label="Proposer Name *" value={name} onChangeText={setName} placeholder="Your name" />
            <LabeledInput
              label="Email ID *"
              value={email}
              onChangeText={setEmail}
              placeholder="Enter your email"
              keyboardType="email-address"
              autoCapitalize="none"
            />
            <LabeledInput
              label="Contact Number *"
              value={mobile}
              onChangeText={setMobile}
              placeholder="Enter contact number"
              keyboardType="phone-pad"
              maxLength={13}
            />
          </SurfaceCard>
        ) : null}

        {!reference && step === 3 ? (
          <>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Select the plan details</Text>
            <SurfaceCard style={styles.sectionCard}>
              <DropdownField
                label="Select the sum insured *"
                value={sumInsured}
                options={sumInsuredOptions}
                onChange={setSumInsured}
                testID="aplus-sum-insured-dropdown"
              />
              <View style={styles.twoColumns}>
                <View style={styles.column}>
                  <DropdownField
                    label="Select your Tenure *"
                    value={tenure}
                    options={tenureOptions}
                    onChange={setTenure}
                    compact
                    testID="aplus-tenure-dropdown"
                  />
                </View>
                <View style={styles.column}>
                  <DropdownField
                    label="Select your Plan *"
                    value={plan}
                    options={planOptions}
                    onChange={setPlan}
                    compact
                    testID="aplus-plan-dropdown"
                  />
                </View>
              </View>
            </SurfaceCard>
            <SurfaceCard style={[styles.selectedPlan, { borderColor: colors.primaryPale }]}>
              <View style={[styles.planIcon, { backgroundColor: colors.primaryWash }]}>
                <Ionicons name="ribbon" size={19} color={colors.primary} />
              </View>
              <View style={styles.planCopy}>
                <Text style={[styles.planTitle, { color: colors.primary }]}>{plan}</Text>
                <Text style={[styles.planSubTitle, { color: colors.foreground }]}>Premium amount</Text>
              </View>
              <Text style={[styles.premiumAmount, { color: colors.primary }]}>
                {quote ? `₹${quote.annualPremium.toLocaleString('en-IN')}` : 'No demo rate'}
              </Text>
            </SurfaceCard>
            <View style={styles.addOnSection}>
              <AddOnRow label="Self Add-ons details" onPress={() => setAddonOwner('Self')} />
              <AddOnRow label="Spouse Add-ons details" onPress={() => setAddonOwner('Spouse')} />
            </View>
            <Text style={[styles.note, { color: colors.mutedForeground }]}>
              Dropdown alternatives are dummy data. The ₹11,280 reference applies only to ₹10 Lakh / Silver / 1 Year; other rates and add-on prices are not provided.
            </Text>
          </>
        ) : null}

        {!reference && step === 4 ? (
          <>
            <SurfaceCard style={styles.sectionCard}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Proposer Details</Text>
              <SummaryRow label="Proposer Name" value={name} />
              <SummaryRow label="Email ID" value={email} />
              <SummaryRow label="Contact Number" value={mobile} />
            </SurfaceCard>
            <SurfaceCard style={styles.sectionCard}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Quote Details</Text>
              <SummaryRow label="Sum insured" value={sumInsured} />
              <SummaryRow label="Plan type" value={plan} />
              <SummaryRow label="Policy tenure" value={tenure} />
              {quote ? (
                <SummaryRow label="Reference premium" value={`₹${quote.annualPremium.toLocaleString('en-IN')} P.A.`} />
              ) : (
                <SummaryRow label="Reference premium" value="No reference rate for this selection" />
              )}
            </SurfaceCard>
            <View style={[styles.offlineNote, { backgroundColor: colors.primaryWash }]}>
              <Ionicons name="information-circle-outline" size={16} color={colors.primary} />
              <Text style={[styles.note, { color: colors.foreground }]}>
                This is an offline demo estimate, not an insurer quote. No policy or payment will be created.
              </Text>
            </View>
          </>
        ) : null}

        {reference ? (
          <SurfaceCard style={styles.successCard}>
            <View style={[styles.successIcon, { backgroundColor: colors.primaryWash }]}>
              <Ionicons name="checkmark" size={28} color={colors.success} />
            </View>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Details saved</Text>
            <Text style={[styles.note, { color: colors.mutedForeground }]}>
              Demo reference: {reference}. Your information has not been sent to Universal Sompo.
            </Text>
            <PrimaryButton label="Back to Home" icon="home-outline" onPress={() => router.replace('/(tabs)/home')} />
          </SurfaceCard>
        ) : null}

        {error ? <Text accessibilityRole="alert" style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
        {!reference ? (
          <View style={styles.footer}>
            <PrimaryButton
              label={step === 4 ? 'Send Details' : 'Continue'}
              icon={step === 4 ? 'send-outline' : 'chevron-forward'}
              onPress={continueStep}
            />
          </View>
        ) : null}
      </KeyboardAwareScrollViewCompat>

      <Modal
        visible={addonOwner !== null}
        transparent
        animationType="slide"
        onRequestClose={() => setAddonOwner(null)}
      >
        <View style={styles.modalBackdrop}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setAddonOwner(null)} accessibilityLabel="Close add-ons" />
          <View style={[styles.modalCard, { backgroundColor: colors.card }]}>
            <View style={styles.modalHeader}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
                {addonOwner} add-ons
              </Text>
              <Pressable onPress={() => setAddonOwner(null)} accessibilityRole="button" accessibilityLabel="Close add-ons">
                <Ionicons name="close" size={22} color={colors.destructive} />
              </Pressable>
            </View>
            <Text style={[styles.copy, { color: colors.mutedForeground }]}>
              Add-on options and prices were not included in the A Plus reference. No add-ons are selected in this offline demo.
            </Text>
            <PrimaryButton label="Close" onPress={() => setAddonOwner(null)} />
          </View>
        </View>
      </Modal>
    </>
  );
}

function DropdownField({
  label,
  value,
  options,
  onChange,
  placeholder = 'Select',
  compact = false,
  testID,
}: {
  label: string;
  value: string;
  options: readonly string[];
  onChange: (value: string) => void;
  placeholder?: string;
  compact?: boolean;
  testID: string;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [visible, setVisible] = useState(false);

  const close = () => setVisible(false);

  return (
    <>
      <View style={styles.choiceGroup}>
        <Text style={[styles.fieldLabel, { color: colors.foreground }]}>{label}</Text>
        <Pressable
          testID={testID}
          accessibilityRole="button"
          accessibilityLabel={`${label}: ${value || placeholder}`}
          accessibilityState={{ expanded: visible }}
          onPress={() => setVisible(true)}
          style={({ pressed }) => [
            styles.choiceRow,
            {
              borderColor: colors.borderStrong,
              backgroundColor: colors.card,
            },
            compact && styles.choiceRowCompact,
            pressed && styles.pressed,
          ]}
        >
          <Text
            numberOfLines={1}
            style={[styles.choiceValue, { color: value ? colors.foreground : colors.placeholder }]}
          >
            {value || placeholder}
          </Text>
          <Ionicons name="chevron-down" size={16} color={colors.foreground} />
        </Pressable>
      </View>
      <Modal
        transparent
        visible={visible}
        animationType="slide"
        onRequestClose={close}
      >
        <View style={[styles.dropdownModalBackdrop, { backgroundColor: colors.scrim }]}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={`Close ${label} options`}
            onPress={close}
            style={StyleSheet.absoluteFill}
          />
          <View
            style={[
              styles.dropdownSheet,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
                paddingBottom: Math.max(insets.bottom, 16),
              },
            ]}
          >
            <View style={styles.dropdownHeader}>
              <Text style={[styles.dropdownTitle, { color: colors.foreground }]}>{label}</Text>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`Close ${label} options`}
                onPress={close}
                hitSlop={10}
              >
                <Ionicons name="close" size={22} color={colors.mutedForeground} />
              </Pressable>
            </View>
            <ScrollView
              style={styles.dropdownOptions}
              keyboardShouldPersistTaps="handled"
              showsVerticalScrollIndicator={false}
            >
              {options.map((option, index) => (
                <Pressable
                  key={option}
                  testID={`${testID}-option-${index}`}
                  accessibilityRole="button"
                  accessibilityState={{ selected: option === value }}
                  onPress={() => {
                    onChange(option);
                    close();
                  }}
                  style={[styles.dropdownOption, { borderBottomColor: colors.border }]}
                >
                  <Text style={[styles.dropdownOptionText, { color: colors.foreground }]}>{option}</Text>
                  {option === value ? (
                    <Ionicons name="checkmark" size={19} color={colors.primary} />
                  ) : null}
                </Pressable>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </>
  );
}

function AddOnRow({ label, onPress }: { label: string; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={({ pressed }) => [
        styles.addOnRow,
        { borderColor: colors.border, backgroundColor: colors.card },
        pressed && styles.pressed,
      ]}
    >
      <View style={styles.addOnCopy}>
        <Text style={[styles.addOnTitle, { color: colors.foreground }]}>{label}</Text>
        <Text style={[styles.note, { color: colors.mutedForeground }]}>0 Add-ons selected</Text>
      </View>
      <Text style={[styles.addOnAction, { color: colors.primary, borderColor: colors.primary }]}>Select Add-ons</Text>
    </Pressable>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  const colors = useColors();
  return (
    <View style={[styles.summaryRow, { borderBottomColor: colors.border }]}>
      <Text style={[styles.summaryLabel, { color: colors.foreground }]}>{label}</Text>
      <Text style={[styles.summaryValue, { color: colors.mutedForeground }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 13, gap: 12 },
  progress: { flexDirection: 'row', alignItems: 'flex-start', paddingHorizontal: 7, marginBottom: 3 },
  progressStep: { width: 48, alignItems: 'center', gap: 4 },
  stepCircle: { width: 21, height: 21, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  stepNumber: { fontSize: 10, fontWeight: '800' },
  stepLabel: { fontSize: 7, fontWeight: '700', textAlign: 'center' },
  stepLine: { flex: 1, height: 2, marginTop: 9 },
  sectionCard: { gap: 10, padding: 12 },
  sectionTitle: { fontSize: 14, fontWeight: '800' },
  copy: { fontSize: 10, lineHeight: 15 },
  fieldLabel: { fontSize: 10, lineHeight: 14, fontWeight: '700' },
  twoColumns: { flexDirection: 'row', gap: 9 },
  column: { flex: 1, gap: 6 },
  choiceGroup: { gap: 5 },
  choiceRow: { minHeight: 39, borderWidth: 1, borderRadius: 9, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  choiceRowCompact: { minHeight: 36 },
  choiceValue: { fontSize: 9 },
  dropdownModalBackdrop: { flex: 1, justifyContent: 'flex-end' },
  dropdownSheet: { maxHeight: '72%', borderTopLeftRadius: 18, borderTopRightRadius: 18, borderWidth: 1, paddingHorizontal: 18, paddingTop: 16, gap: 8 },
  dropdownHeader: { minHeight: 34, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  dropdownTitle: { flex: 1, fontSize: 16, fontWeight: '800' },
  dropdownOptions: { flexGrow: 0 },
  dropdownOption: { minHeight: 48, paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  dropdownOptionText: { fontSize: 14, fontWeight: '600' },
  selectedPlan: { borderWidth: 1, borderRadius: 12, padding: 10, flexDirection: 'row', alignItems: 'center', gap: 8 },
  planIcon: { width: 28, height: 28, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  planCopy: { flex: 1, gap: 2 },
  planTitle: { fontSize: 11, fontWeight: '800' },
  planSubTitle: { fontSize: 9, fontWeight: '700' },
  premiumAmount: { fontSize: 12, fontWeight: '800' },
  addOnSection: { gap: 8 },
  addOnRow: { minHeight: 52, borderWidth: 1, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 7, flexDirection: 'row', alignItems: 'center', gap: 8 },
  addOnCopy: { flex: 1, gap: 3 },
  addOnTitle: { fontSize: 10, fontWeight: '700' },
  addOnAction: { fontSize: 8, fontWeight: '700', borderWidth: 1, borderRadius: 13, paddingHorizontal: 8, paddingVertical: 5 },
  summaryRow: { minHeight: 31, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  summaryLabel: { fontSize: 10, fontWeight: '600' },
  summaryValue: { flexShrink: 1, fontSize: 10, textAlign: 'right' },
  offlineNote: { padding: 10, borderRadius: 10, flexDirection: 'row', alignItems: 'flex-start', gap: 6 },
  note: { flex: 1, fontSize: 9, lineHeight: 14 },
  error: { fontSize: 10, fontWeight: '600' },
  footer: { marginTop: 'auto', paddingTop: 6 },
  successCard: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12, padding: 18 },
  successIcon: { width: 55, height: 55, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  modalBackdrop: { flex: 1, backgroundColor: 'rgba(31, 18, 23, 0.52)', justifyContent: 'flex-end' },
  modalCard: { borderTopLeftRadius: 18, borderTopRightRadius: 18, padding: 18, paddingBottom: 26, gap: 14 },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  pressed: { opacity: 0.78 },
});
