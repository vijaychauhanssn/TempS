# Universal Sompo Insurance App

Expo Router mobile app imported from the supplied project archive and updated to match the accompanying screen references.

## Start and verify

- Start the configured Expo workflow: `artifacts/sompo-insurance-mobile: expo`
- Run a TypeScript check: `pnpm --filter @workspace/sompo-insurance-mobile run typecheck`
- See [SETUP.md](./SETUP.md) for demo/API mode and configuration notes.
- See [SCREEN_INVENTORY.md](./SCREEN_INVENTORY.md) for the route and reference-screen map.

## Data and privacy

The current API server exposes a health check only. Home banners and the insurer flows therefore use local demonstration data by default. Claims, payments, quotes, renewal requests, policy details, provider directories, and member records are not sent to Universal Sompo. No production insurer API contract has been assumed.
