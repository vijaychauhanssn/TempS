export type ApiRequestOptions = {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  body?: unknown;
  signal?: AbortSignal;
  timeoutMs?: number;
  headers?: Record<string, string>;
};

export class ApiError extends Error {
  readonly status?: number;
  readonly code: 'not-configured' | 'timeout' | 'unauthorized' | 'http' | 'network' | 'invalid-response';

  constructor(
    message: string,
    code: ApiError['code'],
    status?: number,
  ) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.status = status;
  }
}

let accessTokenGetter: (() => Promise<string | null>) | null = null;

export function setAccessTokenGetter(
  getter: (() => Promise<string | null>) | null,
) {
  accessTokenGetter = getter;
}

function getBaseUrl() {
  return process.env.EXPO_PUBLIC_API_BASE_URL?.replace(/\/+$/, '') ?? '';
}

export async function apiRequest<T>(
  path: string,
  options: ApiRequestOptions = {},
): Promise<T> {
  const baseUrl = getBaseUrl();
  if (!baseUrl) {
    throw new ApiError(
      'Set EXPO_PUBLIC_API_BASE_URL and an approved endpoint before enabling live API mode.',
      'not-configured',
    );
  }
  if (!path.startsWith('/')) {
    throw new ApiError('API paths must start with a slash.', 'invalid-response');
  }

  const controller = new AbortController();
  const timeoutMs = options.timeoutMs ?? 10000;
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  const externalSignal = options.signal;
  const abortFromCaller = () => controller.abort();

  if (externalSignal?.aborted) controller.abort();
  externalSignal?.addEventListener('abort', abortFromCaller, { once: true });

  try {
    const token = await accessTokenGetter?.();
    const headers: Record<string, string> = {
      Accept: 'application/json',
      ...options.headers,
    };
    if (options.body !== undefined) headers['Content-Type'] = 'application/json';
    if (token) headers.Authorization = `Bearer ${token}`;

    const response = await fetch(`${baseUrl}${path}`, {
      method: options.method ?? 'GET',
      headers,
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
      signal: controller.signal,
    });

    if (response.status === 401) {
      throw new ApiError('Your session has expired. Sign in again to continue.', 'unauthorized', 401);
    }
    if (!response.ok) {
      throw new ApiError(`The service returned ${response.status}.`, 'http', response.status);
    }

    if (response.status === 204) return undefined as T;
    try {
      return (await response.json()) as T;
    } catch {
      throw new ApiError('The service returned an unreadable response.', 'invalid-response', response.status);
    }
  } catch (error) {
    if (error instanceof ApiError) throw error;
    if (controller.signal.aborted) {
      throw new ApiError('The request timed out or was cancelled.', 'timeout');
    }
    throw new ApiError('Could not reach the service. Check your connection and try again.', 'network');
  } finally {
    clearTimeout(timeout);
    externalSignal?.removeEventListener('abort', abortFromCaller);
  }
}
