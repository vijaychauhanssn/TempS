import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';

export default function BrandHeader() {
  return (
    <View style={styles.wrap}>
      <View style={styles.logo}><Ionicons name="shield-checkmark" size={22} color="#FFFFFF" /></View>
      <View style={{ flex: 1 }}>
        <Text style={styles.name}>Universal Sompo</Text>
        <Text style={styles.sub}>General Insurance</Text>
      </View>
      <View style={styles.badge}><Ionicons name="notifications-outline" size={21} color={colors.primary} /></View>
    </View>
  );
}
const styles = StyleSheet.create({
  wrap: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 14, gap: 10, backgroundColor: '#FFF' },
  logo: { width: 38, height: 38, borderRadius: 12, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' },
  name: { fontWeight: '800', color: colors.text, fontSize: 15 },
  sub: { color: colors.muted, fontSize: 11, marginTop: 1 },
  badge: { width: 38, height: 38, borderRadius: 20, backgroundColor: colors.roseLight, alignItems: 'center', justifyContent: 'center' },
});