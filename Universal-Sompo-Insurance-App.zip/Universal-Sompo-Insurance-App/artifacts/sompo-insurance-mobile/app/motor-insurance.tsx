import React, { useState } from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { AppHeader, AppPage, LabeledInput, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

const coverItems = [
  { label: 'Fire', icon: 'flame-outline' as const },
  { label: 'Explosion', icon: 'sunny-outline' as const },
  { label: 'Self-ignition', icon: 'flash-outline' as const },
  { label: 'Natural disasters', icon: 'thunderstorm-outline' as const },
  { label: 'Personal accident', icon: 'medkit-outline' as const },
  { label: 'Theft', icon: 'lock-closed-outline' as const },
];

const benefits = [
  { title: 'Multiple Add-on Options', detail: 'Enhanced protection as per your need.', icon: 'add-circle-outline' as const },
  { title: 'Self Inspection via smartphone', detail: 'Share a few pictures of your vehicle.', icon: 'camera-outline' as const },
  { title: 'Customizable IDV', detail: 'Choose an insured declared value that suits you.', icon: 'options-outline' as const },
  { title: 'No Claim Bonus', detail: 'Get rewarded for claim-free years.', icon: 'ribbon-outline' as const },
  { title: 'Cashless Repairs', detail: 'Use a network garage for supported repairs.', icon: 'construct-outline' as const },
  { title: '24/7 Customer Support', detail: 'Help when you need it.', icon: 'headset-outline' as const },
];

export default function MotorInsuranceScreen() {
  const colors = useColors();
  const { vehicle = 'Four Wheeler', mode = 'buy' } = useLocalSearchParams<{
    vehicle?: string;
    mode?: string;
  }>();
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [showCovered, setShowCovered] = useState(true);
  const [error, setError] = useState('');
  const isTwoWheeler = vehicle.toLowerCase().includes('two');
  const vehicleTitle = isTwoWheeler ? 'Two Wheeler' : 'Four Wheeler';
  const pageTitle = mode === 'renew' ? 'Renew Policy' : vehicleTitle;

  const getQuote = () => {
    if (vehicleNumber.trim().replace(/\s/g, '').length < 6) {
      setError('Enter a valid vehicle registration number to continue.');
      return;
    }
    setError('');
    router.push({
      pathname: '/motor-quote',
      params: { vehicle: vehicleTitle, registration: vehicleNumber.trim().toUpperCase() },
    });
  };

  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title={pageTitle} onBack={() => router.back()} />
      <View style={styles.intro}>
        <View style={styles.introCopy}>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>MOTOR INSURANCE</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>
            Cover for the road ahead.
          </Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            Comprehensive protection for your {isTwoWheeler ? 'two-wheeler' : 'car'}.
          </Text>
        </View>
        <Image
          source={require('../assets/images/motor-hero.png')}
          style={styles.heroImage}
          resizeMode="contain"
          accessibilityLabel="Cars and city illustration"
        />
      </View>

      <View style={[styles.cashless, { backgroundColor: colors.primaryWash, borderColor: colors.primaryPale }]}>
        <Ionicons name="business-outline" size={17} color={colors.primary} />
        <Text style={[styles.cashlessText, { color: colors.foreground }]}>
          13,583+ Cashless Garages PAN India
        </Text>
      </View>

      <LabeledInput
        label={isTwoWheeler ? 'Vehicle Number' : 'Vehicle Number'}
        value={vehicleNumber}
        onChangeText={(value) => setVehicleNumber(value.toUpperCase())}
        placeholder="Enter vehicle number"
        autoCapitalize="characters"
      />
      <Text style={[styles.hint, { color: colors.mutedForeground }]}>
        {isTwoWheeler ? 'Enter your bike or scooter registration number.' : 'Vehicle number must be same as the RTO number.'}
      </Text>
      {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
      <PrimaryButton label="Get Quote" icon="arrow-forward" onPress={getQuote} />
      <Pressable
        onPress={() => router.push({ pathname: '/vehicle-details', params: { vehicle: vehicleTitle } })}
        style={[styles.outline, { borderColor: colors.borderStrong }]}
      >
        <Text style={[styles.outlineText, { color: colors.foreground }]}>Got a new {isTwoWheeler ? 'bike' : 'car'}?</Text>
      </Pressable>
      <Pressable
        onPress={() => router.push({ pathname: '/motor-quote', params: { vehicle: vehicleTitle, registration: vehicleNumber || 'DEMO-01' } })}
        style={styles.resume}
      >
        <Text style={[styles.resumeText, { color: colors.primary }]}>Resume my saved journey</Text>
        <Ionicons name="arrow-forward" size={14} color={colors.primary} />
      </Pressable>

      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Know what our motor insurance offers you</Text>
        <View style={styles.toggleRow}>
          {[true, false].map((covered) => (
            <Pressable
              key={covered ? 'covered' : 'not-covered'}
              onPress={() => setShowCovered(covered)}
              style={[
                styles.toggle,
                {
                  borderBottomColor: showCovered === covered ? colors.primary : colors.border,
                },
              ]}
            >
              <Text style={[styles.toggleText, { color: showCovered === covered ? colors.primary : colors.mutedForeground }]}>
                {covered ? 'What’s Covered' : 'What’s Not Covered'}
              </Text>
            </Pressable>
          ))}
        </View>
        {showCovered ? (
          <>
            <View style={styles.coverGrid}>
              {coverItems.map((item) => (
                <View key={item.label} style={styles.coverItem}>
                  <View style={[styles.coverIcon, { backgroundColor: colors.primaryWash }]}>
                    <Ionicons name={item.icon} size={18} color={colors.primary} />
                  </View>
                  <Text style={[styles.coverLabel, { color: colors.foreground }]}>{item.label}</Text>
                </View>
              ))}
            </View>
            <View style={styles.benefitList}>
              {benefits.map((benefit) => (
                <SurfaceCard key={benefit.title} style={styles.benefitCard}>
                  <View style={[styles.benefitIcon, { backgroundColor: colors.primaryWash }]}>
                    <Ionicons name={benefit.icon} size={18} color={colors.primary} />
                  </View>
                  <View style={styles.benefitCopy}>
                    <Text style={[styles.benefitTitle, { color: colors.foreground }]}>{benefit.title}</Text>
                    <Text style={[styles.benefitDetail, { color: colors.mutedForeground }]}>{benefit.detail}</Text>
                  </View>
                </SurfaceCard>
              ))}
            </View>
          </>
        ) : (
          <SurfaceCard style={styles.exclusionCard}>
            {['Wear and tear or routine maintenance', 'Driving without a valid licence', 'Loss outside the selected policy cover'].map((item) => (
              <View key={item} style={styles.exclusionRow}>
                <Ionicons name="close-circle-outline" size={17} color={colors.destructive} />
                <Text style={[styles.benefitDetail, { color: colors.foreground }]}>{item}</Text>
              </View>
            ))}
            <Text style={[styles.hint, { color: colors.mutedForeground }]}>
              This is general demo guidance, not a policy contract.
            </Text>
          </SurfaceCard>
        )}
      </View>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 14, gap: 10 },
  intro: { minHeight: 132, flexDirection: 'row', alignItems: 'center', gap: 5 },
  introCopy: { flex: 1, gap: 5 },
  eyebrow: { fontSize: 9, fontWeight: '800', letterSpacing: 1 },
  title: { fontSize: 19, lineHeight: 23, fontWeight: '800' },
  subtitle: { fontSize: 10, lineHeight: 15 },
  heroImage: { width: '48%', height: 119 },
  cashless: { minHeight: 37, borderWidth: 1, borderRadius: 11, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 7 },
  cashlessText: { fontSize: 10, fontWeight: '800' },
  hint: { fontSize: 9, lineHeight: 14, marginTop: -6 },
  error: { fontSize: 10 },
  outline: { minHeight: 42, borderWidth: 1, borderRadius: 23, alignItems: 'center', justifyContent: 'center' },
  outlineText: { fontSize: 12, fontWeight: '700' },
  resume: { minHeight: 31, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5 },
  resumeText: { fontSize: 11, fontWeight: '800', textDecorationLine: 'underline' },
  section: { gap: 10, marginTop: 5 },
  sectionTitle: { fontSize: 14, fontWeight: '800' },
  toggleRow: { flexDirection: 'row' },
  toggle: { flex: 1, minHeight: 36, borderBottomWidth: 2, alignItems: 'center', justifyContent: 'center' },
  toggleText: { fontSize: 10, fontWeight: '800' },
  coverGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'space-between' },
  coverItem: { width: '31%', alignItems: 'center', gap: 5, minHeight: 62 },
  coverIcon: { width: 35, height: 35, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  coverLabel: { fontSize: 9, textAlign: 'center', fontWeight: '600' },
  benefitList: { gap: 7 },
  benefitCard: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 9, borderRadius: 13 },
  benefitIcon: { width: 32, height: 32, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  benefitCopy: { flex: 1, gap: 3 },
  benefitTitle: { fontSize: 10, fontWeight: '800' },
  benefitDetail: { flex: 1, fontSize: 9, lineHeight: 14 },
  exclusionCard: { gap: 10 },
  exclusionRow: { flexDirection: 'row', alignItems: 'center', gap: 7 },
});
