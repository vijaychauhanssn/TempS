import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import {
  AppHeader,
  AppPage,
  BrandLogo,
  SurfaceCard,
} from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

const services = [
  {
    title: 'Health Checkup',
    detail: 'Book a health checkup appointment, easily and stay healthy.',
    action: 'Book Now',
    icon: 'heart' as const,
    route: '/health-checkup' as const,
    tone: 'health' as const,
  },
  {
    title: 'Tele Consultation',
    detail: 'Consult with certified doctors from the comfort of your home.',
    action: 'Consult Now',
    icon: 'medkit' as const,
    route: '/tele-consultation' as const,
    tone: 'blue' as const,
  },
];

export default function KblScreen() {
  const colors = useColors();
  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="KBL Details" onBack={() => router.back()} />
      <View style={styles.brandRow}>
        <View style={styles.sompoLogo}>
          <BrandLogo width={138} />
        </View>
        <View style={[styles.bankBadge, { backgroundColor: colors.primary, borderColor: colors.primary }]}>
          <Ionicons name="business-outline" size={15} color={colors.white} />
          <Text style={[styles.bankName, { color: colors.white }]}>Karnataka Bank</Text>
        </View>
      </View>

      <View style={styles.hero}>
        <View style={styles.heroCopy}>
          <Text style={[styles.heroTitle, { color: colors.foreground }]}>
            Be healthy and take care of yourself.
          </Text>
          <Text style={[styles.heroDetail, { color: colors.mutedForeground }]}>
            As a valuable customer, explore the services shown below.
          </Text>
        </View>
        <View style={[styles.healthArtwork, { backgroundColor: colors.primaryWash }]}>
          <Ionicons name="heart" size={34} color={colors.primary} />
          <View style={[styles.healthBadge, { backgroundColor: colors.white }]}>
            <Ionicons name="medical" size={17} color={colors.primary} />
          </View>
        </View>
      </View>

      <View style={styles.serviceGrid}>
        {services.map((service) => (
          <Pressable
            key={service.title}
            accessibilityRole="button"
            accessibilityLabel={`${service.action}: ${service.title}`}
            onPress={() => router.push(service.route)}
            style={({ pressed }) => [styles.servicePressable, pressed && styles.pressed]}
          >
            <SurfaceCard style={[styles.serviceCard, { backgroundColor: colors[service.tone] }]}>
              <View style={[styles.serviceIcon, { backgroundColor: colors.white }]}>
                <Ionicons name={service.icon} size={25} color={colors.primary} />
              </View>
              <Text style={[styles.serviceTitle, { color: colors.primaryDeep }]}>{service.title}</Text>
              <Text style={[styles.serviceDetail, { color: colors.mutedForeground }]}>{service.detail}</Text>
              <View style={styles.serviceAction}>
                <Text style={[styles.actionText, { color: colors.primary }]}>{service.action}</Text>
                <Ionicons name="chevron-forward" size={14} color={colors.primary} />
              </View>
            </SurfaceCard>
          </Pressable>
        ))}
      </View>

      <Text style={[styles.note, { color: colors.mutedForeground }]}>
        These KBL health services are a local demo. No bank, doctor, or diagnostic centre is contacted.
      </Text>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 13, gap: 13 },
  brandRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 },
  sompoLogo: { flex: 1, alignItems: 'flex-start', overflow: 'hidden' },
  bankBadge: { borderWidth: 1, borderRadius: 11, paddingHorizontal: 9, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 5 },
  bankName: { fontSize: 9, fontWeight: '800' },
  hero: { minHeight: 142, flexDirection: 'row', alignItems: 'center', gap: 10 },
  heroCopy: { flex: 1, gap: 8 },
  heroTitle: { fontSize: 19, lineHeight: 24, fontWeight: '800' },
  heroDetail: { fontSize: 10, lineHeight: 15 },
  healthArtwork: { width: 91, height: 91, borderRadius: 36, alignItems: 'center', justifyContent: 'center' },
  healthBadge: { position: 'absolute', bottom: 12, right: 9, width: 31, height: 31, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  serviceGrid: { flexDirection: 'row', gap: 9 },
  servicePressable: { flex: 1 },
  serviceCard: { minHeight: 186, padding: 12, borderWidth: 0, alignItems: 'center', justifyContent: 'center', gap: 8 },
  serviceIcon: { width: 47, height: 47, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  serviceTitle: { fontSize: 11, fontWeight: '800', textAlign: 'center' },
  serviceDetail: { minHeight: 39, fontSize: 9, lineHeight: 13, textAlign: 'center' },
  serviceAction: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  actionText: { fontSize: 10, fontWeight: '800' },
  note: { fontSize: 9, lineHeight: 14, textAlign: 'center', marginTop: 3 },
  pressed: { opacity: 0.77, transform: [{ scale: 0.99 }] },
});
