import React, { useEffect, useMemo, useState } from 'react';
import { Alert, Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { AppHeader, AppPage, SurfaceCard } from '@/components/AppUI';
import { SelectField } from '@/components/FormFields';
import { useColors } from '@/hooks/useColors';

const directoryItems = [
  { name: 'Ruban Patliputra Hospital Pvt. Ltd.', address: 'Patliputra Colony, Patna, Bihar', state: 'Bihar', city: 'Patna', pincode: '800013', phone: '0612-2320446', distance: '1.2 km', rating: '4.2', category: 'Hospitals' },
  { name: 'Aryan Hospital Pvt. Ltd.', address: 'Old Railway Road, Patna, Bihar', state: 'Bihar', city: 'Patna', pincode: '800001', phone: '01240491000', distance: '1.5 km', rating: '3.9', category: 'Hospitals' },
  { name: 'Kantila Gandhi Memorial Hospital', address: 'Outer Circle Road, South Park, Jamshedpur', state: 'Jharkhand', city: 'Jamshedpur', pincode: '831001', phone: '0612-2320446', distance: '4.2 km', rating: '4.0', category: 'Hospitals' },
  { name: 'City Care Pharmacy', address: 'Boring Road, Patna, Bihar', state: 'Bihar', city: 'Patna', pincode: '800001', phone: '0612-2211000', distance: '0.8 km', rating: '4.5', category: 'Pharmacies' },
  { name: 'Sompo Network Garage', address: 'Fraser Road, Patna, Bihar', state: 'Bihar', city: 'Patna', pincode: '800001', phone: '0612-2411511', distance: '2.1 km', rating: '4.1', category: 'Network Garages' },
  { name: 'Universal Diagnostic Centre', address: 'Sector 18, Noida, Uttar Pradesh', state: 'Uttar Pradesh', city: 'Noida', pincode: '201301', phone: '0120-4510200', distance: '1.9 km', rating: '4.3', category: 'Diagnostic Labs' },
  { name: 'Patna Emergency Ambulance Service', address: 'Fraser Road, Patna, Bihar', state: 'Bihar', city: 'Patna', pincode: '800001', phone: '108', distance: '0.5 km', rating: '24/7', category: 'Ambulances' },
  { name: 'City Blood Bank', address: 'Boring Road, Patna, Bihar', state: 'Bihar', city: 'Patna', pincode: '800001', phone: '0612-2220088', distance: '1.4 km', rating: '4.4', category: 'Blood Banks' },
  { name: 'Wellness Centre Patna', address: 'Bailey Road, Patna, Bihar', state: 'Bihar', city: 'Patna', pincode: '800014', phone: '0612-2206100', distance: '2.2 km', rating: '4.2', category: 'Wellness Centers' },
  { name: 'Bharat Fuel Station', address: 'Bailey Road, Patna, Bihar', state: 'Bihar', city: 'Patna', pincode: '800014', phone: '0612-2211022', distance: '1.2 km', rating: '4.0', category: 'Petrol Pumps' },
  { name: 'Patna Auto Care', address: 'Kankarbagh, Patna, Bihar', state: 'Bihar', city: 'Patna', pincode: '800020', phone: '0612-2321222', distance: '2.7 km', rating: '4.1', category: 'Mechanics' },
  { name: 'Central City Parking', address: 'Fraser Road, Patna, Bihar', state: 'Bihar', city: 'Patna', pincode: '800001', phone: '0612-2000550', distance: '0.9 km', rating: '4.0', category: 'Parking' },
  { name: 'Patna Vehicle Emission Centre', address: 'Boring Road, Patna, Bihar', state: 'Bihar', city: 'Patna', pincode: '800001', phone: '0612-2000660', distance: '1.7 km', rating: '4.0', category: 'Pollution Centers' },
  { name: 'Universal Sompo Service Office', address: 'Exhibition Road, Patna, Bihar', state: 'Bihar', city: 'Patna', pincode: '800001', phone: '1800-22-4030', distance: '1.1 km', rating: '4.3', category: 'Branches' },
];

const serviceAliases: Record<string, string> = {
  Hospitals: 'Hospitals',
  Ambulances: 'Ambulances',
  'Blood Banks': 'Blood Banks',
  Pharmacies: 'Pharmacies',
  'Diagnostic Labs': 'Diagnostic Labs',
  'Wellness Centers': 'Wellness Centers',
  'Network Garages': 'Network Garages',
  'Petrol Pumps': 'Petrol Pumps',
  Mechanics: 'Mechanics',
  Parking: 'Parking',
  'Pollution Centers': 'Pollution Centers',
  Branches: 'Branches',
};

export default function FindHospitalsScreen() {
  const colors = useColors();
  const { category = 'Hospitals' } = useLocalSearchParams<{ category?: string }>();
  const title = serviceAliases[category] ?? 'Hospitals';
  const [stateName, setStateName] = useState('All');
  const [city, setCity] = useState('All');
  const [pincode, setPincode] = useState('All');
  useEffect(() => {
    setStateName('All');
    setCity('All');
    setPincode('All');
  }, [title]);
  const categoryItems = useMemo(() => directoryItems.filter((item) => item.category === title), [title]);
  const stateOptions = useMemo(
    () => ['All', ...Array.from(new Set(categoryItems.map((item) => item.state))).sort()],
    [categoryItems],
  );
  const cityOptions = useMemo(
    () => [
      'All',
      ...Array.from(
        new Set(categoryItems.filter((item) => stateName === 'All' || item.state === stateName).map((item) => item.city)),
      ).sort(),
    ],
    [categoryItems, stateName],
  );
  const pincodeOptions = useMemo(
    () => [
      'All',
      ...Array.from(
        new Set(
          categoryItems
            .filter((item) => (stateName === 'All' || item.state === stateName) && (city === 'All' || item.city === city))
            .map((item) => item.pincode),
        ),
      ).sort(),
    ],
    [categoryItems, city, stateName],
  );

  const filteredItems = useMemo(() => {
    return categoryItems.filter((item) =>
      (stateName === 'All' || item.state === stateName)
      && (city === 'All' || item.city === city)
      && (pincode === 'All' || item.pincode === pincode),
    );
  }, [categoryItems, city, pincode, stateName]);

  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title={title === 'Hospitals' ? 'Find Hospitals' : title} onBack={() => router.back()} />
      <Text style={[styles.intro, { color: colors.mutedForeground }]}>
        Search nearby {title.toLowerCase()} in the sample service directory.
      </Text>
      <View style={styles.filterRow}>
        <SelectField
          label="State"
          value={stateName}
          placeholder="All states"
          options={stateOptions}
          searchable={false}
          onChange={(value) => {
            setStateName(value);
            setCity('All');
            setPincode('All');
          }}
          testID="finder-state"
        />
        <SelectField
          label="City"
          value={city}
          placeholder="All cities"
          options={cityOptions}
          disabled={cityOptions.length <= 1}
          searchable={false}
          onChange={(value) => {
            setCity(value);
            setPincode('All');
          }}
          testID="finder-city"
        />
      </View>
      <SelectField
        label="Pincode"
        value={pincode}
        placeholder="All pincodes"
        options={pincodeOptions}
        disabled={pincodeOptions.length <= 1}
        searchable={false}
        onChange={setPincode}
        testID="finder-pincode"
      />

      <Text style={[styles.resultsTitle, { color: colors.foreground }]}>
        {title} near you
      </Text>
      {filteredItems.length ? (
        <View style={styles.results}>
          {filteredItems.map((item) => (
            <SurfaceCard key={item.name} style={styles.resultCard}>
              <View style={styles.resultTitleRow}>
                <View style={[styles.resultIcon, { backgroundColor: colors.primaryWash }]}>
                  <Ionicons
                    name={title === 'Network Garages' ? 'car-outline' : title === 'Pharmacies' ? 'medical-outline' : 'business-outline'}
                    size={20}
                    color={colors.primary}
                  />
                </View>
                <View style={styles.resultTitleCopy}>
                  <Text style={[styles.resultName, { color: colors.foreground }]}>{item.name}</Text>
                  <Text style={[styles.rating, { color: colors.gold }]}>★ {item.rating}</Text>
                </View>
              </View>
              <Text style={[styles.address, { color: colors.mutedForeground }]}>
                <Ionicons name="location" size={14} color={colors.primary} /> {item.address}
              </Text>
              <View style={styles.distanceRow}>
                <Pressable
                  onPress={() => void Linking.openURL(`tel:${item.phone.replace(/[^0-9+]/g, '')}`).catch(() => Alert.alert('Call', item.phone))}
                  style={[styles.actionPill, { backgroundColor: colors.primaryWash }]}
                >
                  <Ionicons name="call-outline" size={14} color={colors.primary} />
                  <Text style={[styles.phoneText, { color: colors.foreground }]}>{item.phone}</Text>
                </Pressable>
                <Text style={[styles.distance, { color: colors.mutedForeground }]}>{item.distance}</Text>
              </View>
              <View style={[styles.actions, { borderTopColor: colors.border }]}>
                <Pressable
                  onPress={() => router.push({ pathname: '/health-plan', params: { plan: 'a-plus' } })}
                  style={[styles.actionPill, { backgroundColor: colors.primaryWash }]}
                >
                  <Ionicons name="pricetag-outline" size={13} color={colors.primary} />
                  <Text style={[styles.actionText, { color: colors.primary }]}>Offers</Text>
                </Pressable>
                <Pressable
                  onPress={() => Alert.alert(item.name, `${item.address}\n${item.phone}\n\nSample directory listing; availability is not live.`)}
                  style={[styles.actionPill, { backgroundColor: colors.blue }]}
                >
                  <Text style={[styles.actionText, { color: colors.primaryDeep }]}>View details</Text>
                  <Ionicons name="chevron-forward" size={13} color={colors.primaryDeep} />
                </Pressable>
              </View>
            </SurfaceCard>
          ))}
        </View>
      ) : (
        <SurfaceCard style={styles.emptyCard}>
          <Ionicons name="search-outline" size={28} color={colors.mutedForeground} />
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No matches</Text>
          <Text style={[styles.emptyCopy, { color: colors.mutedForeground }]}>
            Try another state or city, or clear the pincode filter.
          </Text>
        </SurfaceCard>
      )}
      <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
        Sample locations only · not connected to the live provider network.
      </Text>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 14, gap: 12 },
  intro: { fontSize: 12, lineHeight: 17, marginTop: -12 },
  filterRow: { flexDirection: 'row', gap: 8 },
  resultsTitle: { fontSize: 15, fontWeight: '800', marginTop: 2 },
  results: { gap: 9 },
  resultCard: { padding: 11, gap: 8, borderRadius: 14 },
  resultTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  resultIcon: { width: 39, height: 39, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  resultTitleCopy: { flex: 1, gap: 3 },
  resultName: { fontSize: 12, lineHeight: 16, fontWeight: '800' },
  rating: { fontSize: 10, fontWeight: '700' },
  address: { fontSize: 10, lineHeight: 15 },
  distanceRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  actionPill: { minHeight: 29, borderRadius: 15, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', gap: 5 },
  phoneText: { fontSize: 10, fontWeight: '700' },
  distance: { fontSize: 10, fontWeight: '700' },
  actions: { flexDirection: 'row', justifyContent: 'space-between', borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 7 },
  actionText: { fontSize: 10, fontWeight: '700' },
  emptyCard: { alignItems: 'center', gap: 8, padding: 22 },
  emptyTitle: { fontSize: 15, fontWeight: '800' },
  emptyCopy: { fontSize: 11, textAlign: 'center' },
  disclaimer: { textAlign: 'center', fontSize: 9, lineHeight: 14 },
});
