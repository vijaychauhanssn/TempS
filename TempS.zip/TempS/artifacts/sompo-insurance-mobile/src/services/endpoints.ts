/**
 * Routes verified against the current API server.
 *
 * The server currently exposes only its health check. Product routes from the
 * reference requirements are intentionally not listed here until the insurer
 * API contract is supplied and approved.
 */
export const API_ENDPOINTS = {
  health: '/api/healthz',
} as const;

export function getConfiguredHomePath() {
  const path = process.env.EXPO_PUBLIC_HOME_API_PATH?.trim();
  return path && path.startsWith('/') ? path : undefined;
}
