import React, { PropsWithChildren } from 'react';
import {
  Image,
  ImageSourcePropType,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleProp,
  StyleSheet,
  Text,
  TextInput,
  TextInputProps,
  View,
  ViewStyle,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

type PageProps = PropsWithChildren<{
  contentStyle?: StyleProp<ViewStyle>;
  backgroundColor?: string;
  scroll?: boolean;
  refreshing?: boolean;
  onRefresh?: () => void;
}>;

export function AppPage({
  children,
  contentStyle,
  backgroundColor,
  scroll = true,
  refreshing = false,
  onRefresh,
}: PageProps) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;
  const containerStyle: StyleProp<ViewStyle> = [
    styles.pageContent,
    {
      paddingTop: topInset + 8,
      paddingBottom: bottomInset + 26,
    },
    contentStyle,
  ];

  return (
    <View
      style={[
        styles.page,
        { backgroundColor: backgroundColor ?? colors.screen },
      ]}
    >
      {scroll ? (
        <ScrollView
          style={styles.page}
          contentContainerStyle={containerStyle}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          refreshControl={
            onRefresh ? (
              <RefreshControl
                refreshing={refreshing}
                onRefresh={onRefresh}
              />
            ) : undefined
          }
        >
          {children}
        </ScrollView>
      ) : (
        <View style={[styles.pageContent, containerStyle]}>{children}</View>
      )}
    </View>
  );
}

export function BrandLogo({ width = 300 }: { width?: number }) {
  const height = width * (76 / 322);
  return (
    <Image
      source={require('../assets/images/universal-sompo-logo.png')}
      accessibilityLabel="Universal Sompo General Insurance"
      resizeMode="contain"
      style={{ width, height, alignSelf: 'center' }}
    />
  );
}

export function AppHeader({
  title,
  onBack,
  right,
}: {
  title: string;
  onBack?: () => void;
  right?: React.ReactNode;
}) {
  const colors = useColors();
  return (
    <View style={styles.header}>
      <Pressable
        onPress={onBack}
        accessibilityRole="button"
        accessibilityLabel="Go back"
        hitSlop={10}
        style={styles.headerBack}
      >
        <Ionicons name="arrow-back" size={25} color={colors.foreground} />
      </Pressable>
      <Text style={[styles.headerTitle, { color: colors.foreground }]}>
        {title}
      </Text>
      <View style={styles.headerRight}>{right}</View>
    </View>
  );
}

export function PrimaryButton({
  label,
  onPress,
  icon,
  disabled = false,
  style,
  testID,
}: {
  label: string;
  onPress: () => void;
  icon?: keyof typeof Ionicons.glyphMap;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
  testID?: string;
}) {
  const colors = useColors();
  const handlePress = () => {
    if (disabled) return;
    void Haptics.selectionAsync().catch(() => undefined);
    onPress();
  };

  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      accessibilityState={{ disabled }}
      onPress={handlePress}
      style={({ pressed }) => [
        styles.primaryButtonOuter,
        style,
        pressed && !disabled && styles.pressed,
        disabled && styles.disabled,
      ]}
    >
      <LinearGradient
        colors={[colors.primarySoft, colors.primary, colors.primaryDeep]}
        start={{ x: 0.1, y: 0 }}
        end={{ x: 0.95, y: 1 }}
        style={styles.primaryButtonInner}
      >
        <Text style={[styles.primaryButtonText, { color: colors.white }]}>
          {label}
        </Text>
        {icon ? <Ionicons name={icon} size={18} color={colors.white} /> : null}
      </LinearGradient>
    </Pressable>
  );
}

export function OutlineButton({
  label,
  onPress,
  icon,
  style,
  testID,
}: {
  label: string;
  onPress: () => void;
  icon?: keyof typeof Ionicons.glyphMap;
  style?: StyleProp<ViewStyle>;
  testID?: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      testID={testID}
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [
        styles.outlineButton,
        { borderColor: colors.primary, backgroundColor: colors.white },
        style,
        pressed && styles.pressed,
      ]}
    >
      {icon ? (
        <Ionicons name={icon} size={18} color={colors.primary} />
      ) : null}
      <Text style={[styles.outlineButtonText, { color: colors.primary }]}>
        {label}
      </Text>
    </Pressable>
  );
}

export function IconButton({
  name,
  onPress,
  color,
  label,
  badge,
}: {
  name: keyof typeof Ionicons.glyphMap;
  onPress: () => void;
  color?: string;
  label: string;
  badge?: boolean;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      hitSlop={8}
      style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}
    >
      <Ionicons name={name} size={23} color={color ?? colors.foreground} />
      {badge ? (
        <View
          style={[
            styles.notificationDot,
            { backgroundColor: colors.primary, borderColor: colors.white },
          ]}
        />
      ) : null}
    </Pressable>
  );
}

export function SurfaceCard({
  children,
  style,
}: PropsWithChildren<{ style?: StyleProp<ViewStyle> }>) {
  const colors = useColors();
  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          shadowColor: colors.shadow,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}

export function SectionHeading({
  title,
  actionLabel,
  onAction,
}: {
  title: string;
  actionLabel?: string;
  onAction?: () => void;
}) {
  const colors = useColors();
  return (
    <View style={styles.sectionHeading}>
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
        {title}
      </Text>
      {actionLabel && onAction ? (
        <Pressable onPress={onAction} hitSlop={8}>
          <Text style={[styles.actionLabel, { color: colors.primary }]}>
            {actionLabel}
          </Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export function LabeledInput({
  label,
  error,
  style,
  ...props
}: TextInputProps & { label?: string; error?: string }) {
  const colors = useColors();
  return (
    <View style={styles.inputGroup}>
      {label ? (
        <Text style={[styles.inputLabel, { color: colors.foreground }]}>
          {label}
        </Text>
      ) : null}
      <TextInput
        {...props}
        placeholderTextColor={colors.placeholder}
        style={[
          styles.input,
          {
            borderColor: error ? colors.primary : colors.borderStrong,
            color: colors.foreground,
            backgroundColor: colors.card,
          },
          style,
        ]}
      />
      {error ? (
        <Text style={[styles.inputError, { color: colors.primary }]}>
          {error}
        </Text>
      ) : null}
    </View>
  );
}

export function Avatar({
  name,
  size = 44,
  source,
}: {
  name: string;
  size?: number;
  source?: ImageSourcePropType;
}) {
  const colors = useColors();
  const initials = name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part.charAt(0).toUpperCase())
    .join('');
  const avatarSource =
    source ??
    (name === 'Saurav Sharma'
      ? require('../assets/images/profile-avatar.png')
      : undefined);

  return (
    <View
      style={[
        styles.avatar,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: colors.primaryPale,
          borderColor: colors.primary,
        },
      ]}
    >
      {avatarSource ? (
        <Image
          source={avatarSource}
          style={{ width: size - 4, height: size - 4, borderRadius: size }}
        />
      ) : (
        <Text style={[styles.avatarText, { color: colors.primary }]}>
          {initials || 'US'}
        </Text>
      )}
    </View>
  );
}

export function Hairline() {
  const colors = useColors();
  return <View style={[styles.hairline, { backgroundColor: colors.border }]} />;
}

export function HelperText({ children }: PropsWithChildren) {
  const colors = useColors();
  return (
    <Text style={[styles.helperText, { color: colors.mutedForeground }]}>
      {children}
    </Text>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  pageContent: {
    flexGrow: 1,
    paddingHorizontal: 18,
    gap: 16,
  },
  header: {
    minHeight: 48,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  headerBack: {
    width: 38,
    height: 42,
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
  headerTitle: { flex: 1, fontSize: 18, fontWeight: '700' },
  headerRight: {
    minWidth: 38,
    alignItems: 'flex-end',
    justifyContent: 'center',
  },
  primaryButtonOuter: { borderRadius: 28, overflow: 'hidden' },
  primaryButtonInner: {
    minHeight: 48,
    paddingHorizontal: 22,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 10,
  },
  primaryButtonText: {
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.15,
  },
  outlineButton: {
    minHeight: 46,
    borderWidth: 1.5,
    borderRadius: 26,
    paddingHorizontal: 18,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 8,
  },
  outlineButtonText: { fontSize: 15, fontWeight: '700' },
  pressed: { opacity: 0.78, transform: [{ scale: 0.99 }] },
  disabled: { opacity: 0.52 },
  iconButton: {
    width: 42,
    height: 42,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  notificationDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    position: 'absolute',
    right: 8,
    top: 8,
    borderWidth: 1,
  },
  card: {
    borderRadius: 18,
    borderWidth: StyleSheet.hairlineWidth,
    padding: 16,
    shadowOpacity: 0.06,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 2,
  },
  sectionHeading: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 6,
    marginBottom: 2,
  },
  sectionTitle: { fontSize: 17, fontWeight: '700' },
  actionLabel: { fontSize: 12, fontWeight: '700' },
  inputGroup: { gap: 7 },
  inputLabel: { fontSize: 14, fontWeight: '600' },
  input: {
    minHeight: 48,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderRadius: 11,
    fontSize: 15,
  },
  inputError: { fontSize: 12, fontWeight: '500' },
  avatar: {
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  avatarText: { fontSize: 15, fontWeight: '800' },
  hairline: { height: StyleSheet.hairlineWidth, width: '100%' },
  helperText: { fontSize: 12, lineHeight: 17 },
});
