import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppHeader, AppPage, SurfaceCard } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

const questions = [
  {
    question: 'Can I view my insurance policy here?',
    answer: 'The reference app includes an Insurance Vault. This demo has no live policy connection, so you can explore the empty state and sample navigation only.',
  },
  {
    question: 'How does OTP login work?',
    answer: 'OTP verification is simulated on this device. Tap Send OTP and enter 123456. No SMS or email is sent.',
  },
  {
    question: 'Where are my profile details stored?',
    answer: 'Profile details are saved locally on this device using app storage. They are not sent to Universal Sompo or another service.',
  },
  {
    question: 'How do I contact support?',
    answer: 'Open Contact Us to call one of the toll-free numbers or compose an email to the address shown in the reference screens.',
  },
];

export default function FaqScreen() {
  const colors = useColors();
  const [expanded, setExpanded] = useState<number | null>(0);
  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="FAQ" onBack={() => router.back()} />
      <View style={styles.heading}>
        <Text style={[styles.title, { color: colors.foreground }]}>
          Frequently asked questions
        </Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Answers about this demo app.
        </Text>
      </View>
      <View style={styles.list}>
        {questions.map((item, index) => {
          const isOpen = expanded === index;
          return (
            <Pressable
              key={item.question}
              onPress={() => setExpanded(isOpen ? null : index)}
              accessibilityRole="button"
              accessibilityState={{ expanded: isOpen }}
            >
              <SurfaceCard style={styles.item}>
                <View style={styles.questionRow}>
                  <Text style={[styles.question, { color: colors.foreground }]}>
                    {item.question}
                  </Text>
                  <Ionicons
                    name={isOpen ? 'chevron-up' : 'chevron-down'}
                    size={18}
                    color={colors.primary}
                  />
                </View>
                {isOpen ? (
                  <Text style={[styles.answer, { color: colors.mutedForeground }]}>
                    {item.answer}
                  </Text>
                ) : null}
              </SurfaceCard>
            </Pressable>
          );
        })}
      </View>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 16, gap: 16 },
  heading: { gap: 5 },
  title: { fontSize: 22, fontWeight: '800' },
  subtitle: { fontSize: 12 },
  list: { gap: 9 },
  item: { gap: 10, padding: 14 },
  questionRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  question: { flex: 1, fontSize: 13, lineHeight: 18, fontWeight: '700' },
  answer: { fontSize: 12, lineHeight: 18 },
});
