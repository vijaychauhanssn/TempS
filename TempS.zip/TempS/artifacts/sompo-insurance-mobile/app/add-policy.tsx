import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppHeader, AppPage, SurfaceCard } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

const options = [
  { title: 'Motor', detail: 'Car or two-wheeler insurance', icon: 'car-sport-outline' as const, color: 'vehicle' },
  { title: 'Health', detail: 'Individual or family health cover', icon: 'heart-outline' as const, color: 'health' },
  { title: 'Add Other Policy', detail: 'Link an existing policy account', icon: 'document-text-outline' as const, color: 'blue' },
  { title: 'Super Healthcare', detail: 'Explore enhanced health cover', icon: 'medkit-outline' as const, color: 'gold' },
  { title: 'Non-USGIC Policy', detail: 'Add a policy from another provider', icon: 'shield-outline' as const, color: 'pink' },
] as const;

export default function AddPolicyScreen() {
  const colors = useColors();
  const open = (title: (typeof options)[number]['title']) => {
    if (title === 'Motor') router.push('/motor-insurance?vehicle=Four%20Wheeler');
    else if (title === 'Health') router.push('/health-buy?plan=complete');
    else if (title === 'Super Healthcare') router.push('/health-plan?plan=super');
    else router.push({ pathname: '/kbl-details', params: { action: 'link', claimType: title } });
  };

  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title="Add Policy" onBack={() => router.back()} />
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
        Choose a policy type to explore or link it to your local demo vault.
      </Text>
      <View style={styles.options}>
        {options.map((option, index) => (
          <Pressable
            key={option.title}
            onPress={() => open(option.title)}
            style={({ pressed }) => [pressed && styles.pressed]}
          >
            <SurfaceCard style={styles.optionCard}>
              <View style={[styles.optionIcon, { backgroundColor: colors[option.color] }]}>
                <Ionicons name={option.icon} size={23} color={colors.primaryDeep} />
              </View>
              <View style={styles.optionCopy}>
                <Text style={[styles.optionTitle, { color: colors.foreground }]}>{option.title}</Text>
                <Text style={[styles.optionDetail, { color: colors.mutedForeground }]}>{option.detail}</Text>
              </View>
              <View style={[styles.arrow, { backgroundColor: index % 2 === 0 ? colors.primary : colors.primaryPale }]}>
                <Ionicons name="chevron-forward" size={16} color={index % 2 === 0 ? colors.white : colors.primary} />
              </View>
            </SurfaceCard>
          </Pressable>
        ))}
      </View>
      <View style={[styles.tip, { backgroundColor: colors.primaryWash }]}>
        <Ionicons name="information-circle-outline" size={18} color={colors.primary} />
        <Text style={[styles.tipText, { color: colors.foreground }]}>
          Linked account details are stored only on this device in this demo.
        </Text>
      </View>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 14, gap: 13 },
  subtitle: { fontSize: 12, lineHeight: 17, marginTop: -11 },
  options: { gap: 9 },
  optionCard: { minHeight: 66, padding: 9, flexDirection: 'row', alignItems: 'center', gap: 9, borderRadius: 14 },
  optionIcon: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  optionCopy: { flex: 1, gap: 3 },
  optionTitle: { fontSize: 13, fontWeight: '800' },
  optionDetail: { fontSize: 10, lineHeight: 14 },
  arrow: { width: 29, height: 29, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  tip: { borderRadius: 12, padding: 11, flexDirection: 'row', alignItems: 'center', gap: 8 },
  tipText: { flex: 1, fontSize: 10, lineHeight: 15 },
  pressed: { opacity: 0.75 },
});
