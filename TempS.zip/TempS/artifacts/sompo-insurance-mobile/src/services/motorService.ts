export type MotorServiceMode = 'demo-local';

export const motorService = {
  getMode(): MotorServiceMode {
    return 'demo-local';
  },
};
