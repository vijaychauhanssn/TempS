import React, { useRef, useState } from 'react';
import {
  KeyboardTypeOptions,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import {
  AppHeader,
  BrandLogo,
  HelperText,
  LabeledInput,
  PrimaryButton,
} from '@/components/AppUI';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

type LoginMethod =
  | 'Corporate ID'
  | 'Mobile Number'
  | 'Email ID'
  | 'UHID No.'
  | 'Employee ID & DOB';
const methods: LoginMethod[] = [
  'Corporate ID',
  'Mobile Number',
  'Email ID',
  'UHID No.',
  'Employee ID & DOB',
];

export default function LoginScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { completeLogin } = useAppState();
  const [method, setMethod] = useState<LoginMethod>('Mobile Number');
  const [pickerOpen, setPickerOpen] = useState(false);
  const [value, setValue] = useState('');
  const [dob, setDob] = useState('');
  const [otp, setOtp] = useState<string[]>(['', '', '', '', '', '']);
  const [otpSent, setOtpSent] = useState(false);
  const [message, setMessage] = useState('');
  const otpRefs = useRef<(TextInput | null)[]>([]);
  const requiresOtp = method === 'Mobile Number' || method === 'Email ID';
  const needsDob = method === 'UHID No.' || method === 'Employee ID & DOB';
  const keyboardType: KeyboardTypeOptions =
    method === 'Mobile Number' ? 'phone-pad' : 'default';

  const selectMethod = (nextMethod: LoginMethod) => {
    setMethod(nextMethod);
    setValue('');
    setDob('');
    setOtp(['', '', '', '', '', '']);
    setOtpSent(false);
    setMessage('');
    setPickerOpen(false);
  };

  const sendOtp = () => {
    if (
      method === 'Mobile Number' &&
      value.replace(/\D/g, '').length !== 10
    ) {
      setMessage('Enter a valid 10-digit mobile number first.');
      return;
    }
    if (
      method === 'Email ID' &&
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim())
    ) {
      setMessage('Enter a valid email address first.');
      return;
    }
    setMessage('Demo OTP sent. Enter 123456 to continue.');
    setOtpSent(true);
    otpRefs.current[0]?.focus();
  };

  const submit = async () => {
    setMessage('');
    if (!value.trim()) {
      setMessage(
        method === 'Mobile Number'
          ? 'Enter your mobile number.'
          : method === 'Email ID'
            ? 'Enter your email address.'
              : method === 'UHID No.'
              ? 'Enter your registered UHID number.'
                : method === 'Corporate ID'
                  ? 'Enter your corporate ID.'
                  : 'Enter your employee ID.',
      );
      return;
    }
    if (needsDob && !dob.trim()) {
      setMessage('Enter your date of birth to continue.');
      return;
    }
    if (requiresOtp && !otpSent) {
      setMessage('Request an OTP before verifying.');
      return;
    }
    if (requiresOtp && otp.join('') !== '123456') {
      setMessage('The demo code is 123456. Please try again.');
      return;
    }
    await completeLogin();
    router.replace('/(tabs)/home');
  };

  const updateDigit = (index: number, digit: string) => {
    const cleanDigit = digit.replace(/\D/g, '').slice(-1);
    setOtp((current) => current.map((item, i) => (i === index ? cleanDigit : item)));
    if (cleanDigit && index < otpRefs.current.length - 1) {
      otpRefs.current[index + 1]?.focus();
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.screen }]}>
      <KeyboardAwareScrollViewCompat
        style={styles.scroll}
        contentContainerStyle={[
          styles.content,
          {
            paddingTop: (insets.top || 0) + (insets.top === 0 ? 67 : 12),
            paddingBottom: (insets.bottom || 0) + 24,
          },
        ]}
        keyboardShouldPersistTaps="handled"
        bottomOffset={24}
      >
        <AppHeader title="Login" onBack={() => router.back()} />
        <BrandLogo width={292} />
        <View style={styles.welcome}>
          <Text style={[styles.welcomeText, { color: colors.foreground }]}>
            Welcome to{' '}
          </Text>
          <Text style={[styles.brandText, { color: colors.primary }]}>
            Universal Sompo
          </Text>
        </View>
        <View
          style={[
            styles.formPanel,
            {
              backgroundColor: colors.white,
              borderColor: colors.border,
              shadowColor: colors.shadow,
            },
          ]}
        >
          <Text style={[styles.formTitle, { color: colors.foreground }]}>
            {method === 'Mobile Number' || method === 'Email ID'
              ? 'Log In'
              : 'Login with Registered Details'}
          </Text>
          <Pressable
            onPress={() => setPickerOpen(true)}
            style={styles.methodPicker}
            accessibilityRole="button"
            accessibilityLabel={`Login method: ${method}. Choose another method`}
          >
            <Text style={[styles.methodText, { color: colors.primary }]}>
              {method}
            </Text>
            <Ionicons name="chevron-down" size={17} color={colors.primary} />
          </Pressable>
          <LabeledInput
            label={
              method === 'Mobile Number'
                ? 'Enter your mobile number'
                : method === 'Email ID'
                  ? 'Enter your registered email ID'
                  : method === 'Corporate ID'
                    ? 'Corporate ID'
                  : method === 'UHID No.'
                    ? 'UHID No.'
                    : 'Employee ID'
            }
            placeholder={
              method === 'Mobile Number'
                ? '+91  Enter your mobile number'
                : method === 'Email ID'
                  ? 'Enter your e-mail ID'
                  : method === 'Corporate ID'
                    ? 'Enter your corporate ID'
                  : method === 'UHID No.'
                    ? 'Enter your UHID number'
                    : 'Enter employee ID'
            }
            value={value}
            onChangeText={(text) => {
              setValue(text);
              setMessage('');
            }}
            keyboardType={keyboardType}
            autoCapitalize={method === 'Email ID' ? 'none' : 'characters'}
            testID="login-identifier"
          />
          {needsDob ? (
            <LabeledInput
              label="DOB (dd-mm-yyyy)"
              placeholder="DD-MM-YYYY"
              value={dob}
              onChangeText={setDob}
              keyboardType="numbers-and-punctuation"
              testID="login-dob"
            />
          ) : null}
          {requiresOtp ? (
            <>
              <Pressable
                onPress={sendOtp}
                accessibilityRole="button"
                style={[
                  styles.sendOtp,
                  { borderColor: colors.primary, backgroundColor: colors.white },
                ]}
              >
                <Text style={[styles.sendOtpText, { color: colors.primary }]}>
                  {otpSent ? 'Resend OTP' : 'Send OTP'}
                </Text>
              </Pressable>
              <Text style={[styles.otpLabel, { color: colors.foreground }]}>
                {otpSent
                  ? `Enter the 6-digit code sent to your ${method === 'Email ID' ? 'email' : 'mobile'}`
                  : `We'll send an OTP through ${method === 'Email ID' ? 'email' : 'SMS'}`}
              </Text>
              <View style={styles.otpRow}>
                {otp.map((digit, index) => (
                  <TextInput
                    key={`otp-${index}`}
                    ref={(node) => {
                      otpRefs.current[index] = node;
                    }}
                    value={digit}
                    onChangeText={(text) => updateDigit(index, text)}
                    onKeyPress={({ nativeEvent }) => {
                      if (
                        nativeEvent.key === 'Backspace' &&
                        !otp[index] &&
                        index > 0
                      ) {
                        otpRefs.current[index - 1]?.focus();
                      }
                    }}
                    keyboardType="number-pad"
                    maxLength={1}
                    selectTextOnFocus
                    accessibilityLabel={`OTP digit ${index + 1}`}
                    style={[
                      styles.otpBox,
                      {
                        borderColor: digit ? colors.primary : colors.borderStrong,
                        color: colors.foreground,
                        backgroundColor: colors.white,
                      },
                    ]}
                  />
                ))}
              </View>
            </>
          ) : null}
          {message ? (
            <Text
              accessibilityRole="alert"
              style={[
                styles.message,
                {
                  color: message.startsWith('Demo OTP')
                    ? colors.success
                    : colors.primary,
                },
              ]}
            >
              {message}
            </Text>
          ) : null}
          <HelperText>
            This is a local demo; verification is simulated and no OTP is sent.
          </HelperText>
          <PrimaryButton
            label={requiresOtp ? 'Verify' : 'Confirm'}
            icon="chevron-forward"
            onPress={() => void submit()}
            style={styles.confirmButton}
            testID="login-confirm"
          />
        </View>
      </KeyboardAwareScrollViewCompat>

      <Modal
        transparent
        animationType="fade"
        visible={pickerOpen}
        onRequestClose={() => setPickerOpen(false)}
      >
        <Pressable
          style={[styles.scrim, { backgroundColor: colors.scrim }]}
          onPress={() => setPickerOpen(false)}
        >
          <View
            style={[
              styles.methodSheet,
              { backgroundColor: colors.white, borderColor: colors.primaryPale },
            ]}
          >
            <Text style={[styles.sheetTitle, { color: colors.foreground }]}>
              Choose a login method
            </Text>
            {methods.map((item) => (
              <Pressable
                key={item}
                onPress={() => selectMethod(item)}
                style={[
                  styles.methodOption,
                  { borderColor: colors.border },
                  item === method && { backgroundColor: colors.primaryWash },
                ]}
              >
                <Text
                  style={[
                    styles.methodOptionText,
                    { color: item === method ? colors.primary : colors.foreground },
                  ]}
                >
                  {item}
                </Text>
                {item === method ? (
                  <Ionicons name="checkmark-circle" size={20} color={colors.primary} />
                ) : (
                  <Ionicons name="chevron-forward" size={18} color={colors.mutedForeground} />
                )}
              </Pressable>
            ))}
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { flex: 1 },
  content: {
    paddingHorizontal: 18,
    gap: 15,
    flexGrow: 1,
  },
  welcome: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    alignItems: 'center',
    paddingBottom: 4,
  },
  welcomeText: { fontSize: 19, fontWeight: '600' },
  brandText: { fontSize: 19, fontWeight: '800' },
  formPanel: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    borderWidth: StyleSheet.hairlineWidth,
    padding: 20,
    gap: 17,
    flexGrow: 1,
    shadowOpacity: 0.05,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: -4 },
  },
  formTitle: { fontSize: 22, fontWeight: '800', textAlign: 'center' },
  methodPicker: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingVertical: 1,
  },
  methodText: { fontSize: 13, fontWeight: '700' },
  sendOtp: {
    alignSelf: 'flex-end',
    borderWidth: 1,
    borderRadius: 18,
    paddingHorizontal: 14,
    paddingVertical: 7,
    marginTop: -7,
  },
  sendOtpText: { fontSize: 12, fontWeight: '700' },
  otpLabel: { fontSize: 13, fontWeight: '600', marginTop: -6 },
  otpRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 7 },
  otpBox: {
    flex: 1,
    maxWidth: 46,
    height: 48,
    borderWidth: 1.2,
    borderRadius: 11,
    textAlign: 'center',
    fontSize: 19,
    fontWeight: '700',
  },
  message: { fontSize: 13, fontWeight: '600', lineHeight: 18 },
  confirmButton: { marginTop: 'auto' },
  scrim: {
    flex: 1,
    justifyContent: 'flex-end',
    padding: 16,
  },
  methodSheet: {
    padding: 18,
    borderRadius: 22,
    borderWidth: 1,
    gap: 10,
  },
  sheetTitle: { fontSize: 18, fontWeight: '800', marginBottom: 3 },
  methodOption: {
    minHeight: 48,
    borderWidth: 1,
    borderRadius: 13,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  methodOptionText: { fontSize: 14, fontWeight: '600' },
});
