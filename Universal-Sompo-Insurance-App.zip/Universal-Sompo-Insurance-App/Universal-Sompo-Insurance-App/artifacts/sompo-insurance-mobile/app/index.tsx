import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useAppState } from '@/context/AppState';
import { BrandLogo } from '@/components/AppUI';

const slides = [
  {
    eyebrow: '“Protect What Matters Most”',
    title: 'Welcome',
    body: 'Your all-in-one insurance solution for life, health, vehicle & more.',
    image: require('../assets/images/onboarding-welcome.png'),
  },
  {
    eyebrow: '“Insurance Made Simple”',
    title: 'Fast, secure & hassle-free',
    body: 'Protection for everything you love.',
    image: require('../assets/images/onboarding-simple.png'),
  },
  {
    eyebrow: '“Your Safety, Our Priority”',
    title: 'Trusted coverage anytime, anywhere.',
    body: 'Support and protection, wherever life takes you.',
    image: require('../assets/images/onboarding-safety.png'),
  },
];

function AppLoadingScreen() {
  const colors = useColors();
  const { width, height } = useWindowDimensions();
  const icons: {
    name: keyof typeof Ionicons.glyphMap;
    size: number;
    color: string;
    backgroundColor: string;
    offset: number;
  }[] = [
    { name: 'heart', size: 17, color: colors.primary, backgroundColor: colors.rose, offset: 14 },
    { name: 'document-text', size: 18, color: '#2994c7', backgroundColor: colors.blue, offset: 4 },
    { name: 'shield-checkmark', size: 28, color: colors.primary, backgroundColor: colors.pink, offset: 0 },
    { name: 'fitness', size: 17, color: '#c8103d', backgroundColor: colors.rose, offset: 7 },
    { name: 'car-sport', size: 18, color: '#c28a00', backgroundColor: '#fff0c1', offset: 15 },
  ];

  return (
    <LinearGradient
      colors={['#fff9fb', '#fff0f3', '#f9dfe6']}
      locations={[0, 0.56, 1]}
      style={styles.loadingScreen}
    >
      <View
        style={[
          styles.loadingLogo,
          {
            top: Math.max(150, height * 0.47),
            width: Math.min(width * 0.78, 310),
          },
        ]}
      >
        <BrandLogo width={Math.min(width * 0.78, 310)} />
      </View>
      <View
        accessibilityLabel="Insurance services"
        style={[
          styles.loadingIcons,
          {
            bottom: Math.max(78, height * 0.14),
            width: Math.min(width * 0.86, 340),
          },
        ]}
      >
        {icons.map((item, index) => {
          const bubbleSize = index === 2 ? 58 : index === 1 ? 46 : 40;
          return (
            <View
              key={item.name}
              style={[
                styles.loadingBubble,
                {
                  width: bubbleSize,
                  height: bubbleSize,
                  borderRadius: bubbleSize / 2,
                  marginBottom: item.offset,
                  backgroundColor: item.backgroundColor,
                  shadowColor: colors.shadow,
                },
              ]}
            >
              <Ionicons name={item.name} size={item.size} color={item.color} />
            </View>
          );
        })}
      </View>
      <ActivityIndicator
        accessibilityLabel="Loading"
        size="small"
        color={colors.primary}
        style={[
          styles.loadingIndicator,
          { bottom: Math.max(27, height * 0.055) },
        ]}
      />
    </LinearGradient>
  );
}

export default function OnboardingScreen() {
  const [step, setStep] = useState(0);
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { isReady, hasSession } = useAppState();
  const webTop = Platform.OS === 'web' ? 67 : insets.top;
  const webBottom = Platform.OS === 'web' ? 34 : insets.bottom;
  const slide = slides[step];

  useEffect(() => {
    if (isReady && hasSession) router.replace('/(tabs)/home');
  }, [hasSession, isReady]);

  if (!isReady || hasSession) {
    return <AppLoadingScreen />;
  }

  const finish = () => router.replace('/welcome');
  const next = () => (step < slides.length - 1 ? setStep(step + 1) : finish());

  return (
    <LinearGradient
      colors={[colors.screen, colors.primaryPale, colors.primaryWash]}
      locations={[0, 0.68, 1]}
      style={[
        styles.container,
        {
          paddingTop: webTop + 8,
          paddingBottom: webBottom + 16,
        },
      ]}
    >
      <View style={styles.logoWrap}>
        <BrandLogo width={Math.min(318, 0.88 * 390)} />
      </View>
      <View style={styles.copy}>
        <Text style={[styles.eyebrow, { color: colors.mutedForeground }]}>
          {slide.eyebrow}
        </Text>
        <Text style={[styles.title, { color: colors.primaryDeep }]}>
          {slide.title}
        </Text>
        <Text style={[styles.body, { color: colors.foreground }]}>
          {slide.body}
        </Text>
      </View>
      <Image
        source={slide.image}
        resizeMode="contain"
        style={styles.illustration}
        accessibilityLabel="Insurance protection illustration"
      />
      <View style={styles.controls}>
        <Pressable onPress={finish} hitSlop={12} accessibilityRole="button">
          <Text style={[styles.skip, { color: colors.primaryDeep }]}>Skip</Text>
        </Pressable>
        <View style={styles.dots}>
          {slides.map((item, index) => (
            <View
              key={item.title}
              style={[
                styles.dot,
                {
                  backgroundColor:
                    index === step ? colors.primary : colors.white,
                  width: index === step ? 32 : 20,
                },
              ]}
            />
          ))}
        </View>
        <Pressable
          onPress={next}
          accessibilityRole="button"
          accessibilityLabel={step === slides.length - 1 ? 'Get started' : 'Next'}
          testID="onboarding-next"
          style={({ pressed }) => [
            styles.nextButtonOuter,
            { borderColor: colors.primary },
            pressed && styles.pressed,
          ]}
        >
          <View style={[styles.nextButton, { backgroundColor: colors.primary }]}>
            <Ionicons
              name={step === slides.length - 1 ? 'checkmark' : 'arrow-forward'}
              size={22}
              color={colors.white}
            />
          </View>
        </Pressable>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  loadingScreen: { flex: 1, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  loadingLogo: { position: 'absolute', alignSelf: 'center', transform: [{ translateY: -32 }] },
  loadingIcons: { position: 'absolute', alignSelf: 'center', flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', paddingHorizontal: 4 },
  loadingBubble: { alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#ffffff', shadowOpacity: 0.16, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 3 },
  loadingIndicator: { position: 'absolute' },
  container: {
    flex: 1,
    paddingHorizontal: 18,
    justifyContent: 'space-between',
    gap: 8,
  },
  logoWrap: { height: 62, justifyContent: 'center' },
  copy: { alignItems: 'center', paddingHorizontal: 6, gap: 8 },
  eyebrow: { fontSize: 16, textAlign: 'center' },
  title: {
    fontSize: 32,
    fontWeight: '800',
    lineHeight: 38,
    textAlign: 'center',
  },
  body: {
    fontSize: 18,
    lineHeight: 25,
    fontWeight: '500',
    textAlign: 'center',
  },
  illustration: {
    flex: 1,
    width: '100%',
    maxHeight: 330,
    alignSelf: 'center',
    marginVertical: 4,
  },
  controls: {
    minHeight: 62,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  skip: { fontSize: 14, fontWeight: '600', minWidth: 50 },
  dots: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  dot: { height: 9, borderRadius: 8 },
  nextButtonOuter: {
    width: 58,
    height: 58,
    borderWidth: 1.5,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  nextButton: {
    width: 44,
    height: 44,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pressed: { opacity: 0.76, transform: [{ scale: 0.96 }] },
});
