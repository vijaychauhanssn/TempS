import React, { useEffect } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { KeyboardProvider } from 'react-native-keyboard-controller';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { AppStateProvider } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';
import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from '@expo-google-fonts/inter';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

function RootLayoutNav() {
  const colors = useColors();
  return (
    <Stack
      screenOptions={{
        headerShown: false,
        headerBackTitle: 'Back',
        contentStyle: { backgroundColor: colors.screen },
        animation: 'slide_from_right',
      }}
    >
      <Stack.Screen name="index" options={{ animation: 'fade' }} />
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="welcome" />
      <Stack.Screen name="login" />
      <Stack.Screen name="register" />
      <Stack.Screen name="profile" />
      <Stack.Screen name="profile-edit" />
      <Stack.Screen name="notifications" />
      <Stack.Screen name="resources" />
      <Stack.Screen name="contact" />
      <Stack.Screen name="calculator" />
      <Stack.Screen name="a-plus-calculator" />
      <Stack.Screen name="faq" />
      <Stack.Screen name="insurance" />
      <Stack.Screen name="add-policy" />
      <Stack.Screen name="policy-detail" />
      <Stack.Screen name="policy-renewal" />
      <Stack.Screen name="motor-insurance" />
      <Stack.Screen name="my-vehicle" />
      <Stack.Screen name="my-challan" />
      <Stack.Screen name="pollution-certificate" />
      <Stack.Screen name="stepathon" />
      <Stack.Screen name="be-fit" />
      <Stack.Screen name="vehicle-details" />
      <Stack.Screen name="motor-quote" />
      <Stack.Screen name="health-plan" />
      <Stack.Screen name="health-buy" />
      <Stack.Screen name="claims" />
      <Stack.Screen name="service-request" />
      <Stack.Screen name="claim-action" />
      <Stack.Screen name="kbl-details" />
      <Stack.Screen name="kbl" />
      <Stack.Screen name="health-checkup" />
      <Stack.Screen name="tele-consultation" />
      <Stack.Screen name="renewal" />
      <Stack.Screen name="find-hospitals" />
      <Stack.Screen name="webinar" />
    </Stack>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <GestureHandlerRootView style={{ flex: 1 }}>
            <KeyboardProvider>
              <AppStateProvider>
                <StatusBar style="dark" />
                <RootLayoutNav />
              </AppStateProvider>
            </KeyboardProvider>
          </GestureHandlerRootView>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
