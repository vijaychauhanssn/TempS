import React, { useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { Image, Modal, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { AppHeader, LabeledInput, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { DatePickerField, isValidDateValue } from '@/components/FormFields';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useAppState } from '@/context/AppState';
import type { UserPolicy } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const RENEWALS_KEY = 'universal-sompo:renewal-requests';
const addOnOptions = [
  { id: 'hospital-cash', name: 'Daily hospital cash cover', price: 200 },
  { id: 'critical-illness', name: 'Critical illness cover', price: 3000 },
  { id: 'pre-hospitalization', name: 'Extension under pre-hospitalization', price: 470 },
  { id: 'maternity', name: 'Maternity and childcare benefit', price: 470 },
];

export default function PolicyRenewalScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { policyId = '', category: requestedCategory = '' } = useLocalSearchParams<{ policyId?: string; category?: string }>();
  const { profile, policies } = useAppState();
  const motorPolicies = policies.filter((item) => item.category === 'Motor');
  const [selectedPolicyId, setSelectedPolicyId] = useState(policyId);
  const selectedPolicy = policies.find((item) => item.id === selectedPolicyId)
    ?? policies.find((item) => item.category === (requestedCategory === 'Motor' ? 'Motor' : 'Health'));
  const isMotor = selectedPolicy?.category === 'Motor' || (!selectedPolicy && requestedCategory === 'Motor');
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [showPolicyPicker, setShowPolicyPicker] = useState(false);
  const [showKycComplete, setShowKycComplete] = useState(false);
  const [policyNumber, setPolicyNumber] = useState(selectedPolicy?.policyNumber ?? '');
  const [email, setEmail] = useState(profile.email);
  const [dateOfBirth, setDateOfBirth] = useState(profile.dateOfBirth);
  const [idType, setIdType] = useState('Aadhaar');
  const [idNumber, setIdNumber] = useState('');
  const [mobile, setMobile] = useState(profile.mobile);
  const [kycChanged, setKycChanged] = useState<boolean | null>(null);
  const [consent, setConsent] = useState(false);
  const [sumInsured, setSumInsured] = useState('₹5,00,000');
  const [tenure, setTenure] = useState(1);
  const [plan, setPlan] = useState('Package One');
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([]);
  const [paymentMethod, setPaymentMethod] = useState('UPI');
  const [error, setError] = useState('');
  const [savedMessage, setSavedMessage] = useState('');
  const topInset = Platform.OS === 'web' ? Math.max(insets.top, 67) : insets.top;
  const bottomInset = Platform.OS === 'web' ? 34 : insets.bottom;

  const addOnTotal = useMemo(
    () => addOnOptions.reduce((total, option) => total + (selectedAddOns.includes(option.id) ? option.price : 0), 0),
    [selectedAddOns],
  );
  const basePremium = (sumInsured === '₹10,00,000' ? 7200 : 5000) * tenure;
  const discount = plan === 'Package Two' ? 400 : 0;
  const netPremium = basePremium + addOnTotal - discount;
  const gst = Math.round(netPremium * 0.18);
  const totalPayable = netPremium + gst;

  const saveRenewal = async (category: 'Health' | 'Motor', number: string) => {
    try {
      const previousValue = await AsyncStorage.getItem(RENEWALS_KEY);
      const previous = previousValue ? JSON.parse(previousValue) : [];
      const requests = Array.isArray(previous) ? previous : [];
      requests.unshift({
        reference: `RN-${Date.now().toString().slice(-7)}`,
        policyId: selectedPolicy?.id ?? null,
        policyNumber: number,
        category,
        plan: category === 'Health' ? plan : 'Existing motor cover',
        totalPayable: category === 'Health' ? totalPayable : null,
        savedAt: new Date().toISOString(),
        status: 'Saved locally — not submitted to insurer',
      });
      await AsyncStorage.setItem(RENEWALS_KEY, JSON.stringify(requests.slice(0, 20)));
      setSavedMessage('Renewal details saved on this device. They have not been sent to the insurer.');
      setError('');
    } catch {
      setError('Could not save the renewal details on this device.');
    }
  };

  const submitMotorRenewal = () => {
    if (!policyNumber.trim()) {
      setError('Enter or select a policy number.');
      return;
    }
    void saveRenewal('Motor', policyNumber.trim());
  };

  const verifyKyc = () => {
    const validEmail = /^\S+@\S+\.\S+$/.test(email.trim());
    const validMobile = mobile.replace(/\D/g, '').length >= 10;
    if (!policyNumber.trim() || !validEmail || !isValidDateValue(dateOfBirth) || idNumber.trim().length < 4 || !validMobile) {
      setError('Complete each field with a valid policy number, email, date of birth, ID number and mobile number.');
      return;
    }
    if (kycChanged === null || !consent) {
      setError('Answer the KYC change question and accept the consent to continue.');
      return;
    }
    setError('');
    setShowKycComplete(true);
  };

  const toggleAddOn = (id: string) => {
    setSelectedAddOns((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  };

  const openPolicy = (policy: UserPolicy) => {
    setSelectedPolicyId(policy.id);
    setPolicyNumber(policy.policyNumber);
    setShowPolicyPicker(false);
  };

  const pageTitle = isMotor ? 'Policy Renew' : 'Complete Healthcare Insurance';

  return (
    <>
      <KeyboardAwareScrollViewCompat
        style={[styles.page, { backgroundColor: colors.screen }]}
        contentContainerStyle={[styles.content, { paddingTop: topInset + 8, paddingBottom: bottomInset + 24 }]}
        bottomOffset={72}
        keyboardShouldPersistTaps="handled"
      >
        <AppHeader title={pageTitle} onBack={() => router.back()} />
        {isMotor ? (
          <MotorRenewalForm
            policy={selectedPolicy?.category === 'Motor' ? selectedPolicy : undefined}
            policies={motorPolicies}
            policyNumber={policyNumber}
            onPolicyNumberChange={setPolicyNumber}
            onChoosePolicy={() => setShowPolicyPicker(true)}
            onSubmit={submitMotorRenewal}
            error={error}
            savedMessage={savedMessage}
          />
        ) : (
          <>
            <Image
              source={require('../assets/images/policy-renewal-hero.png')}
              resizeMode="cover"
              style={styles.heroImage}
              accessibilityLabel="Insurance documents and protection umbrella"
            />
            {!selectedPolicy ? (
              <SurfaceCard style={styles.emptyCard}>
                <Ionicons name="document-text-outline" size={27} color={colors.mutedForeground} />
                <Text style={[styles.heading, { color: colors.foreground }]}>No health policy is saved</Text>
                <Text style={[styles.helper, { color: colors.mutedForeground }]}>Add a policy or explore a health plan to continue.</Text>
                <PrimaryButton label="Explore health plans" icon="arrow-forward" onPress={() => router.push('/health-plan?plan=complete')} />
              </SurfaceCard>
            ) : (
              <>
                <StepProgress step={step} />
                <Text style={[styles.heading, { color: colors.foreground }]}>
                  {step === 1 ? 'Welcome, Renew Insurance Via' : step === 2 ? 'Choose your renewal plan' : "You're almost there!"}
                </Text>
                {step === 1 ? (
                  <SurfaceCard style={styles.formCard}>
                    <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Policy Number *</Text>
                    <LabeledInput value={policyNumber} onChangeText={setPolicyNumber} placeholder="Enter policy number" autoCapitalize="characters" />
                    <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Email ID *</Text>
                    <LabeledInput value={email} onChangeText={setEmail} placeholder="Email ID" keyboardType="email-address" autoCapitalize="none" />
                    <View style={styles.twoColumns}>
                      <DatePickerField
                        label="Date of Birth *"
                        value={dateOfBirth}
                        onChange={setDateOfBirth}
                        displayFormat="DD/MM/YYYY"
                        minDate={new Date(1920, 0, 1)}
                        maxDate={new Date()}
                        testID="renewal-dob"
                      />
                      <View style={styles.flexColumn}>
                        <Text style={[styles.fieldLabel, { color: colors.foreground }]}>ID Type *</Text>
                        <View style={styles.idTypeOptions}>
                          {['Aadhaar', 'PAN'].map((type) => (
                            <Pressable
                              key={type}
                              onPress={() => setIdType(type)}
                              style={[styles.idTypeButton, { backgroundColor: idType === type ? colors.primaryWash : colors.card, borderColor: idType === type ? colors.primary : colors.border }]}
                            >
                              <Text style={[styles.idTypeText, { color: idType === type ? colors.primary : colors.foreground }]}>{type}</Text>
                            </Pressable>
                          ))}
                        </View>
                      </View>
                    </View>
                    <Text style={[styles.fieldLabel, { color: colors.foreground }]}>{idType} Number *</Text>
                    <LabeledInput value={idNumber} onChangeText={setIdNumber} placeholder={`Enter ${idType} number`} autoCapitalize="characters" />
                    <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Mobile Number *</Text>
                    <LabeledInput value={mobile} onChangeText={setMobile} placeholder="Mobile number" keyboardType="phone-pad" />
                    <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Is there any change in KYC?</Text>
                    <View style={styles.radioRow}>
                      <RadioOption label="Yes" selected={kycChanged === true} onPress={() => setKycChanged(true)} />
                      <RadioOption label="No" selected={kycChanged === false} onPress={() => setKycChanged(false)} />
                    </View>
                    <Pressable onPress={() => setConsent((current) => !current)} style={styles.consentRow}>
                      <Ionicons name={consent ? 'checkbox' : 'square-outline'} size={18} color={consent ? colors.primary : colors.mutedForeground} />
                      <Text style={[styles.consentText, { color: colors.mutedForeground }]}>
                        I consent to receive and download information from central KYC registry and agree to the Terms & Conditions.
                      </Text>
                    </Pressable>
                    {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
                    <PrimaryButton label="Verify" icon="arrow-forward" onPress={verifyKyc} />
                  </SurfaceCard>
                ) : null}

                {step === 2 ? (
                  <SurfaceCard style={styles.formCard}>
                    <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Select the right Sum Insured *</Text>
                    <View style={styles.chips}>
                      {['₹5,00,000', '₹10,00,000'].map((amount) => (
                        <ChoiceChip key={amount} label={amount} active={sumInsured === amount} onPress={() => setSumInsured(amount)} />
                      ))}
                    </View>
                    <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Policy tenure</Text>
                    <View style={styles.chips}>
                      {[1, 2, 3].map((years) => (
                        <ChoiceChip key={years} label={`${years} ${years === 1 ? 'Year' : 'Years'}`} active={tenure === years} onPress={() => setTenure(years)} />
                      ))}
                    </View>
                    <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Select Plan Option</Text>
                    {['Package One', 'Package Two'].map((option, index) => (
                      <Pressable
                        key={option}
                        onPress={() => setPlan(option)}
                        style={[styles.planChoice, { borderColor: plan === option ? colors.primary : colors.border, backgroundColor: plan === option ? colors.primaryWash : colors.card }]}
                      >
                        <Ionicons name={plan === option ? 'radio-button-on' : 'radio-button-off'} size={18} color={colors.primary} />
                        <View style={styles.planCopy}>
                          <Text style={[styles.planTitle, { color: colors.foreground }]}>{option}</Text>
                          <Text style={[styles.helper, { color: colors.mutedForeground }]}>
                            {index === 0 ? 'Core cover and selected benefits' : 'Extended cover with additional benefits'}
                          </Text>
                        </View>
                        <Text style={[styles.price, { color: colors.primary }]}>₹{(basePremium + (index ? -400 : 0)).toLocaleString('en-IN')}</Text>
                      </Pressable>
                    ))}
                    <View style={styles.addOnHeader}>
                      <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Add-ons for you</Text>
                      <Text style={[styles.helper, { color: colors.mutedForeground }]}>Tap to select</Text>
                    </View>
                    {addOnOptions.map((option) => (
                      <Pressable key={option.id} onPress={() => toggleAddOn(option.id)} style={[styles.addOnRow, { borderColor: colors.border }]}>
                        <Ionicons name="add-circle-outline" size={18} color={colors.primary} />
                        <Text style={[styles.addOnName, { color: colors.foreground }]}>{option.name}</Text>
                        <Text style={[styles.addOnPrice, { color: colors.primary }]}>₹{option.price.toLocaleString('en-IN')}</Text>
                        <Ionicons name={selectedAddOns.includes(option.id) ? 'checkbox' : 'square-outline'} size={18} color={selectedAddOns.includes(option.id) ? colors.primary : colors.mutedForeground} />
                      </Pressable>
                    ))}
                    <View style={[styles.totalRow, { borderTopColor: colors.border }]}>
                      <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Estimated premium</Text>
                      <Text style={[styles.price, { color: colors.primary }]}>₹{totalPayable.toLocaleString('en-IN')}</Text>
                    </View>
                    {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
                    <PrimaryButton label="Continue to review" icon="arrow-forward" onPress={() => { setError(''); setStep(3); }} />
                    <Pressable onPress={() => setStep(1)} style={styles.backLink}>
                      <Text style={[styles.linkText, { color: colors.primary }]}>Back to KYC</Text>
                    </Pressable>
                  </SurfaceCard>
                ) : null}

                {step === 3 ? (
                  <SurfaceCard style={styles.summaryCard}>
                    <View style={[styles.readyBanner, { backgroundColor: colors.primaryWash }]}>
                      <Ionicons name="checkmark-circle" size={20} color={colors.success} />
                      <Text style={[styles.readyText, { color: colors.foreground }]}>Review renewal details</Text>
                    </View>
                    <View style={styles.policySummary}>
                      <SummaryItem label="Policy number" value={policyNumber} />
                      <SummaryItem label="Sum insured" value={sumInsured} />
                      <SummaryItem label="Plan" value={plan} />
                      <SummaryItem label="Tenure" value={`${tenure} ${tenure === 1 ? 'Year' : 'Years'}`} />
                    </View>
                    <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Premium Details</Text>
                    <SummaryItem label="Basic premium" value={`₹${basePremium.toLocaleString('en-IN')}`} />
                    <SummaryItem label="Add-ons" value={`₹${addOnTotal.toLocaleString('en-IN')}`} />
                    <SummaryItem label="Plan discount" value={`-₹${discount.toLocaleString('en-IN')}`} />
                    <SummaryItem label="GST (18%)" value={`₹${gst.toLocaleString('en-IN')}`} />
                    <View style={[styles.totalRow, { borderTopColor: colors.border }]}>
                      <Text style={[styles.totalLabel, { color: colors.primary }]}>Total Payable</Text>
                      <Text style={[styles.totalAmount, { color: colors.primary }]}>₹{totalPayable.toLocaleString('en-IN')}</Text>
                    </View>
                    <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Payment method (demo)</Text>
                    <View style={styles.chips}>
                      {['UPI', 'Card'].map((method) => (
                        <ChoiceChip key={method} label={method} active={paymentMethod === method} onPress={() => setPaymentMethod(method)} />
                      ))}
                    </View>
                    <Text style={[styles.helper, { color: colors.mutedForeground }]}>
                      This is a local preview only. No payment is taken and no renewal is submitted to the insurer.
                    </Text>
                    {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
                    {savedMessage ? <Text style={[styles.successMessage, { color: colors.success }]}>{savedMessage}</Text> : null}
                    <PrimaryButton label="Save demo renewal" icon="checkmark" onPress={() => void saveRenewal('Health', policyNumber.trim())} />
                    <Pressable onPress={() => setStep(2)} style={styles.backLink}>
                      <Text style={[styles.linkText, { color: colors.primary }]}>Back to plan</Text>
                    </Pressable>
                  </SurfaceCard>
                ) : null}
                <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
                  Sample renewal flow only. Rates, eligibility, payment and policy changes are not connected to insurer services.
                </Text>
              </>
            )}
          </>
        )}
      </KeyboardAwareScrollViewCompat>

      <Modal
        transparent
        visible={showKycComplete}
        animationType="fade"
        onRequestClose={() => setShowKycComplete(false)}
      >
        <View style={[styles.modalOverlay, { backgroundColor: colors.scrim }]}>
          <SurfaceCard style={styles.modalCard}>
            <View style={[styles.kycIcon, { backgroundColor: colors.primaryWash }]}>
              <Ionicons name="shield-checkmark" size={36} color={colors.success} />
            </View>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>Your KYC is completed</Text>
            <Text style={[styles.helper, { color: colors.mutedForeground }]}>Click OK to continue to your plan.</Text>
            <PrimaryButton label="OK" onPress={() => { setShowKycComplete(false); setStep(2); }} />
          </SurfaceCard>
        </View>
      </Modal>

      <Modal
        transparent
        visible={showPolicyPicker}
        animationType="slide"
        onRequestClose={() => setShowPolicyPicker(false)}
      >
        <View style={[styles.modalOverlay, { backgroundColor: colors.scrim }]}>
          <SurfaceCard style={styles.pickerCard}>
            <View style={styles.pickerHeading}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Select a motor policy</Text>
              <Pressable onPress={() => setShowPolicyPicker(false)} accessibilityRole="button" accessibilityLabel="Close policy list">
                <Ionicons name="close" size={22} color={colors.foreground} />
              </Pressable>
            </View>
            {motorPolicies.length ? motorPolicies.map((policy) => (
              <Pressable key={policy.id} onPress={() => openPolicy(policy)} style={[styles.pickerRow, { borderColor: colors.border }]}>
                <View style={styles.planCopy}>
                  <Text style={[styles.planTitle, { color: colors.foreground }]}>{policy.name}</Text>
                  <Text style={[styles.helper, { color: colors.mutedForeground }]}>{policy.policyNumber}</Text>
                </View>
                <Ionicons name="chevron-forward" size={16} color={colors.primary} />
              </Pressable>
            )) : (
              <Text style={[styles.helper, { color: colors.mutedForeground }]}>No motor policies are saved on this device.</Text>
            )}
          </SurfaceCard>
        </View>
      </Modal>
    </>
  );
}

function MotorRenewalForm({
  policy,
  policies,
  policyNumber,
  onPolicyNumberChange,
  onChoosePolicy,
  onSubmit,
  error,
  savedMessage,
}: {
  policy?: UserPolicy;
  policies: UserPolicy[];
  policyNumber: string;
  onPolicyNumberChange: (value: string) => void;
  onChoosePolicy: () => void;
  onSubmit: () => void;
  error: string;
  savedMessage: string;
}) {
  const colors = useColors();
  return (
    <>
      <Image
        source={require('../assets/images/policy-renewal-hero.png')}
        resizeMode="cover"
        style={styles.heroImage}
        accessibilityLabel="Insurance documents and protection umbrella"
      />
      <View style={styles.motorIntro}>
        <Text style={[styles.heading, { color: colors.foreground }]}>Renew your motor policy</Text>
        <Text style={[styles.helper, { color: colors.mutedForeground }]}>Choose a saved policy or enter a policy number.</Text>
      </View>
      {policies.length ? (
        <SurfaceCard style={styles.formCard}>
          {policy ? (
            <View style={[styles.selectedPolicy, { backgroundColor: colors.primaryWash }]}>
              <Ionicons name="car-outline" size={20} color={colors.primary} />
              <View style={styles.planCopy}>
                <Text style={[styles.planTitle, { color: colors.foreground }]}>{policy.name}</Text>
                <Text style={[styles.helper, { color: colors.mutedForeground }]}>Expires {policy.expiryDate}</Text>
              </View>
            </View>
          ) : null}
          <Pressable onPress={onChoosePolicy} style={[styles.selectPolicy, { borderColor: colors.border }]}>
            <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Choose saved policy</Text>
            <Ionicons name="chevron-down" size={17} color={colors.mutedForeground} />
          </Pressable>
          <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Policy Number</Text>
          <LabeledInput value={policyNumber} onChangeText={onPolicyNumberChange} placeholder="Enter policy number" autoCapitalize="characters" />
          {error ? <Text style={[styles.error, { color: colors.destructive }]}>{error}</Text> : null}
          {savedMessage ? <Text style={[styles.successMessage, { color: colors.success }]}>{savedMessage}</Text> : null}
          <PrimaryButton label="Submit" icon="arrow-forward" onPress={onSubmit} />
          <Text style={[styles.helper, { color: colors.mutedForeground }]}>
            This saves a demo renewal request on this device. It is not sent to the insurer.
          </Text>
        </SurfaceCard>
      ) : (
        <SurfaceCard style={styles.emptyCard}>
          <Ionicons name="car-outline" size={27} color={colors.mutedForeground} />
          <Text style={[styles.heading, { color: colors.foreground }]}>No motor policy is saved</Text>
          <Text style={[styles.helper, { color: colors.mutedForeground }]}>Start a motor quote or add an existing policy.</Text>
          <PrimaryButton
            label="Get a motor quote"
            icon="arrow-forward"
            onPress={() => router.push({ pathname: '/motor-insurance', params: { vehicle: 'Four Wheeler', mode: 'renew' } })}
          />
        </SurfaceCard>
      )}
    </>
  );
}

function StepProgress({ step }: { step: 1 | 2 | 3 }) {
  const colors = useColors();
  const steps = ['KYC', 'Plan', 'Payment'];
  return (
    <View style={styles.stepProgress}>
      {steps.map((label, index) => {
        const active = index + 1 <= step;
        return (
          <React.Fragment key={label}>
            <View style={styles.stepItem}>
              <View style={[styles.stepCircle, { backgroundColor: active ? colors.primary : colors.border }]}>
                <Text style={[styles.stepNumber, { color: active ? colors.white : colors.mutedForeground }]}>{index + 1}</Text>
              </View>
              <Text style={[styles.stepLabel, { color: active ? colors.primary : colors.mutedForeground }]}>{label}</Text>
            </View>
            {index < steps.length - 1 ? <View style={[styles.stepLine, { backgroundColor: step > index + 1 ? colors.primary : colors.border }]} /> : null}
          </React.Fragment>
        );
      })}
    </View>
  );
}

function RadioOption({ label, selected, onPress }: { label: string; selected: boolean; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable onPress={onPress} style={styles.radioOption}>
      <Ionicons name={selected ? 'radio-button-on' : 'radio-button-off'} size={18} color={selected ? colors.primary : colors.mutedForeground} />
      <Text style={[styles.radioLabel, { color: colors.foreground }]}>{label}</Text>
    </Pressable>
  );
}

function ChoiceChip({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable onPress={onPress} style={[styles.choiceChip, { backgroundColor: active ? colors.primary : colors.card, borderColor: active ? colors.primary : colors.border }]}>
      <Text style={[styles.choiceChipText, { color: active ? colors.white : colors.foreground }]}>{label}</Text>
    </Pressable>
  );
}

function SummaryItem({ label, value }: { label: string; value: string }) {
  const colors = useColors();
  return (
    <View style={styles.summaryRow}>
      <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.summaryValue, { color: colors.foreground }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  content: { flexGrow: 1, paddingHorizontal: 14, gap: 12 },
  heroImage: { width: '100%', height: 155, borderRadius: 13 },
  heading: { fontSize: 15, fontWeight: '800' },
  helper: { fontSize: 9, lineHeight: 14 },
  formCard: { padding: 12, gap: 9 },
  fieldLabel: { fontSize: 10, fontWeight: '700' },
  twoColumns: { flexDirection: 'row', gap: 8 },
  flexColumn: { flex: 1, gap: 5 },
  idTypeOptions: { flexDirection: 'row', gap: 5 },
  idTypeButton: { flex: 1, minHeight: 39, borderWidth: 1, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  idTypeText: { fontSize: 9, fontWeight: '700' },
  radioRow: { flexDirection: 'row', gap: 35 },
  radioOption: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 3 },
  radioLabel: { fontSize: 10, fontWeight: '700' },
  consentRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 7, paddingVertical: 3 },
  consentText: { flex: 1, fontSize: 9, lineHeight: 14 },
  error: { fontSize: 9, lineHeight: 14 },
  successMessage: { fontSize: 9, lineHeight: 14, fontWeight: '700' },
  stepProgress: { flexDirection: 'row', alignItems: 'flex-start', paddingHorizontal: 13, paddingTop: 3 },
  stepItem: { alignItems: 'center', gap: 4 },
  stepCircle: { width: 22, height: 22, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  stepNumber: { fontSize: 9, fontWeight: '800' },
  stepLabel: { fontSize: 8, fontWeight: '700' },
  stepLine: { flex: 1, height: 2, marginTop: 10, marginHorizontal: 4 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  choiceChip: { minHeight: 34, borderWidth: 1, borderRadius: 18, paddingHorizontal: 12, alignItems: 'center', justifyContent: 'center' },
  choiceChipText: { fontSize: 9, fontWeight: '800' },
  planChoice: { minHeight: 62, borderWidth: 1, borderRadius: 12, padding: 9, flexDirection: 'row', alignItems: 'center', gap: 7 },
  planCopy: { flex: 1, gap: 4 },
  planTitle: { fontSize: 10, fontWeight: '800' },
  price: { fontSize: 11, fontWeight: '800' },
  addOnHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 2 },
  addOnRow: { minHeight: 46, borderWidth: 1, borderRadius: 11, paddingHorizontal: 8, flexDirection: 'row', alignItems: 'center', gap: 7 },
  addOnName: { flex: 1, fontSize: 9, lineHeight: 13 },
  addOnPrice: { fontSize: 9, fontWeight: '800' },
  totalRow: { borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 10, marginTop: 2, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  backLink: { alignItems: 'center', paddingVertical: 3 },
  linkText: { fontSize: 9, fontWeight: '800' },
  summaryCard: { padding: 12, gap: 10 },
  readyBanner: { minHeight: 42, borderRadius: 11, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', gap: 7 },
  readyText: { fontSize: 11, fontWeight: '800' },
  policySummary: { gap: 8, paddingVertical: 4 },
  sectionTitle: { fontSize: 12, fontWeight: '800' },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 8 },
  summaryLabel: { fontSize: 9 },
  summaryValue: { flex: 1, fontSize: 9, fontWeight: '700', textAlign: 'right' },
  totalLabel: { fontSize: 11, fontWeight: '800' },
  totalAmount: { fontSize: 14, fontWeight: '800' },
  disclaimer: { fontSize: 8, lineHeight: 13, textAlign: 'center' },
  emptyCard: { padding: 15, gap: 9, alignItems: 'center' },
  motorIntro: { gap: 4, alignItems: 'center' },
  selectedPolicy: { minHeight: 51, padding: 8, flexDirection: 'row', alignItems: 'center', gap: 8, borderRadius: 11 },
  selectPolicy: { minHeight: 42, borderWidth: 1, borderRadius: 10, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  modalOverlay: { flex: 1, padding: 22, alignItems: 'center', justifyContent: 'center' },
  modalCard: { width: '100%', maxWidth: 360, padding: 18, alignItems: 'center', gap: 11, borderRadius: 18 },
  kycIcon: { width: 66, height: 66, borderRadius: 23, alignItems: 'center', justifyContent: 'center' },
  modalTitle: { fontSize: 15, fontWeight: '800', textAlign: 'center' },
  pickerCard: { width: '100%', maxWidth: 390, padding: 14, gap: 9, borderRadius: 18 },
  pickerHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingBottom: 4 },
  pickerRow: { minHeight: 53, borderWidth: 1, borderRadius: 11, paddingHorizontal: 9, flexDirection: 'row', alignItems: 'center', gap: 8 },
});
