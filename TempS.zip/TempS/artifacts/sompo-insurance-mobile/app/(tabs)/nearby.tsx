import React from 'react';
import { Alert, Image, Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppPage, SectionHeading, SurfaceCard } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

const healthServices = [
  { title: 'Network Hospital', icon: 'business-outline' as const, category: 'Hospitals' },
  { title: 'Ambulances', icon: 'medkit-outline' as const, category: 'Ambulances' },
  { title: 'Blood Banks', icon: 'water-outline' as const, category: 'Blood Banks' },
  { title: 'Pharmacies', icon: 'medical-outline' as const, category: 'Pharmacies' },
  { title: 'Diagnostic Labs', icon: 'flask-outline' as const, category: 'Diagnostic Labs' },
  { title: 'Wellness Center', icon: 'fitness-outline' as const, category: 'Wellness Centers' },
];

const autoServices = [
  { title: 'Network Garages', icon: 'home-outline' as const, category: 'Network Garages' },
  { title: 'Petrol Pump', icon: 'speedometer-outline' as const, category: 'Petrol Pumps' },
  { title: 'Mechanic', icon: 'construct-outline' as const, category: 'Mechanics' },
  { title: 'Parking', icon: 'car-outline' as const, category: 'Parking' },
  { title: 'Pollution Center', icon: 'leaf-outline' as const, category: 'Pollution Centers' },
  { title: 'Our Branch', icon: 'business-outline' as const, category: 'Branches' },
];

function NearbyTile({
  title,
  icon,
  category,
}: {
  title: string;
  icon: keyof typeof Ionicons.glyphMap;
  category: string;
}) {
  const colors = useColors();
  const open = () => {
    if (category === 'Ambulances') {
      Alert.alert('Emergency help', 'Call 108 for ambulance assistance.', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Call 108', onPress: () => void Linking.openURL('tel:108') },
      ]);
      return;
    }
    router.push({ pathname: '/find-hospitals', params: { category } });
  };

  return (
    <Pressable onPress={open} style={({ pressed }) => [styles.tilePressable, pressed && styles.pressed]}>
      <SurfaceCard style={styles.tile}>
        <View style={[styles.tileIcon, { backgroundColor: colors.primaryWash }]}>
          <Ionicons name={icon} size={22} color={colors.primary} />
        </View>
        <Text style={[styles.tileTitle, { color: colors.foreground }]}>{title}</Text>
        <Ionicons name="arrow-forward" size={16} color={colors.mutedForeground} />
      </SurfaceCard>
    </Pressable>
  );
}

export default function NearbyScreen() {
  const colors = useColors();
  return (
    <AppPage contentStyle={styles.content}>
      <View style={styles.titleBlock}>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>SERVICES AROUND YOU</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Nearby</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Find hospitals, pharmacies, garages and more.
        </Text>
      </View>

      <View style={styles.bandHeading}>
        <Text style={[styles.bandTitle, { color: colors.foreground }]}>Health</Text>
        <View style={[styles.bandLine, { backgroundColor: colors.primaryPale }]} />
      </View>
      <View style={styles.grid}>
        {healthServices.map((service) => (
          <NearbyTile key={service.title} {...service} />
        ))}
      </View>

      <View style={styles.bandHeading}>
        <Text style={[styles.bandTitle, { color: colors.foreground }]}>Auto</Text>
        <View style={[styles.bandLine, { backgroundColor: colors.primaryPale }]} />
      </View>
      <View style={styles.grid}>
        {autoServices.map((service) => (
          <NearbyTile key={service.title} {...service} />
        ))}
      </View>

      <Pressable onPress={() => router.push('/find-hospitals')} style={({ pressed }) => [pressed && styles.pressed]}>
        <SurfaceCard style={[styles.promo, { backgroundColor: colors.primaryPale }]}>
          <View style={styles.promoCopy}>
            <Text style={[styles.promoEyebrow, { color: colors.primary }]}>NEAR BY</Text>
            <Text style={[styles.promoTitle, { color: colors.foreground }]}>Everything you need, close by.</Text>
            <Text style={[styles.promoBody, { color: colors.mutedForeground }]}>
              Search the sample directory by city or pincode.
            </Text>
          </View>
          <Image
            source={require('../../assets/images/onboarding-safety.png')}
            resizeMode="contain"
            style={styles.promoArt}
            accessibilityLabel="Insurance and care illustration"
          />
        </SurfaceCard>
      </Pressable>
      <Text style={[styles.note, { color: colors.mutedForeground }]}>
        Directory entries are demonstration data and are not live availability.
      </Text>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 14, gap: 12 },
  titleBlock: { gap: 4, paddingTop: 3 },
  eyebrow: { fontSize: 9, fontWeight: '800', letterSpacing: 1 },
  title: { fontSize: 26, fontWeight: '800' },
  subtitle: { fontSize: 12, lineHeight: 17 },
  bandHeading: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 3 },
  bandTitle: { fontSize: 17, fontWeight: '800' },
  bandLine: { flex: 1, height: 1 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  tilePressable: { width: '48%' },
  tile: { minHeight: 68, padding: 9, borderRadius: 13, flexDirection: 'row', alignItems: 'center', gap: 7 },
  tileIcon: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  tileTitle: { flex: 1, fontSize: 10, fontWeight: '700', lineHeight: 13 },
  promo: { minHeight: 116, flexDirection: 'row', alignItems: 'center', overflow: 'hidden', borderRadius: 18 },
  promoCopy: { flex: 1, gap: 5 },
  promoEyebrow: { fontSize: 9, fontWeight: '800', letterSpacing: 1 },
  promoTitle: { fontSize: 16, lineHeight: 20, fontWeight: '800' },
  promoBody: { fontSize: 10, lineHeight: 14 },
  promoArt: { width: 80, height: 90 },
  note: { fontSize: 9, lineHeight: 14, textAlign: 'center' },
  pressed: { opacity: 0.76, transform: [{ scale: 0.99 }] },
});
