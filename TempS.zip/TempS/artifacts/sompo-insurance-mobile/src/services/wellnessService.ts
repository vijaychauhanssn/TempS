export type WellnessDataMode = 'device-local-demo';

export const wellnessService = {
  getMode(): WellnessDataMode {
    return 'device-local-demo';
  },
};
