# USGI React Native starter (Expo + TypeScript)

This is a runnable starter reconstructed from the two supplied photos of the Figma board. The photos show a Universal Sompo General Insurance app flow: welcome/onboarding, individual/corporate sign-in, home/services, contact/emergency, notifications, and claim tracking.

## Run in Replit
1. Create a new **Node.js** Replit project.
2. Upload/extract this project into it.
3. In the Shell run `npm install`.
4. Run `npm start` and open the Expo QR code with Expo Go, or use `npm run web` for a web preview.
5. If Replit's template has a different Expo SDK, keep the template's compatible Expo/React Native versions and install the navigation dependencies listed in `package.json`.

## Included screens
- Welcome / onboarding entry
- Login with individual/corporate switch and demo OTP flow
- Home dashboard and quick-service tiles
- Claims list with status/progress and filters
- Profile/settings menu
- Bottom-tab navigation

## Important limitations
- This is a **functional UI prototype**, not the original application's recovered source code.
- The supplied images are photos of a large Figma canvas, not direct frame exports. Fine text, spacing, imagery and some screens cannot be read accurately; screens are approximations and should be refined against direct Figma frame exports.
- OTP, login, policy, claims, contact, notifications and emergency services are not connected to real APIs. The demo login accepts any 4+ digit OTP after a 10-digit mobile number. Do not use real customer data until authentication, authorization, secure token storage, API validation and privacy/security review are implemented.
- APK reverse engineering may recover some resources and decompiled code, but it does not reliably restore the original React Native project, TypeScript, navigation source, or backend.

## Next accuracy step
Export each important Figma frame as PNG at 2x/3x and provide the APK. Then the layouts, assets, screen navigation and behavior can be compared and refined. Do not use a screenshot of the whole canvas as an app asset.
