import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import BrandHeader from '../components/BrandHeader';
import SectionTitle from '../components/SectionTitle';
import { colors } from '../theme/colors';

const services = [
  { label: 'My Policies', icon: 'shield-checkmark-outline' as const },
  { label: 'Claims', icon: 'document-text-outline' as const },
  { label: 'Renew Policy', icon: 'refresh-outline' as const },
  { label: 'Network Hospitals', icon: 'medkit-outline' as const },
  { label: 'Download', icon: 'download-outline' as const },
  { label: 'Help & Support', icon: 'headset-outline' as const },
];
export default function HomeScreen({ navigation }: any) {
  return (
    <View style={styles.screen}>
      <BrandHeader />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.greeting}>Hello there 👋</Text>
        <Text style={styles.sub}>Welcome to your insurance dashboard</Text>
        <View style={styles.banner}>
          <View style={{ flex: 1 }}>
            <Text style={styles.bannerKicker}>YOUR SAFETY, OUR PROMISE</Text>
            <Text style={styles.bannerTitle}>Insurance made simple.</Text>
            <Text style={styles.bannerBody}>Manage policies and track claims in one place.</Text>
          </View>
          <View style={styles.bannerIcon}><Ionicons name="heart-half-outline" size={36} color={colors.primary}/></View>
        </View>
        <SectionTitle title="Quick services" action="View all" />
        <View style={styles.grid}>{services.map(item => (
          <Pressable key={item.label} style={styles.service} onPress={() => item.label === 'Claims' ? navigation.navigate('Claims') : undefined}>
            <View style={styles.serviceIcon}><Ionicons name={item.icon} size={24} color={colors.primary}/></View>
            <Text style={styles.serviceLabel}>{item.label}</Text>
          </Pressable>
        ))}</View>
        <SectionTitle title="Recent activity" action="View history" />
        <View style={styles.activity}>
          <View style={styles.activityIcon}><Ionicons name="document-text-outline" size={22} color={colors.primary}/></View>
          <View style={{ flex: 1 }}><Text style={styles.activityTitle}>No recent activity</Text><Text style={styles.activitySub}>Your policy and claim updates will appear here.</Text></View>
        </View>
        <View style={styles.help}><Ionicons name="call-outline" size={22} color={colors.primary}/><View style={{ flex: 1 }}><Text style={styles.activityTitle}>Need help?</Text><Text style={styles.activitySub}>Contact our support team for assistance.</Text></View><Ionicons name="chevron-forward" size={20} color={colors.muted}/></View>
      </ScrollView>
    </View>
  );
}
const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  content: { padding: 18, paddingBottom: 28 },
  greeting: { fontSize: 23, fontWeight: '800', color: colors.text, marginTop: 8 },
  sub: { color: colors.muted, marginTop: 5, marginBottom: 18, fontSize: 13 },
  banner: { backgroundColor: colors.roseLight, borderRadius: 18, padding: 18, flexDirection: 'row', alignItems: 'center', marginBottom: 25 },
  bannerKicker: { fontSize: 9, letterSpacing: 1, color: colors.primary, fontWeight: '800' },
  bannerTitle: { fontSize: 19, fontWeight: '800', color: colors.text, marginTop: 8 },
  bannerBody: { fontSize: 12, lineHeight: 18, color: colors.muted, marginTop: 6, maxWidth: 220 },
  bannerIcon: { width: 68, height: 68, borderRadius: 34, backgroundColor: '#FFF', alignItems: 'center', justifyContent: 'center', marginLeft: 10 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginBottom: 24 },
  service: { width: '31.5%', minHeight: 108, backgroundColor: '#FFF', borderRadius: 15, padding: 12, alignItems: 'center', justifyContent: 'center', marginBottom: 10, borderWidth: 1, borderColor: '#F0ECEE' },
  serviceIcon: { width: 48, height: 48, borderRadius: 16, backgroundColor: colors.roseLight, alignItems: 'center', justifyContent: 'center', marginBottom: 9 },
  serviceLabel: { color: colors.text, fontSize: 11, textAlign: 'center', fontWeight: '600' },
  activity: { backgroundColor: '#FFF', borderRadius: 15, padding: 15, flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 12 },
  activityIcon: { width: 46, height: 46, borderRadius: 14, backgroundColor: colors.roseLight, alignItems: 'center', justifyContent: 'center' },
  activityTitle: { fontSize: 13, fontWeight: '700', color: colors.text },
  activitySub: { color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 4 },
  help: { backgroundColor: '#FFF', borderRadius: 15, padding: 15, flexDirection: 'row', alignItems: 'center', gap: 12 },
});