import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { RootStackParamList } from '../../App';
import PrimaryButton from '../components/PrimaryButton';
import { colors } from '../theme/colors';

type Props = NativeStackScreenProps<RootStackParamList, 'Welcome'>;
export default function WelcomeScreen({ navigation }: Props) {
  return (
    <ScrollView contentContainerStyle={styles.page}>
      <View style={styles.brand}>
        <View style={styles.logo}><Ionicons name="shield-checkmark" size={28} color="#FFF" /></View>
        <Text style={styles.brandName}>Universal Sompo</Text>
        <Text style={styles.brandSub}>GENERAL INSURANCE</Text>
      </View>
      <View style={styles.hero}>
        <View style={styles.artCircle}><Ionicons name="shield-checkmark" size={72} color={colors.primary} /><View style={styles.smallCircle}><Ionicons name="heart" size={22} color="#FFF" /></View></View>
      </View>
      <Text style={styles.heading}>Welcome</Text>
      <Text style={styles.description}>Your all-in-one insurance companion. Explore your policies, track claims and get support whenever you need it.</Text>
      <View style={styles.dots}><View style={styles.dotActive}/><View style={styles.dot}/><View style={styles.dot}/></View>
      <PrimaryButton title="Get Started" onPress={() => navigation.navigate('Login')} style={{ width: '100%', marginTop: 28 }} />
      <Text style={styles.footer}>Your safety. Our promise.</Text>
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  page: { flexGrow: 1, backgroundColor: '#FFF', paddingHorizontal: 28, paddingTop: 48, paddingBottom: 30, alignItems: 'center', justifyContent: 'space-between' },
  brand: { alignItems: 'center' },
  logo: { backgroundColor: colors.primary, width: 54, height: 54, borderRadius: 17, alignItems: 'center', justifyContent: 'center', marginBottom: 9 },
  brandName: { fontSize: 19, fontWeight: '800', color: colors.text },
  brandSub: { fontSize: 10, letterSpacing: 2, color: colors.muted, marginTop: 3 },
  hero: { height: 240, width: '100%', alignItems: 'center', justifyContent: 'center', backgroundColor: colors.roseLight, borderRadius: 120, marginTop: 30 },
  artCircle: { width: 150, height: 150, borderRadius: 75, backgroundColor: '#FFF', alignItems: 'center', justifyContent: 'center', elevation: 2 },
  smallCircle: { position: 'absolute', right: 2, bottom: 5, width: 48, height: 48, borderRadius: 24, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' },
  heading: { fontSize: 30, fontWeight: '800', color: colors.primary, marginTop: 28 },
  description: { fontSize: 14, lineHeight: 22, textAlign: 'center', color: colors.muted, marginTop: 10 },
  dots: { flexDirection: 'row', gap: 7, marginTop: 18 },
  dotActive: { width: 22, height: 7, borderRadius: 4, backgroundColor: colors.primary },
  dot: { width: 7, height: 7, borderRadius: 4, backgroundColor: '#D8C6CA' },
  footer: { marginTop: 18, color: colors.muted, fontSize: 11 },
});