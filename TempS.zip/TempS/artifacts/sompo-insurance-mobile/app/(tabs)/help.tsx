import React from 'react';
import { Alert, Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { AppPage, SurfaceCard } from '@/components/AppUI';
import { useAppState } from '@/context/AppState';
import { useColors } from '@/hooks/useColors';

function SupportAction({
  icon,
  label,
  action,
  trailing,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  action: () => void;
  trailing?: string;
}) {
  const colors = useColors();
  return (
    <Pressable onPress={action} style={({ pressed }) => [styles.action, pressed && styles.pressed]}>
      <View style={[styles.actionIcon, { backgroundColor: colors.primaryWash }]}>
        <Ionicons name={icon} size={17} color={colors.primary} />
      </View>
      <Text style={[styles.actionText, { color: colors.foreground }]}>{label}</Text>
      {trailing ? <Text style={[styles.trailing, { color: colors.mutedForeground }]}>{trailing}</Text> : null}
      <Ionicons name="chevron-forward" size={15} color={colors.mutedForeground} />
    </Pressable>
  );
}

function SupportGroup({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  const colors = useColors();
  return (
    <View style={styles.group}>
      <Text style={[styles.groupTitle, { color: colors.primary }]}>{title}</Text>
      <SurfaceCard style={styles.groupCard}>{children}</SurfaceCard>
    </View>
  );
}

export default function HelpScreen() {
  const colors = useColors();
  const { profile } = useAppState();
  const openCall = (phone: string) =>
    void Linking.openURL(`tel:${phone.replace(/[^0-9+]/g, '')}`).catch(() =>
      Alert.alert('Call support', phone),
    );
  const openEmail = () =>
    void Linking.openURL('mailto:contactus@universalsompo.com').catch(() =>
      Alert.alert('Email support', 'contactus@universalsompo.com'),
    );

  return (
    <AppPage contentStyle={styles.content}>
      <View style={styles.titleBlock}>
        <Text style={[styles.title, { color: colors.foreground }]}>Support</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Hope you’re OK?</Text>
        <Text style={[styles.description, { color: colors.mutedForeground }]}>
          We’re available 24/7, even on national holidays.
        </Text>
      </View>

      <SupportGroup title="For General Assistance or Queries">
        <View style={styles.quickSupport}>
          <Pressable onPress={() => openCall('1800-22-4030')} style={styles.quickAction}>
            <View style={[styles.quickIcon, { backgroundColor: colors.success }]}>
              <Ionicons name="call" size={19} color={colors.white} />
            </View>
            <Text style={[styles.quickText, { color: colors.foreground }]}>Call Support</Text>
          </Pressable>
          <Pressable onPress={openEmail} style={styles.quickAction}>
            <View style={[styles.quickIcon, { backgroundColor: colors.blue }]}>
              <Ionicons name="mail" size={19} color={colors.primaryDeep} />
            </View>
            <Text style={[styles.quickText, { color: colors.foreground }]}>Send e-mail</Text>
          </Pressable>
          <Pressable
            onPress={() => router.push({ pathname: '/kbl-details', params: { action: 'forms', claimType: 'Health' } })}
            style={[styles.claimButton, { backgroundColor: colors.primary }]}
          >
            <Text style={[styles.claimButtonText, { color: colors.white }]}>Claim Documents</Text>
            <Ionicons name="arrow-forward" size={15} color={colors.white} />
          </Pressable>
        </View>
      </SupportGroup>

      <SupportGroup title="Escalate Your Grievance">
        <SupportAction icon="mail-outline" label="Send e-mail" action={openEmail} />
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        <SupportAction
          icon="document-text-outline"
          label="Grievance Redressal Procedure"
          action={() => Alert.alert('Grievance Redressal', 'Email contactus@universalsompo.com with your policy number and complaint details. This demo does not submit grievances.')}
        />
      </SupportGroup>

      <SupportGroup title="Emergency Contact No.">
        <SupportAction icon="medkit-outline" label="Ambulance" trailing="108" action={() => openCall('108')} />
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        <SupportAction icon="flame-outline" label="Fire" trailing="101" action={() => openCall('101')} />
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        <SupportAction icon="call-outline" label="User Emergency No." trailing={profile.emergencyPhone} action={() => openCall(profile.emergencyPhone)} />
      </SupportGroup>

      <SupportGroup title="Service Request">
        <SupportAction
          icon="add-circle-outline"
          label="Service Request Registration"
          action={() => router.push({ pathname: '/service-request', params: { mode: 'register' } })}
        />
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        <SupportAction
          icon="search-outline"
          label="Service Request Tracker"
          action={() => router.push({ pathname: '/service-request', params: { mode: 'track' } })}
        />
      </SupportGroup>

      <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
        Contact links are provided for convenience. This demonstration does not send support requests.
      </Text>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 13, gap: 12 },
  titleBlock: { gap: 4 },
  title: { fontSize: 24, fontWeight: '800' },
  subtitle: { fontSize: 15, fontWeight: '800' },
  description: { fontSize: 10, lineHeight: 14 },
  group: { gap: 5 },
  groupTitle: { fontSize: 12, fontWeight: '800' },
  groupCard: { padding: 8, borderRadius: 14, gap: 1 },
  quickSupport: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', gap: 5 },
  quickAction: { flex: 1, minHeight: 69, alignItems: 'center', justifyContent: 'center', gap: 5 },
  quickIcon: { width: 34, height: 34, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  quickText: { fontSize: 9, fontWeight: '700' },
  claimButton: { flex: 1.4, minHeight: 34, borderRadius: 17, paddingHorizontal: 8, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 5 },
  claimButtonText: { fontSize: 9, fontWeight: '800' },
  action: { minHeight: 42, flexDirection: 'row', alignItems: 'center', gap: 8 },
  actionIcon: { width: 30, height: 30, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  actionText: { flex: 1, fontSize: 10, fontWeight: '600' },
  trailing: { fontSize: 10, fontWeight: '700' },
  divider: { height: StyleSheet.hairlineWidth, marginLeft: 39 },
  disclaimer: { fontSize: 9, lineHeight: 14, textAlign: 'center', marginTop: 2 },
  pressed: { opacity: 0.72 },
});
