import React, { useState } from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { AppHeader, AppPage, PrimaryButton, SurfaceCard } from '@/components/AppUI';
import { useColors } from '@/hooks/useColors';

const plans: Record<string, {
  title: string;
  badge: string;
  planName: string;
  cover: string;
  benefits: string[];
}> = {
  'a-plus': {
    title: 'A Plus Health Insurance',
    badge: 'Gold Plan',
    planName: '₹5L – ₹1Cr',
    cover: '15% direct discounts',
    benefits: [
      'Hospitalization expenses up to sum insured',
      'Domiciliary care and organ donor expenses',
      'Ambulance and second opinion benefits',
      'Wellness services and rewards',
    ],
  },
  complete: {
    title: 'Complete Health Insurance',
    badge: 'Complete Plan',
    planName: 'Flexible cover',
    cover: 'Family protection',
    benefits: [
      'Coverage options for individuals and families',
      'Hospitalization and day-care treatment',
      'Restore benefit on eligible claims',
      'Wellness services and support',
    ],
  },
  super: {
    title: 'Super Healthcare Insurance',
    badge: 'Digi-Pro Plan',
    planName: '₹5L – ₹1Cr',
    cover: '13K+ cashless network',
    benefits: [
      'No room rent sub-limit on eligible plans',
      'Cumulative bonus up to 200% of sum insured',
      'Automatic restoration benefit',
      'Ambulance and day-care cover',
    ],
  },
  arogya: {
    title: 'Arogya Sanjeevani Insurance',
    badge: 'Arogya Plan',
    planName: 'Essential health cover',
    cover: 'Cashless network',
    benefits: [
      'Hospitalization cover for eligible expenses',
      'Day-care procedures',
      'AYUSH treatment cover within policy terms',
      'Affordable essential protection',
    ],
  },
};

const coverageSteps = [
  { title: 'Sum Insured', detail: 'Cover for eligible medical expenses', color: 'red' },
  { title: 'Secure Benefit', detail: 'No room rent sub-limit on selected plans', color: 'orange' },
  { title: 'Plus Benefit', detail: 'Cumulative bonus on eligible cover', color: 'green' },
  { title: 'Restore Benefit', detail: 'Automatic restoration after eligible claims', color: 'blue' },
] as const;

export default function HealthPlanScreen() {
  const colors = useColors();
  const { plan = 'a-plus' } = useLocalSearchParams<{ plan?: string }>();
  const data = plans[plan] ?? plans['a-plus'];
  const [showCovered, setShowCovered] = useState(true);

  return (
    <AppPage contentStyle={styles.content}>
      <AppHeader title={data.title} onBack={() => router.back()} />
      <View style={styles.hero}>
        <Image
          source={require('../assets/images/health-family.png')}
          style={styles.familyImage}
          resizeMode="cover"
          accessibilityLabel="Family under a health insurance umbrella"
        />
        <View style={styles.heroCopy}>
          <Text style={[styles.heroEyebrow, { color: colors.primary }]}>HEALTHCARE FOR EVERY FAMILY</Text>
          <Text style={[styles.heroTitle, { color: colors.foreground }]}>{data.title}</Text>
          <Text style={[styles.heroDetail, { color: colors.mutedForeground }]}>
            Explore a sample plan overview and request a demo quote.
          </Text>
        </View>
      </View>
      <View style={styles.perks}>
        <Perk icon="medical-outline" label="4× Coverage" />
        <Perk icon="pricetag-outline" label={data.cover} />
        <Perk icon="business-outline" label="13K+ Cashless Network" />
      </View>

      <SurfaceCard style={styles.coverageCard}>
        <Text style={[styles.coverageHeading, { color: colors.foreground }]}>Get 4X Coverage</Text>
        {coverageSteps.map((item, index) => (
          <View key={item.title} style={styles.coverageRow}>
            <View style={[styles.numberBadge, { backgroundColor: index === 0 ? colors.primary : index === 1 ? colors.vehicle : index === 2 ? colors.success : colors.blue }]}>
              <Text style={[styles.numberText, { color: colors.white }]}>{index + 1}</Text>
            </View>
            <View style={styles.coverageCopy}>
              <Text style={[styles.coverageTitle, { color: colors.white }]}>{item.title}</Text>
              <Text style={[styles.coverageDetail, { color: colors.foreground }]}>{item.detail}</Text>
            </View>
            <Ionicons name="checkmark-circle" size={18} color={colors.success} />
          </View>
        ))}
      </SurfaceCard>

      <View style={[styles.planHeader, { backgroundColor: colors.primaryWash }]}>
        <Text style={[styles.planHeaderTitle, { color: colors.foreground }]}>The right plan for a healthier you</Text>
        <Text style={[styles.planHeaderDetail, { color: colors.mutedForeground }]}>{data.badge} · {data.planName}</Text>
      </View>
      <SurfaceCard style={styles.benefitCard}>
        <View style={styles.benefitHeading}>
          <Ionicons name="shield-checkmark" size={18} color={colors.primary} />
          <Text style={[styles.benefitTitle, { color: colors.foreground }]}>{data.badge}</Text>
        </View>
        {data.benefits.map((benefit) => (
          <View key={benefit} style={styles.benefitRow}>
            <Ionicons name="checkmark-circle" size={15} color={colors.success} />
            <Text style={[styles.benefitText, { color: colors.foreground }]}>{benefit}</Text>
          </View>
        ))}
        <PrimaryButton
          label="Buy Now"
          icon="arrow-forward"
          onPress={() => {
            if (plan === 'a-plus') router.push('/a-plus-calculator');
            else router.push({ pathname: '/health-buy', params: { plan } });
          }}
        />
      </SurfaceCard>

      <View style={styles.coveredSection}>
        <Text style={[styles.coveredHeading, { color: colors.foreground }]}>Know what this plan offers</Text>
        <View style={styles.toggleRow}>
          {[true, false].map((covered) => (
            <Pressable
              key={covered ? 'covered' : 'not-covered'}
              onPress={() => setShowCovered(covered)}
              style={[
                styles.toggle,
                { borderBottomColor: showCovered === covered ? colors.primary : colors.border },
              ]}
            >
              <Text style={[styles.toggleText, { color: showCovered === covered ? colors.primary : colors.mutedForeground }]}>
                {covered ? 'What’s Covered' : 'What’s Not Covered'}
              </Text>
            </Pressable>
          ))}
        </View>
        <SurfaceCard style={styles.coverageInfo}>
          {(showCovered ? data.benefits : [
            'Pre-existing conditions during the waiting period',
            'Non-medical expenses excluded by the policy',
            'Treatment outside the selected plan terms',
          ]).map((item) => (
            <View key={item} style={styles.benefitRow}>
              <Ionicons name={showCovered ? 'checkmark-circle' : 'close-circle-outline'} size={15} color={showCovered ? colors.success : colors.destructive} />
              <Text style={[styles.benefitText, { color: colors.foreground }]}>{item}</Text>
            </View>
          ))}
          <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
            Illustrative summary only. Terms, eligibility and exclusions vary by policy.
          </Text>
        </SurfaceCard>
      </View>
    </AppPage>
  );
}

function Perk({ icon, label }: { icon: keyof typeof Ionicons.glyphMap; label: string }) {
  const colors = useColors();
  return (
    <View style={[styles.perk, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={[styles.perkIcon, { backgroundColor: colors.primaryWash }]}>
        <Ionicons name={icon} size={18} color={colors.primary} />
      </View>
      <Text numberOfLines={2} style={[styles.perkText, { color: colors.foreground }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 13, gap: 12 },
  hero: { minHeight: 138, borderRadius: 16, overflow: 'hidden', backgroundColor: 'transparent' },
  familyImage: { width: '100%', height: 132, borderRadius: 15 },
  heroCopy: { gap: 4, paddingHorizontal: 2 },
  heroEyebrow: { fontSize: 8, fontWeight: '800', letterSpacing: 0.8 },
  heroTitle: { fontSize: 18, fontWeight: '800' },
  heroDetail: { fontSize: 10, lineHeight: 14 },
  perks: { flexDirection: 'row', gap: 6 },
  perk: { flex: 1, minHeight: 69, borderWidth: 1, borderRadius: 12, alignItems: 'center', justifyContent: 'center', padding: 6, gap: 4 },
  perkIcon: { width: 30, height: 30, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  perkText: { fontSize: 8, lineHeight: 11, textAlign: 'center', fontWeight: '700' },
  coverageCard: { gap: 7, padding: 11 },
  coverageHeading: { fontSize: 13, fontWeight: '800', textAlign: 'center', marginBottom: 2 },
  coverageRow: { minHeight: 42, borderRadius: 10, backgroundColor: 'transparent', flexDirection: 'row', alignItems: 'center', gap: 7 },
  numberBadge: { width: 30, height: 30, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  numberText: { fontSize: 12, fontWeight: '800' },
  coverageCopy: { flex: 1, gap: 2 },
  coverageTitle: { fontSize: 10, fontWeight: '800', backgroundColor: 'transparent' },
  coverageDetail: { fontSize: 8, lineHeight: 11 },
  planHeader: { borderRadius: 11, padding: 10, gap: 3, alignItems: 'center' },
  planHeaderTitle: { fontSize: 12, fontWeight: '800' },
  planHeaderDetail: { fontSize: 9 },
  benefitCard: { gap: 9, padding: 12 },
  benefitHeading: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  benefitTitle: { fontSize: 13, fontWeight: '800' },
  benefitRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 7 },
  benefitText: { flex: 1, fontSize: 10, lineHeight: 15 },
  coveredSection: { gap: 9 },
  coveredHeading: { fontSize: 14, fontWeight: '800' },
  toggleRow: { flexDirection: 'row' },
  toggle: { flex: 1, minHeight: 34, borderBottomWidth: 2, alignItems: 'center', justifyContent: 'center' },
  toggleText: { fontSize: 10, fontWeight: '800' },
  coverageInfo: { gap: 9, padding: 12 },
  disclaimer: { fontSize: 9, lineHeight: 14, textAlign: 'center', marginTop: 2 },
});
